/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupMembershipConfig extends cdktf.TerraformMetaArguments {
    /**
    * Only return members with the desired access level. Acceptable values are: `guest`, `reporter`, `developer`, `maintainer`, `owner`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership#access_level DataGitlabGroupMembership#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The full path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership#full_path DataGitlabGroupMembership#full_path}
    */
    readonly fullPath?: string;
    /**
    * The ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership#group_id DataGitlabGroupMembership#group_id}
    */
    readonly groupId?: number;
    /**
    * Return all project members including members through ancestor groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership#inherited DataGitlabGroupMembership#inherited}
    */
    readonly inherited?: boolean | cdktf.IResolvable;
}
export interface DataGitlabGroupMembershipMembers {
}
export declare function dataGitlabGroupMembershipMembersToTerraform(struct?: DataGitlabGroupMembershipMembers): any;
export declare function dataGitlabGroupMembershipMembersToHclTerraform(struct?: DataGitlabGroupMembershipMembers): any;
export declare class DataGitlabGroupMembershipMembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupMembershipMembers | undefined;
    set internalValue(value: DataGitlabGroupMembershipMembers | undefined);
    get accessLevel(): string;
    get avatarUrl(): string;
    get expiresAt(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export declare class DataGitlabGroupMembershipMembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupMembershipMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership gitlab_group_membership}
*/
export declare class DataGitlabGroupMembership extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_membership";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupMembership resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupMembership to import
    * @param importFromId The id of the existing DataGitlabGroupMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group_membership gitlab_group_membership} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupMembershipConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabGroupMembershipConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _fullPath?;
    get fullPath(): string;
    set fullPath(value: string);
    resetFullPath(): void;
    get fullPathInput(): string | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get id(): string;
    private _inherited?;
    get inherited(): boolean | cdktf.IResolvable;
    set inherited(value: boolean | cdktf.IResolvable);
    resetInherited(): void;
    get inheritedInput(): boolean | cdktf.IResolvable | undefined;
    private _members;
    get members(): DataGitlabGroupMembershipMembersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
