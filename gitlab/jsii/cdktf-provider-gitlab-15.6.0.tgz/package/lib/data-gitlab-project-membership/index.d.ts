/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectMembershipConfig extends cdktf.TerraformMetaArguments {
    /**
    * The full path of the project. Use `project` instead. Will be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#full_path DataGitlabProjectMembership#full_path}
    */
    readonly fullPath?: string;
    /**
    * Return all project members including members through ancestor groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#inherited DataGitlabProjectMembership#inherited}
    */
    readonly inherited?: boolean | cdktf.IResolvable;
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#project DataGitlabProjectMembership#project}
    */
    readonly project?: string;
    /**
    * The ID of the project. Use `project` instead. Will be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#project_id DataGitlabProjectMembership#project_id}
    */
    readonly projectId?: number;
    /**
    * A query string to search for members
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#query DataGitlabProjectMembership#query}
    */
    readonly query?: string;
    /**
    * List of user ids to filter members by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#user_ids DataGitlabProjectMembership#user_ids}
    */
    readonly userIds?: number[];
}
export interface DataGitlabProjectMembershipMembers {
}
export declare function dataGitlabProjectMembershipMembersToTerraform(struct?: DataGitlabProjectMembershipMembers): any;
export declare function dataGitlabProjectMembershipMembersToHclTerraform(struct?: DataGitlabProjectMembershipMembers): any;
export declare class DataGitlabProjectMembershipMembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectMembershipMembers | undefined;
    set internalValue(value: DataGitlabProjectMembershipMembers | undefined);
    get accessLevel(): string;
    get avatarUrl(): string;
    get expiresAt(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export declare class DataGitlabProjectMembershipMembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectMembershipMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership gitlab_project_membership}
*/
export declare class DataGitlabProjectMembership extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_membership";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectMembership resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectMembership to import
    * @param importFromId The id of the existing DataGitlabProjectMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_membership gitlab_project_membership} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectMembershipConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabProjectMembershipConfig);
    private _fullPath?;
    get fullPath(): string;
    set fullPath(value: string);
    resetFullPath(): void;
    get fullPathInput(): string | undefined;
    get id(): string;
    private _inherited?;
    get inherited(): boolean | cdktf.IResolvable;
    set inherited(value: boolean | cdktf.IResolvable);
    resetInherited(): void;
    get inheritedInput(): boolean | cdktf.IResolvable | undefined;
    private _members;
    get members(): DataGitlabProjectMembershipMembersList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _projectId?;
    get projectId(): number;
    set projectId(value: number);
    resetProjectId(): void;
    get projectIdInput(): number | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _userIds?;
    get userIds(): number[];
    set userIds(value: number[]);
    resetUserIds(): void;
    get userIdsInput(): number[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
