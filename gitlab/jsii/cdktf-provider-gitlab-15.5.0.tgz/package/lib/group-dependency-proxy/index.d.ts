/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupDependencyProxyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Indicates whether the proxy is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy#enabled GroupDependencyProxy#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The ID or URL-encoded path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy#group GroupDependencyProxy#group}
    */
    readonly group: string;
    /**
    * Identity credential used to authenticate with Docker Hub when pulling images. Can be a username (for password or personal access token (PAT)) or organization name (for organization access token (OAT)).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy#identity GroupDependencyProxy#identity}
    */
    readonly identity?: string;
    /**
    * Secret credential used to authenticate with Docker Hub when pulling images. Can be a password, personal access token (PAT), or organization access token (OAT). Cannot be imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy#secret GroupDependencyProxy#secret}
    */
    readonly secret?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy gitlab_group_dependency_proxy}
*/
export declare class GroupDependencyProxy extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_dependency_proxy";
    /**
    * Generates CDKTF code for importing a GroupDependencyProxy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupDependencyProxy to import
    * @param importFromId The id of the existing GroupDependencyProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupDependencyProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_dependency_proxy gitlab_group_dependency_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupDependencyProxyConfig
    */
    constructor(scope: Construct, id: string, config: GroupDependencyProxyConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    resetSecret(): void;
    get secretInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
