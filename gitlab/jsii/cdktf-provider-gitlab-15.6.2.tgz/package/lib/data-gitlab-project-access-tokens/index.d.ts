/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectAccessTokensConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name or id of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/project_access_tokens#project DataGitlabProjectAccessTokens#project}
    */
    readonly project: string;
    /**
    * List all project access token that match the specified state. Valid values are `active`, `inactive`. Returns all project access token if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/project_access_tokens#state DataGitlabProjectAccessTokens#state}
    */
    readonly state?: string;
}
export interface DataGitlabProjectAccessTokensAccessTokens {
}
export declare function dataGitlabProjectAccessTokensAccessTokensToTerraform(struct?: DataGitlabProjectAccessTokensAccessTokens): any;
export declare function dataGitlabProjectAccessTokensAccessTokensToHclTerraform(struct?: DataGitlabProjectAccessTokensAccessTokens): any;
export declare class DataGitlabProjectAccessTokensAccessTokensOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectAccessTokensAccessTokens | undefined;
    set internalValue(value: DataGitlabProjectAccessTokensAccessTokens | undefined);
    get accessLevel(): string;
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get description(): string;
    get expiresAt(): string;
    get id(): string;
    get lastUsedAt(): string;
    get name(): string;
    get project(): string;
    get revoked(): cdktf.IResolvable;
    get scopes(): string[];
    get userId(): number;
}
export declare class DataGitlabProjectAccessTokensAccessTokensList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectAccessTokensAccessTokensOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/project_access_tokens gitlab_project_access_tokens}
*/
export declare class DataGitlabProjectAccessTokens extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_access_tokens";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectAccessTokens resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectAccessTokens to import
    * @param importFromId The id of the existing DataGitlabProjectAccessTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/project_access_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectAccessTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/project_access_tokens gitlab_project_access_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectAccessTokensConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectAccessTokensConfig);
    private _accessTokens;
    get accessTokens(): DataGitlabProjectAccessTokensAccessTokensList;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
