/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectLevelMrApprovalsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Set to `true` to disable overriding approvers per merge request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#disable_overriding_approvers_per_merge_request ProjectLevelMrApprovals#disable_overriding_approvers_per_merge_request}
    */
    readonly disableOverridingApproversPerMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Set to `true` to allow merge requests authors to approve their own merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#merge_requests_author_approval ProjectLevelMrApprovals#merge_requests_author_approval}
    */
    readonly mergeRequestsAuthorApproval?: boolean | cdktf.IResolvable;
    /**
    * Set to `true` to disable merge request committers from approving their own merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#merge_requests_disable_committers_approval ProjectLevelMrApprovals#merge_requests_disable_committers_approval}
    */
    readonly mergeRequestsDisableCommittersApproval?: boolean | cdktf.IResolvable;
    /**
    * The ID or URL-encoded path of a project to change MR approval configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#project ProjectLevelMrApprovals#project}
    */
    readonly project: string;
    /**
    * Set to `true` to require authentication to approve merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#require_password_to_approve ProjectLevelMrApprovals#require_password_to_approve}
    */
    readonly requirePasswordToApprove?: boolean | cdktf.IResolvable;
    /**
    * Set to `true` to remove all approvals in a merge request when new commits are pushed to its source branch. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#reset_approvals_on_push ProjectLevelMrApprovals#reset_approvals_on_push}
    */
    readonly resetApprovalsOnPush?: boolean | cdktf.IResolvable;
    /**
    * Reset approvals from Code Owners if their files changed. Can be enabled only if reset_approvals_on_push is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#selective_code_owner_removals ProjectLevelMrApprovals#selective_code_owner_removals}
    */
    readonly selectiveCodeOwnerRemovals?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals gitlab_project_level_mr_approvals}
*/
export declare class ProjectLevelMrApprovals extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_level_mr_approvals";
    /**
    * Generates CDKTF code for importing a ProjectLevelMrApprovals resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectLevelMrApprovals to import
    * @param importFromId The id of the existing ProjectLevelMrApprovals that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectLevelMrApprovals to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_level_mr_approvals gitlab_project_level_mr_approvals} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectLevelMrApprovalsConfig
    */
    constructor(scope: Construct, id: string, config: ProjectLevelMrApprovalsConfig);
    private _disableOverridingApproversPerMergeRequest?;
    get disableOverridingApproversPerMergeRequest(): boolean | cdktf.IResolvable;
    set disableOverridingApproversPerMergeRequest(value: boolean | cdktf.IResolvable);
    resetDisableOverridingApproversPerMergeRequest(): void;
    get disableOverridingApproversPerMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _mergeRequestsAuthorApproval?;
    get mergeRequestsAuthorApproval(): boolean | cdktf.IResolvable;
    set mergeRequestsAuthorApproval(value: boolean | cdktf.IResolvable);
    resetMergeRequestsAuthorApproval(): void;
    get mergeRequestsAuthorApprovalInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestsDisableCommittersApproval?;
    get mergeRequestsDisableCommittersApproval(): boolean | cdktf.IResolvable;
    set mergeRequestsDisableCommittersApproval(value: boolean | cdktf.IResolvable);
    resetMergeRequestsDisableCommittersApproval(): void;
    get mergeRequestsDisableCommittersApprovalInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _requirePasswordToApprove?;
    get requirePasswordToApprove(): boolean | cdktf.IResolvable;
    set requirePasswordToApprove(value: boolean | cdktf.IResolvable);
    resetRequirePasswordToApprove(): void;
    get requirePasswordToApproveInput(): boolean | cdktf.IResolvable | undefined;
    private _resetApprovalsOnPush?;
    get resetApprovalsOnPush(): boolean | cdktf.IResolvable;
    set resetApprovalsOnPush(value: boolean | cdktf.IResolvable);
    resetResetApprovalsOnPush(): void;
    get resetApprovalsOnPushInput(): boolean | cdktf.IResolvable | undefined;
    private _selectiveCodeOwnerRemovals?;
    get selectiveCodeOwnerRemovals(): boolean | cdktf.IResolvable;
    set selectiveCodeOwnerRemovals(value: boolean | cdktf.IResolvable);
    resetSelectiveCodeOwnerRemovals(): void;
    get selectiveCodeOwnerRemovalsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
