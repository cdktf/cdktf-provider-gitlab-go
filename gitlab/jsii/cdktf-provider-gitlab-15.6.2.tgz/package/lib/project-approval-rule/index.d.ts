/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectApprovalRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether the rule is applied to all protected branches. If set to 'true', the value of `protected_branch_ids` is ignored. Default is 'false'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#applies_to_all_protected_branches ProjectApprovalRule#applies_to_all_protected_branches}
    */
    readonly appliesToAllProtectedBranches?: boolean | cdktf.IResolvable;
    /**
    * The number of approvals required for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#approvals_required ProjectApprovalRule#approvals_required}
    */
    readonly approvalsRequired: number;
    /**
    * When this flag is set, the default `any_approver` rule will not be imported if present.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#disable_importing_default_any_approver_rule_on_create ProjectApprovalRule#disable_importing_default_any_approver_rule_on_create}
    */
    readonly disableImportingDefaultAnyApproverRuleOnCreate?: boolean | cdktf.IResolvable;
    /**
    * A list of group IDs whose members can approve of the merge request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#group_ids ProjectApprovalRule#group_ids}
    */
    readonly groupIds?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#id ProjectApprovalRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the approval rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#name ProjectApprovalRule#name}
    */
    readonly name: string;
    /**
    * The name or id of the project to add the approval rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#project ProjectApprovalRule#project}
    */
    readonly project: string;
    /**
    * A list of protected branch IDs (not branch names) for which the rule applies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#protected_branch_ids ProjectApprovalRule#protected_branch_ids}
    */
    readonly protectedBranchIds?: number[];
    /**
    * Report type is required when the rule_type is `report_approver`. Valid values are `code_coverage`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#report_type ProjectApprovalRule#report_type}
    */
    readonly reportType?: string;
    /**
    * String, defaults to 'regular'. The type of rule. `any_approver` is a pre-configured default rule with `approvals_required` at `0`. Valid values are `regular`, `any_approver`, `report_approver`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#rule_type ProjectApprovalRule#rule_type}
    */
    readonly ruleType?: string;
    /**
    * A list of specific User IDs to add to the list of approvers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#user_ids ProjectApprovalRule#user_ids}
    */
    readonly userIds?: number[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule gitlab_project_approval_rule}
*/
export declare class ProjectApprovalRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_approval_rule";
    /**
    * Generates CDKTF code for importing a ProjectApprovalRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectApprovalRule to import
    * @param importFromId The id of the existing ProjectApprovalRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectApprovalRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_approval_rule gitlab_project_approval_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectApprovalRuleConfig
    */
    constructor(scope: Construct, id: string, config: ProjectApprovalRuleConfig);
    private _appliesToAllProtectedBranches?;
    get appliesToAllProtectedBranches(): boolean | cdktf.IResolvable;
    set appliesToAllProtectedBranches(value: boolean | cdktf.IResolvable);
    resetAppliesToAllProtectedBranches(): void;
    get appliesToAllProtectedBranchesInput(): boolean | cdktf.IResolvable | undefined;
    private _approvalsRequired?;
    get approvalsRequired(): number;
    set approvalsRequired(value: number);
    get approvalsRequiredInput(): number | undefined;
    private _disableImportingDefaultAnyApproverRuleOnCreate?;
    get disableImportingDefaultAnyApproverRuleOnCreate(): boolean | cdktf.IResolvable;
    set disableImportingDefaultAnyApproverRuleOnCreate(value: boolean | cdktf.IResolvable);
    resetDisableImportingDefaultAnyApproverRuleOnCreate(): void;
    get disableImportingDefaultAnyApproverRuleOnCreateInput(): boolean | cdktf.IResolvable | undefined;
    private _groupIds?;
    get groupIds(): number[];
    set groupIds(value: number[]);
    resetGroupIds(): void;
    get groupIdsInput(): number[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _protectedBranchIds?;
    get protectedBranchIds(): number[];
    set protectedBranchIds(value: number[]);
    resetProtectedBranchIds(): void;
    get protectedBranchIdsInput(): number[] | undefined;
    private _reportType?;
    get reportType(): string;
    set reportType(value: string);
    resetReportType(): void;
    get reportTypeInput(): string | undefined;
    private _ruleType?;
    get ruleType(): string;
    set ruleType(value: string);
    resetRuleType(): void;
    get ruleTypeInput(): string | undefined;
    private _userIds?;
    get userIds(): number[];
    set userIds(value: number[]);
    resetUserIds(): void;
    get userIdsInput(): number[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
