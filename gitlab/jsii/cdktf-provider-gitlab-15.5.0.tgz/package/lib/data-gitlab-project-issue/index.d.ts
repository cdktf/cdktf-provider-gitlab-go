/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectIssueConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue#id DataGitlabProjectIssue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The internal ID of the project's issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue#iid DataGitlabProjectIssue#iid}
    */
    readonly iid: number;
    /**
    * The name or ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue#project DataGitlabProjectIssue#project}
    */
    readonly project: string;
}
export interface DataGitlabProjectIssueTaskCompletionStatus {
}
export declare function dataGitlabProjectIssueTaskCompletionStatusToTerraform(struct?: DataGitlabProjectIssueTaskCompletionStatus): any;
export declare function dataGitlabProjectIssueTaskCompletionStatusToHclTerraform(struct?: DataGitlabProjectIssueTaskCompletionStatus): any;
export declare class DataGitlabProjectIssueTaskCompletionStatusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectIssueTaskCompletionStatus | undefined;
    set internalValue(value: DataGitlabProjectIssueTaskCompletionStatus | undefined);
    get completedCount(): number;
    get count(): number;
}
export declare class DataGitlabProjectIssueTaskCompletionStatusList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectIssueTaskCompletionStatusOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue gitlab_project_issue}
*/
export declare class DataGitlabProjectIssue extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_issue";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectIssue resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectIssue to import
    * @param importFromId The id of the existing DataGitlabProjectIssue that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectIssue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_issue gitlab_project_issue} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectIssueConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectIssueConfig);
    get assigneeIds(): number[];
    get authorId(): number;
    get closedAt(): string;
    get closedByUserId(): number;
    get confidential(): cdktf.IResolvable;
    get createdAt(): string;
    get description(): string;
    get discussionLocked(): cdktf.IResolvable;
    get discussionToResolve(): string;
    get downvotes(): number;
    get dueDate(): string;
    get epicId(): number;
    get epicIssueId(): number;
    get externalId(): string;
    get humanTimeEstimate(): string;
    get humanTotalTimeSpent(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _iid?;
    get iid(): number;
    set iid(value: number);
    get iidInput(): number | undefined;
    get issueId(): number;
    get issueLinkId(): number;
    get issueType(): string;
    get labels(): string[];
    private _links;
    get links(): cdktf.StringMap;
    get mergeRequestToResolveDiscussionsOf(): number;
    get mergeRequestsCount(): number;
    get milestoneId(): number;
    get movedToId(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _references;
    get references(): cdktf.StringMap;
    get state(): string;
    get subscribed(): cdktf.IResolvable;
    private _taskCompletionStatus;
    get taskCompletionStatus(): DataGitlabProjectIssueTaskCompletionStatusList;
    get timeEstimate(): number;
    get title(): string;
    get totalTimeSpent(): number;
    get updatedAt(): string;
    get upvotes(): number;
    get userNotesCount(): number;
    get webUrl(): string;
    get weight(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
