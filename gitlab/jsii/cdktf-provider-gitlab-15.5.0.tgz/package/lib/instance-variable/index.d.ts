/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface InstanceVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the variable. Maximum of 255 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#description InstanceVariable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#id InstanceVariable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#key InstanceVariable#key}
    */
    readonly key: string;
    /**
    * If set to `true`, the value of the variable will be hidden in job logs. The value must meet the [masking requirements](https://docs.gitlab.com/ci/variables/#masked-variables). Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#masked InstanceVariable#masked}
    */
    readonly masked?: boolean | cdktf.IResolvable;
    /**
    * If set to `true`, the variable will be passed only to pipelines running on protected branches and tags. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#protected InstanceVariable#protected}
    */
    readonly protected?: boolean | cdktf.IResolvable;
    /**
    * Whether the variable is treated as a raw string. Default: false. When true, variables in the value are not expanded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#raw InstanceVariable#raw}
    */
    readonly raw?: boolean | cdktf.IResolvable;
    /**
    * The value of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#value InstanceVariable#value}
    */
    readonly value: string;
    /**
    * The type of a variable. Valid values are: `env_var`, `file`. Default is `env_var`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#variable_type InstanceVariable#variable_type}
    */
    readonly variableType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable gitlab_instance_variable}
*/
export declare class InstanceVariable extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_instance_variable";
    /**
    * Generates CDKTF code for importing a InstanceVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the InstanceVariable to import
    * @param importFromId The id of the existing InstanceVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the InstanceVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_variable gitlab_instance_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InstanceVariableConfig
    */
    constructor(scope: Construct, id: string, config: InstanceVariableConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _masked?;
    get masked(): boolean | cdktf.IResolvable;
    set masked(value: boolean | cdktf.IResolvable);
    resetMasked(): void;
    get maskedInput(): boolean | cdktf.IResolvable | undefined;
    private _protected?;
    get protected(): boolean | cdktf.IResolvable;
    set protected(value: boolean | cdktf.IResolvable);
    resetProtected(): void;
    get protectedInput(): boolean | cdktf.IResolvable | undefined;
    private _raw?;
    get raw(): boolean | cdktf.IResolvable;
    set raw(value: boolean | cdktf.IResolvable);
    resetRaw(): void;
    get rawInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    resetVariableType(): void;
    get variableTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
