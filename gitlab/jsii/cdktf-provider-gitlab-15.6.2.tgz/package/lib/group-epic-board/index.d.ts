/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupEpicBoardConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or URL-encoded path of the group owned by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board#group GroupEpicBoard#group}
    */
    readonly group: string;
    /**
    * The name of the board.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board#name GroupEpicBoard#name}
    */
    readonly name: string;
    /**
    * lists block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board#lists GroupEpicBoard#lists}
    */
    readonly lists?: GroupEpicBoardLists[] | cdktf.IResolvable;
}
export interface GroupEpicBoardLists {
    /**
    * The ID of the label the list should be scoped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board#label_id GroupEpicBoard#label_id}
    */
    readonly labelId?: number;
}
export declare function groupEpicBoardListsToTerraform(struct?: GroupEpicBoardLists | cdktf.IResolvable): any;
export declare function groupEpicBoardListsToHclTerraform(struct?: GroupEpicBoardLists | cdktf.IResolvable): any;
export declare class GroupEpicBoardListsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupEpicBoardLists | cdktf.IResolvable | undefined;
    set internalValue(value: GroupEpicBoardLists | cdktf.IResolvable | undefined);
    get id(): number;
    private _labelId?;
    get labelId(): number;
    set labelId(value: number);
    resetLabelId(): void;
    get labelIdInput(): number | undefined;
    get position(): number;
}
export declare class GroupEpicBoardListsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GroupEpicBoardLists[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupEpicBoardListsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board gitlab_group_epic_board}
*/
export declare class GroupEpicBoard extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_epic_board";
    /**
    * Generates CDKTF code for importing a GroupEpicBoard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupEpicBoard to import
    * @param importFromId The id of the existing GroupEpicBoard that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupEpicBoard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_epic_board gitlab_group_epic_board} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupEpicBoardConfig
    */
    constructor(scope: Construct, id: string, config: GroupEpicBoardConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _lists;
    get lists(): GroupEpicBoardListsList;
    putLists(value: GroupEpicBoardLists[] | cdktf.IResolvable): void;
    resetLists(): void;
    get listsInput(): cdktf.IResolvable | GroupEpicBoardLists[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
