/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectProtectedBranchConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the protected branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#name DataGitlabProjectProtectedBranch#name}
    */
    readonly name: string;
    /**
    * The integer or path with namespace that uniquely identifies the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#project_id DataGitlabProjectProtectedBranch#project_id}
    */
    readonly projectId: string;
    /**
    * merge_access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#merge_access_levels DataGitlabProjectProtectedBranch#merge_access_levels}
    */
    readonly mergeAccessLevels?: DataGitlabProjectProtectedBranchMergeAccessLevels[] | cdktf.IResolvable;
    /**
    * push_access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#push_access_levels DataGitlabProjectProtectedBranch#push_access_levels}
    */
    readonly pushAccessLevels?: DataGitlabProjectProtectedBranchPushAccessLevels[] | cdktf.IResolvable;
}
export interface DataGitlabProjectProtectedBranchMergeAccessLevels {
    /**
    * The ID of a GitLab group allowed to perform the relevant action. Mutually exclusive with `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#group_id DataGitlabProjectProtectedBranch#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action. Mutually exclusive with `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#user_id DataGitlabProjectProtectedBranch#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedBranchMergeAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedBranchMergeAccessLevels | cdktf.IResolvable): any;
export declare function dataGitlabProjectProtectedBranchMergeAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedBranchMergeAccessLevels | cdktf.IResolvable): any;
export declare class DataGitlabProjectProtectedBranchMergeAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedBranchMergeAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectProtectedBranchMergeAccessLevels | cdktf.IResolvable | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedBranchMergeAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedBranchMergeAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedBranchMergeAccessLevelsOutputReference;
}
export interface DataGitlabProjectProtectedBranchPushAccessLevels {
    /**
    * The ID of a GitLab deploy key allowed to perform the relevant action. Mutually exclusive with `group_id` and `user_id`. This field is read-only until Gitlab 17.5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#deploy_key_id DataGitlabProjectProtectedBranch#deploy_key_id}
    */
    readonly deployKeyId?: number;
    /**
    * The ID of a GitLab group allowed to perform the relevant action. Mutually exclusive with `deploy_key_id` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#group_id DataGitlabProjectProtectedBranch#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action. Mutually exclusive with `deploy_key_id` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#user_id DataGitlabProjectProtectedBranch#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedBranchPushAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedBranchPushAccessLevels | cdktf.IResolvable): any;
export declare function dataGitlabProjectProtectedBranchPushAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedBranchPushAccessLevels | cdktf.IResolvable): any;
export declare class DataGitlabProjectProtectedBranchPushAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedBranchPushAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectProtectedBranchPushAccessLevels | cdktf.IResolvable | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _deployKeyId?;
    get deployKeyId(): number;
    set deployKeyId(value: number);
    resetDeployKeyId(): void;
    get deployKeyIdInput(): number | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedBranchPushAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedBranchPushAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedBranchPushAccessLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch gitlab_project_protected_branch}
*/
export declare class DataGitlabProjectProtectedBranch extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_protected_branch";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectProtectedBranch resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectProtectedBranch to import
    * @param importFromId The id of the existing DataGitlabProjectProtectedBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectProtectedBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branch gitlab_project_protected_branch} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectProtectedBranchConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectProtectedBranchConfig);
    get allowForcePush(): cdktf.IResolvable;
    get codeOwnerApprovalRequired(): cdktf.IResolvable;
    get id(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _mergeAccessLevels;
    get mergeAccessLevels(): DataGitlabProjectProtectedBranchMergeAccessLevelsList;
    putMergeAccessLevels(value: DataGitlabProjectProtectedBranchMergeAccessLevels[] | cdktf.IResolvable): void;
    resetMergeAccessLevels(): void;
    get mergeAccessLevelsInput(): cdktf.IResolvable | DataGitlabProjectProtectedBranchMergeAccessLevels[] | undefined;
    private _pushAccessLevels;
    get pushAccessLevels(): DataGitlabProjectProtectedBranchPushAccessLevelsList;
    putPushAccessLevels(value: DataGitlabProjectProtectedBranchPushAccessLevels[] | cdktf.IResolvable): void;
    resetPushAccessLevels(): void;
    get pushAccessLevelsInput(): cdktf.IResolvable | DataGitlabProjectProtectedBranchPushAccessLevels[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
