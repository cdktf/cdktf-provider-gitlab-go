/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectIntegrationJenkinsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Enable SSL verification. Defaults to `true` (enabled).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#enable_ssl_verification ProjectIntegrationJenkins#enable_ssl_verification}
    */
    readonly enableSslVerification?: boolean | cdktf.IResolvable;
    /**
    * Jenkins URL like `http://jenkins.example.com`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#jenkins_url ProjectIntegrationJenkins#jenkins_url}
    */
    readonly jenkinsUrl: string;
    /**
    * Enable notifications for merge request events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#merge_request_events ProjectIntegrationJenkins#merge_request_events}
    */
    readonly mergeRequestEvents?: boolean | cdktf.IResolvable;
    /**
    * Password for authentication with the Jenkins server, if authentication is required by the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#password ProjectIntegrationJenkins#password}
    */
    readonly password?: string;
    /**
    * ID of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#project ProjectIntegrationJenkins#project}
    */
    readonly project: string;
    /**
    * The URL-friendly project name. Example: `my_project_name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#project_name ProjectIntegrationJenkins#project_name}
    */
    readonly projectName: string;
    /**
    * Enable notifications for push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#push_events ProjectIntegrationJenkins#push_events}
    */
    readonly pushEvents?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for tag push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#tag_push_events ProjectIntegrationJenkins#tag_push_events}
    */
    readonly tagPushEvents?: boolean | cdktf.IResolvable;
    /**
    * Username for authentication with the Jenkins server, if authentication is required by the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#username ProjectIntegrationJenkins#username}
    */
    readonly username?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins gitlab_project_integration_jenkins}
*/
export declare class ProjectIntegrationJenkins extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_integration_jenkins";
    /**
    * Generates CDKTF code for importing a ProjectIntegrationJenkins resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectIntegrationJenkins to import
    * @param importFromId The id of the existing ProjectIntegrationJenkins that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectIntegrationJenkins to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_jenkins gitlab_project_integration_jenkins} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectIntegrationJenkinsConfig
    */
    constructor(scope: Construct, id: string, config: ProjectIntegrationJenkinsConfig);
    get active(): cdktf.IResolvable;
    private _enableSslVerification?;
    get enableSslVerification(): boolean | cdktf.IResolvable;
    set enableSslVerification(value: boolean | cdktf.IResolvable);
    resetEnableSslVerification(): void;
    get enableSslVerificationInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _jenkinsUrl?;
    get jenkinsUrl(): string;
    set jenkinsUrl(value: string);
    get jenkinsUrlInput(): string | undefined;
    private _mergeRequestEvents?;
    get mergeRequestEvents(): boolean | cdktf.IResolvable;
    set mergeRequestEvents(value: boolean | cdktf.IResolvable);
    resetMergeRequestEvents(): void;
    get mergeRequestEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _pushEvents?;
    get pushEvents(): boolean | cdktf.IResolvable;
    set pushEvents(value: boolean | cdktf.IResolvable);
    resetPushEvents(): void;
    get pushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _tagPushEvents?;
    get tagPushEvents(): boolean | cdktf.IResolvable;
    set tagPushEvents(value: boolean | cdktf.IResolvable);
    resetTagPushEvents(): void;
    get tagPushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
