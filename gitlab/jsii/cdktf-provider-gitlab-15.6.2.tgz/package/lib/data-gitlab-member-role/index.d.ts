/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabMemberRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Globally unique ID of the member role. In the format of `gid://gitlab/MemberRole/1`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/member_role#id DataGitlabMemberRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/member_role gitlab_member_role}
*/
export declare class DataGitlabMemberRole extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_member_role";
    /**
    * Generates CDKTF code for importing a DataGitlabMemberRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabMemberRole to import
    * @param importFromId The id of the existing DataGitlabMemberRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/member_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabMemberRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/member_role gitlab_member_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabMemberRoleConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabMemberRoleConfig);
    get baseAccessLevel(): string;
    get createdAt(): string;
    get description(): string;
    get editPath(): string;
    get enabledPermissions(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get iid(): number;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
