/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The full path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group#full_path DataGitlabGroup#full_path}
    */
    readonly fullPath?: string;
    /**
    * The ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group#group_id DataGitlabGroup#group_id}
    */
    readonly groupId?: number;
}
export interface DataGitlabGroupSharedWithGroups {
}
export declare function dataGitlabGroupSharedWithGroupsToTerraform(struct?: DataGitlabGroupSharedWithGroups): any;
export declare function dataGitlabGroupSharedWithGroupsToHclTerraform(struct?: DataGitlabGroupSharedWithGroups): any;
export declare class DataGitlabGroupSharedWithGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupSharedWithGroups | undefined;
    set internalValue(value: DataGitlabGroupSharedWithGroups | undefined);
    get expiresAt(): string;
    get groupAccessLevel(): number;
    get groupFullPath(): string;
    get groupId(): number;
    get groupName(): string;
}
export declare class DataGitlabGroupSharedWithGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupSharedWithGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group gitlab_group}
*/
export declare class DataGitlabGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group";
    /**
    * Generates CDKTF code for importing a DataGitlabGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroup to import
    * @param importFromId The id of the existing DataGitlabGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/group gitlab_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabGroupConfig);
    get defaultBranch(): string;
    get defaultBranchProtection(): number;
    get description(): string;
    get extraSharedRunnersMinutesLimit(): number;
    get fullName(): string;
    private _fullPath?;
    get fullPath(): string;
    set fullPath(value: string);
    resetFullPath(): void;
    get fullPathInput(): string | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get id(): string;
    get lfsEnabled(): cdktf.IResolvable;
    get membershipLock(): cdktf.IResolvable;
    get name(): string;
    get parentId(): number;
    get path(): string;
    get preventForkingOutsideGroup(): cdktf.IResolvable;
    get requestAccessEnabled(): cdktf.IResolvable;
    get runnersToken(): string;
    get sharedRunnersMinutesLimit(): number;
    get sharedRunnersSetting(): string;
    private _sharedWithGroups;
    get sharedWithGroups(): DataGitlabGroupSharedWithGroupsList;
    get visibilityLevel(): string;
    get webUrl(): string;
    get wikiAccessLevel(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
