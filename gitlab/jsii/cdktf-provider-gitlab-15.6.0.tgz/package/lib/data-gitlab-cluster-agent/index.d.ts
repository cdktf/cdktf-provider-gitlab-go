/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabClusterAgentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/cluster_agent#agent_id DataGitlabClusterAgent#agent_id}
    */
    readonly agentId: number;
    /**
    * ID or full path of the project maintained by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/cluster_agent#project DataGitlabClusterAgent#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/cluster_agent gitlab_cluster_agent}
*/
export declare class DataGitlabClusterAgent extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_cluster_agent";
    /**
    * Generates CDKTF code for importing a DataGitlabClusterAgent resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabClusterAgent to import
    * @param importFromId The id of the existing DataGitlabClusterAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/cluster_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabClusterAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/cluster_agent gitlab_cluster_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabClusterAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabClusterAgentConfig);
    private _agentId?;
    get agentId(): number;
    set agentId(value: number);
    get agentIdInput(): number | undefined;
    get createdAt(): string;
    get createdByUserId(): number;
    get id(): string;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
