/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationCustomIssueTrackerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The URL to view an issue in the external issue tracker. Must contain :id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker#issues_url IntegrationCustomIssueTracker#issues_url}
    */
    readonly issuesUrl: string;
    /**
    * The ID or full path of the project for the custom issue tracker.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker#project IntegrationCustomIssueTracker#project}
    */
    readonly project: string;
    /**
    * The URL to the project in the external issue tracker.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker#project_url IntegrationCustomIssueTracker#project_url}
    */
    readonly projectUrl: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker gitlab_integration_custom_issue_tracker}
*/
export declare class IntegrationCustomIssueTracker extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_integration_custom_issue_tracker";
    /**
    * Generates CDKTF code for importing a IntegrationCustomIssueTracker resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationCustomIssueTracker to import
    * @param importFromId The id of the existing IntegrationCustomIssueTracker that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationCustomIssueTracker to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/integration_custom_issue_tracker gitlab_integration_custom_issue_tracker} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationCustomIssueTrackerConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationCustomIssueTrackerConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get id(): string;
    private _issuesUrl?;
    get issuesUrl(): string;
    set issuesUrl(value: string);
    get issuesUrlInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectUrl?;
    get projectUrl(): string;
    set projectUrl(value: string);
    get projectUrlInput(): string | undefined;
    get slug(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
