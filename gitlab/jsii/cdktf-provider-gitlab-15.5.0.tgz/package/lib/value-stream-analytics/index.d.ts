/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ValueStreamAnalyticsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Full path of the group the value stream is created in. **One of `group_full_path` OR `project_full_path` is required.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#group_full_path ValueStreamAnalytics#group_full_path}
    */
    readonly groupFullPath?: string;
    /**
    * The name of the value stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#name ValueStreamAnalytics#name}
    */
    readonly name: string;
    /**
    * Full path of the project the value stream is created in. **One of `group_full_path` OR `project_full_path` is required.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#project_full_path ValueStreamAnalytics#project_full_path}
    */
    readonly projectFullPath?: string;
    /**
    * Stages of the value stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#stages ValueStreamAnalytics#stages}
    */
    readonly stages: ValueStreamAnalyticsStages[] | cdktf.IResolvable;
}
export interface ValueStreamAnalyticsStages {
    /**
    * Boolean whether the stage is customized. If false, it assigns a built-in default stage by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#custom ValueStreamAnalytics#custom}
    */
    readonly custom?: boolean | cdktf.IResolvable;
    /**
    * End event identifier. Valid values are: `CODE_STAGE_START`, `ISSUE_CLOSED`, `ISSUE_CREATED`, `ISSUE_DEPLOYED_TO_PRODUCTION`, `ISSUE_FIRST_ADDED_TO_BOARD`, `ISSUE_FIRST_ADDED_TO_ITERATION`, `ISSUE_FIRST_ASSIGNED_AT`, `ISSUE_FIRST_ASSOCIATED_WITH_MILESTONE`, `ISSUE_FIRST_MENTIONED_IN_COMMIT`, `ISSUE_LABEL_ADDED`, `ISSUE_LABEL_REMOVED`, `ISSUE_LAST_EDITED`, `ISSUE_STAGE_END`, `MERGE_REQUEST_CLOSED`, `MERGE_REQUEST_CREATED`, `MERGE_REQUEST_FIRST_ASSIGNED_AT`, `MERGE_REQUEST_FIRST_COMMIT_AT`, `MERGE_REQUEST_FIRST_DEPLOYED_TO_PRODUCTION`, `MERGE_REQUEST_LABEL_ADDED`, `MERGE_REQUEST_LABEL_REMOVED`, `MERGE_REQUEST_LAST_BUILD_FINISHED`, `MERGE_REQUEST_LAST_BUILD_STARTED`, `MERGE_REQUEST_LAST_EDITED`, `MERGE_REQUEST_MERGED`, `MERGE_REQUEST_REVIEWER_FIRST_ASSIGNED`, `MERGE_REQUEST_PLAN_STAGE_START`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#end_event_identifier ValueStreamAnalytics#end_event_identifier}
    */
    readonly endEventIdentifier?: string;
    /**
    * Label ID associated with the end event identifier. In the format of `gid://gitlab/GroupLabel/<id>` or `gid://gitlab/ProjectLabel/<id>`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#end_event_label_id ValueStreamAnalytics#end_event_label_id}
    */
    readonly endEventLabelId?: string;
    /**
    * Boolean whether the stage is hidden, GitLab provided default stages are hidden by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#hidden ValueStreamAnalytics#hidden}
    */
    readonly hidden?: boolean | cdktf.IResolvable;
    /**
    * The name of the value stream stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#name ValueStreamAnalytics#name}
    */
    readonly name: string;
    /**
    * Start event identifier. Valid values are: `CODE_STAGE_START`, `ISSUE_CLOSED`, `ISSUE_CREATED`, `ISSUE_DEPLOYED_TO_PRODUCTION`, `ISSUE_FIRST_ADDED_TO_BOARD`, `ISSUE_FIRST_ADDED_TO_ITERATION`, `ISSUE_FIRST_ASSIGNED_AT`, `ISSUE_FIRST_ASSOCIATED_WITH_MILESTONE`, `ISSUE_FIRST_MENTIONED_IN_COMMIT`, `ISSUE_LABEL_ADDED`, `ISSUE_LABEL_REMOVED`, `ISSUE_LAST_EDITED`, `ISSUE_STAGE_END`, `MERGE_REQUEST_CLOSED`, `MERGE_REQUEST_CREATED`, `MERGE_REQUEST_FIRST_ASSIGNED_AT`, `MERGE_REQUEST_FIRST_COMMIT_AT`, `MERGE_REQUEST_FIRST_DEPLOYED_TO_PRODUCTION`, `MERGE_REQUEST_LABEL_ADDED`, `MERGE_REQUEST_LABEL_REMOVED`, `MERGE_REQUEST_LAST_BUILD_FINISHED`, `MERGE_REQUEST_LAST_BUILD_STARTED`, `MERGE_REQUEST_LAST_EDITED`, `MERGE_REQUEST_MERGED`, `MERGE_REQUEST_REVIEWER_FIRST_ASSIGNED`, `MERGE_REQUEST_PLAN_STAGE_START`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#start_event_identifier ValueStreamAnalytics#start_event_identifier}
    */
    readonly startEventIdentifier?: string;
    /**
    * Label ID associated with the start event identifier. In the format of `gid://gitlab/GroupLabel/<id>` or `gid://gitlab/ProjectLabel/<id>`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#start_event_label_id ValueStreamAnalytics#start_event_label_id}
    */
    readonly startEventLabelId?: string;
}
export declare function valueStreamAnalyticsStagesToTerraform(struct?: ValueStreamAnalyticsStages | cdktf.IResolvable): any;
export declare function valueStreamAnalyticsStagesToHclTerraform(struct?: ValueStreamAnalyticsStages | cdktf.IResolvable): any;
export declare class ValueStreamAnalyticsStagesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValueStreamAnalyticsStages | cdktf.IResolvable | undefined;
    set internalValue(value: ValueStreamAnalyticsStages | cdktf.IResolvable | undefined);
    private _custom?;
    get custom(): boolean | cdktf.IResolvable;
    set custom(value: boolean | cdktf.IResolvable);
    resetCustom(): void;
    get customInput(): boolean | cdktf.IResolvable | undefined;
    private _endEventIdentifier?;
    get endEventIdentifier(): string;
    set endEventIdentifier(value: string);
    resetEndEventIdentifier(): void;
    get endEventIdentifierInput(): string | undefined;
    private _endEventLabelId?;
    get endEventLabelId(): string;
    set endEventLabelId(value: string);
    resetEndEventLabelId(): void;
    get endEventLabelIdInput(): string | undefined;
    private _hidden?;
    get hidden(): boolean | cdktf.IResolvable;
    set hidden(value: boolean | cdktf.IResolvable);
    resetHidden(): void;
    get hiddenInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _startEventIdentifier?;
    get startEventIdentifier(): string;
    set startEventIdentifier(value: string);
    resetStartEventIdentifier(): void;
    get startEventIdentifierInput(): string | undefined;
    private _startEventLabelId?;
    get startEventLabelId(): string;
    set startEventLabelId(value: string);
    resetStartEventLabelId(): void;
    get startEventLabelIdInput(): string | undefined;
}
export declare class ValueStreamAnalyticsStagesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ValueStreamAnalyticsStages[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValueStreamAnalyticsStagesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics gitlab_value_stream_analytics}
*/
export declare class ValueStreamAnalytics extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_value_stream_analytics";
    /**
    * Generates CDKTF code for importing a ValueStreamAnalytics resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ValueStreamAnalytics to import
    * @param importFromId The id of the existing ValueStreamAnalytics that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ValueStreamAnalytics to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/value_stream_analytics gitlab_value_stream_analytics} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ValueStreamAnalyticsConfig
    */
    constructor(scope: Construct, id: string, config: ValueStreamAnalyticsConfig);
    private _groupFullPath?;
    get groupFullPath(): string;
    set groupFullPath(value: string);
    resetGroupFullPath(): void;
    get groupFullPathInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectFullPath?;
    get projectFullPath(): string;
    set projectFullPath(value: string);
    resetProjectFullPath(): void;
    get projectFullPathInput(): string | undefined;
    private _stages;
    get stages(): ValueStreamAnalyticsStagesList;
    putStages(value: ValueStreamAnalyticsStages[] | cdktf.IResolvable): void;
    get stagesInput(): cdktf.IResolvable | ValueStreamAnalyticsStages[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
