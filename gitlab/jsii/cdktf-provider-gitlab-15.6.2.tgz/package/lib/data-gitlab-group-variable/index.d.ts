/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The environment scope of the variable. Defaults to all environment (`*`). Note that in Community Editions of Gitlab, values other than `*` will cause inconsistent plans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable#environment_scope DataGitlabGroupVariable#environment_scope}
    */
    readonly environmentScope?: string;
    /**
    * The name or id of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable#group DataGitlabGroupVariable#group}
    */
    readonly group: string;
    /**
    * The name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable#key DataGitlabGroupVariable#key}
    */
    readonly key: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable gitlab_group_variable}
*/
export declare class DataGitlabGroupVariable extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_variable";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupVariable to import
    * @param importFromId The id of the existing DataGitlabGroupVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_variable gitlab_group_variable} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupVariableConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupVariableConfig);
    get description(): string;
    private _environmentScope?;
    get environmentScope(): string;
    set environmentScope(value: string);
    resetEnvironmentScope(): void;
    get environmentScopeInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    get masked(): cdktf.IResolvable;
    get protected(): cdktf.IResolvable;
    get raw(): cdktf.IResolvable;
    get value(): string;
    get variableType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
