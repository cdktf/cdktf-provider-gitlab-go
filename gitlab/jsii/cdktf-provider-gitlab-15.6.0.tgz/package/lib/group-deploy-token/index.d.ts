/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupDeployTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * Time the token expires in RFC3339 format. Not set by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#expires_at GroupDeployToken#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The Id or full path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#group GroupDeployToken#group}
    */
    readonly group: string;
    /**
    * A name to describe the deploy token with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#name GroupDeployToken#name}
    */
    readonly name: string;
    /**
    * The scopes of the group deploy token. Valid values are: `read_repository`, `read_registry`, `write_registry`, `read_virtual_registry`, `write_virtual_registry`, `read_package_registry`, `write_package_registry`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#scopes GroupDeployToken#scopes}
    */
    readonly scopes: string[];
    /**
    * A username for the deploy token. Default is `gitlab+deploy-token-{n}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#username GroupDeployToken#username}
    */
    readonly username?: string;
    /**
    * Wether to validate if the expiration date is in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#validate_past_expiration_date GroupDeployToken#validate_past_expiration_date}
    */
    readonly validatePastExpirationDate?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token gitlab_group_deploy_token}
*/
export declare class GroupDeployToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_deploy_token";
    /**
    * Generates CDKTF code for importing a GroupDeployToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupDeployToken to import
    * @param importFromId The id of the existing GroupDeployToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupDeployToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_deploy_token gitlab_group_deploy_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupDeployTokenConfig
    */
    constructor(scope: Construct, id: string, config: GroupDeployTokenConfig);
    get expired(): cdktf.IResolvable;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get revoked(): cdktf.IResolvable;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    get token(): string;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _validatePastExpirationDate?;
    get validatePastExpirationDate(): boolean | cdktf.IResolvable;
    set validatePastExpirationDate(value: boolean | cdktf.IResolvable);
    resetValidatePastExpirationDate(): void;
    get validatePastExpirationDateInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
