/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Default number of revisions for shallow cloning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#ci_default_git_depth DataGitlabProject#ci_default_git_depth}
    */
    readonly ciDefaultGitDepth?: number;
    /**
    * Fields included in the sub claim of the ID Token. Accepts an array starting with project_path. The array might also include ref_type and ref. Defaults to ["project_path", "ref_type", "ref"]. Introduced in GitLab 17.10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#ci_id_token_sub_claim_components DataGitlabProject#ci_id_token_sub_claim_components}
    */
    readonly ciIdTokenSubClaimComponents?: string[];
    /**
    * The integer that uniquely identifies the project within the gitlab install.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#id DataGitlabProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The path of the repository with namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#path_with_namespace DataGitlabProject#path_with_namespace}
    */
    readonly pathWithNamespace?: string;
    /**
    * If true, jobs can be viewed by non-project members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#public_builds DataGitlabProject#public_builds}
    */
    readonly publicBuilds?: boolean | cdktf.IResolvable;
}
export interface DataGitlabProjectContainerExpirationPolicy {
}
export declare function dataGitlabProjectContainerExpirationPolicyToTerraform(struct?: DataGitlabProjectContainerExpirationPolicy): any;
export declare function dataGitlabProjectContainerExpirationPolicyToHclTerraform(struct?: DataGitlabProjectContainerExpirationPolicy): any;
export declare class DataGitlabProjectContainerExpirationPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectContainerExpirationPolicy | undefined;
    set internalValue(value: DataGitlabProjectContainerExpirationPolicy | undefined);
    get cadence(): string;
    get enabled(): cdktf.IResolvable;
    get keepN(): number;
    get nameRegexDelete(): string;
    get nameRegexKeep(): string;
    get nextRunAt(): string;
    get olderThan(): string;
}
export declare class DataGitlabProjectContainerExpirationPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectContainerExpirationPolicyOutputReference;
}
export interface DataGitlabProjectPushRules {
}
export declare function dataGitlabProjectPushRulesToTerraform(struct?: DataGitlabProjectPushRules): any;
export declare function dataGitlabProjectPushRulesToHclTerraform(struct?: DataGitlabProjectPushRules): any;
export declare class DataGitlabProjectPushRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectPushRules | undefined;
    set internalValue(value: DataGitlabProjectPushRules | undefined);
    get authorEmailRegex(): string;
    get branchNameRegex(): string;
    get commitCommitterCheck(): cdktf.IResolvable;
    get commitCommitterNameCheck(): cdktf.IResolvable;
    get commitMessageNegativeRegex(): string;
    get commitMessageRegex(): string;
    get denyDeleteTag(): cdktf.IResolvable;
    get fileNameRegex(): string;
    get maxFileSize(): number;
    get memberCheck(): cdktf.IResolvable;
    get preventSecrets(): cdktf.IResolvable;
    get rejectNonDcoCommits(): cdktf.IResolvable;
    get rejectUnsignedCommits(): cdktf.IResolvable;
}
export declare class DataGitlabProjectPushRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectPushRulesOutputReference;
}
export interface DataGitlabProjectSharedWithGroups {
}
export declare function dataGitlabProjectSharedWithGroupsToTerraform(struct?: DataGitlabProjectSharedWithGroups): any;
export declare function dataGitlabProjectSharedWithGroupsToHclTerraform(struct?: DataGitlabProjectSharedWithGroups): any;
export declare class DataGitlabProjectSharedWithGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectSharedWithGroups | undefined;
    set internalValue(value: DataGitlabProjectSharedWithGroups | undefined);
    get groupAccessLevel(): number;
    get groupFullPath(): string;
    get groupId(): number;
    get groupName(): string;
}
export declare class DataGitlabProjectSharedWithGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectSharedWithGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project gitlab_project}
*/
export declare class DataGitlabProject extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project";
    /**
    * Generates CDKTF code for importing a DataGitlabProject resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProject to import
    * @param importFromId The id of the existing DataGitlabProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project gitlab_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabProjectConfig);
    get allowPipelineTriggerApproveDeployment(): cdktf.IResolvable;
    get analyticsAccessLevel(): string;
    get archived(): cdktf.IResolvable;
    get autoCancelPendingPipelines(): string;
    get autoDevopsDeployStrategy(): string;
    get autoDevopsEnabled(): cdktf.IResolvable;
    get autocloseReferencedIssues(): cdktf.IResolvable;
    get buildGitStrategy(): string;
    get buildTimeout(): number;
    get buildsAccessLevel(): string;
    get ciConfigPath(): string;
    private _ciDefaultGitDepth?;
    get ciDefaultGitDepth(): number;
    set ciDefaultGitDepth(value: number);
    resetCiDefaultGitDepth(): void;
    get ciDefaultGitDepthInput(): number | undefined;
    get ciDeletePipelinesInSeconds(): number;
    private _ciIdTokenSubClaimComponents?;
    get ciIdTokenSubClaimComponents(): string[];
    set ciIdTokenSubClaimComponents(value: string[]);
    resetCiIdTokenSubClaimComponents(): void;
    get ciIdTokenSubClaimComponentsInput(): string[] | undefined;
    get ciPipelineVariablesMinimumOverrideRole(): string;
    get ciRestrictPipelineCancellationRole(): string;
    get ciSeparatedCaches(): cdktf.IResolvable;
    private _containerExpirationPolicy;
    get containerExpirationPolicy(): DataGitlabProjectContainerExpirationPolicyList;
    get containerRegistryAccessLevel(): string;
    get defaultBranch(): string;
    get description(): string;
    get emailsEnabled(): cdktf.IResolvable;
    get emptyRepo(): cdktf.IResolvable;
    get environmentsAccessLevel(): string;
    get externalAuthorizationClassificationLabel(): string;
    get featureFlagsAccessLevel(): string;
    get forkingAccessLevel(): string;
    get httpUrlToRepo(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get importUrl(): string;
    get infrastructureAccessLevel(): string;
    get issuesAccessLevel(): string;
    get issuesEnabled(): cdktf.IResolvable;
    get keepLatestArtifact(): cdktf.IResolvable;
    get lfsEnabled(): cdktf.IResolvable;
    get mergeCommitTemplate(): string;
    get mergePipelinesEnabled(): cdktf.IResolvable;
    get mergeRequestsAccessLevel(): string;
    get mergeRequestsEnabled(): cdktf.IResolvable;
    get mergeTrainsEnabled(): cdktf.IResolvable;
    get modelExperimentsAccessLevel(): string;
    get modelRegistryAccessLevel(): string;
    get monitorAccessLevel(): string;
    get name(): string;
    get namespaceId(): number;
    get path(): string;
    private _pathWithNamespace?;
    get pathWithNamespace(): string;
    set pathWithNamespace(value: string);
    resetPathWithNamespace(): void;
    get pathWithNamespaceInput(): string | undefined;
    get pipelinesEnabled(): cdktf.IResolvable;
    get preventMergeWithoutJiraIssue(): cdktf.IResolvable;
    get printingMergeRequestLinkEnabled(): cdktf.IResolvable;
    private _publicBuilds?;
    get publicBuilds(): boolean | cdktf.IResolvable;
    set publicBuilds(value: boolean | cdktf.IResolvable);
    resetPublicBuilds(): void;
    get publicBuildsInput(): boolean | cdktf.IResolvable | undefined;
    private _pushRules;
    get pushRules(): DataGitlabProjectPushRulesList;
    get releasesAccessLevel(): string;
    get removeSourceBranchAfterMerge(): cdktf.IResolvable;
    get repositoryAccessLevel(): string;
    get repositoryStorage(): string;
    get requestAccessEnabled(): cdktf.IResolvable;
    get requirementsAccessLevel(): string;
    get resolveOutdatedDiffDiscussions(): cdktf.IResolvable;
    get restrictUserDefinedVariables(): cdktf.IResolvable;
    get runnersToken(): string;
    get securityAndComplianceAccessLevel(): string;
    private _sharedWithGroups;
    get sharedWithGroups(): DataGitlabProjectSharedWithGroupsList;
    get snippetsAccessLevel(): string;
    get snippetsEnabled(): cdktf.IResolvable;
    get squashCommitTemplate(): string;
    get sshUrlToRepo(): string;
    get suggestionCommitMessage(): string;
    get topics(): string[];
    get visibilityLevel(): string;
    get webUrl(): string;
    get wikiAccessLevel(): string;
    get wikiEnabled(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
