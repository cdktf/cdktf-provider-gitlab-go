/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectMirrorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Determines the mirror authentication method. Valid values are: `ssh_public_key`, `password`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#auth_method ProjectMirror#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Determines if the mirror is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#enabled ProjectMirror#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Determines if divergent refs are skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#keep_divergent_refs ProjectMirror#keep_divergent_refs}
    */
    readonly keepDivergentRefs?: boolean | cdktf.IResolvable;
    /**
    * Contains a regular expression. Only branches with names matching the regex are mirrored. Requires only_protected_branches to be disabled. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#mirror_branch_regex ProjectMirror#mirror_branch_regex}
    */
    readonly mirrorBranchRegex?: string;
    /**
    * Determines if only protected branches are mirrored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#only_protected_branches ProjectMirror#only_protected_branches}
    */
    readonly onlyProtectedBranches?: boolean | cdktf.IResolvable;
    /**
    * The id of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#project ProjectMirror#project}
    */
    readonly project: string;
    /**
    * The URL of the remote repository to be mirrored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#url ProjectMirror#url}
    */
    readonly url: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror gitlab_project_mirror}
*/
export declare class ProjectMirror extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_mirror";
    /**
    * Generates CDKTF code for importing a ProjectMirror resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectMirror to import
    * @param importFromId The id of the existing ProjectMirror that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectMirror to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_mirror gitlab_project_mirror} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectMirrorConfig
    */
    constructor(scope: Construct, id: string, config: ProjectMirrorConfig);
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _keepDivergentRefs?;
    get keepDivergentRefs(): boolean | cdktf.IResolvable;
    set keepDivergentRefs(value: boolean | cdktf.IResolvable);
    resetKeepDivergentRefs(): void;
    get keepDivergentRefsInput(): boolean | cdktf.IResolvable | undefined;
    private _mirrorBranchRegex?;
    get mirrorBranchRegex(): string;
    set mirrorBranchRegex(value: string);
    resetMirrorBranchRegex(): void;
    get mirrorBranchRegexInput(): string | undefined;
    get mirrorId(): number;
    private _onlyProtectedBranches?;
    get onlyProtectedBranches(): boolean | cdktf.IResolvable;
    set onlyProtectedBranches(value: boolean | cdktf.IResolvable);
    resetOnlyProtectedBranches(): void;
    get onlyProtectedBranchesInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
