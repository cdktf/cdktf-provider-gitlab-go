/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabCurrentUserConfig extends cdktf.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/current_user gitlab_current_user}
*/
export declare class DataGitlabCurrentUser extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_current_user";
    /**
    * Generates CDKTF code for importing a DataGitlabCurrentUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabCurrentUser to import
    * @param importFromId The id of the existing DataGitlabCurrentUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/current_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabCurrentUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/current_user gitlab_current_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabCurrentUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabCurrentUserConfig);
    get bot(): cdktf.IResolvable;
    get globalId(): string;
    get globalNamespaceId(): string;
    get groupCount(): number;
    get id(): string;
    get name(): string;
    get namespaceId(): string;
    get publicEmail(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
