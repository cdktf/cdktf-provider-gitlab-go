/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectProtectedTagsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The integer or path with namespace that uniquely identifies the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags#project DataGitlabProjectProtectedTags#project}
    */
    readonly project: string;
}
export interface DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels {
    /**
    * The ID of a GitLab group allowed to perform the relevant action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags#group_id DataGitlabProjectProtectedTags#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags#user_id DataGitlabProjectProtectedTags#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels): any;
export declare function dataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels): any;
export declare class DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels | undefined;
    set internalValue(value: DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get id(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsOutputReference;
}
export interface DataGitlabProjectProtectedTagsProtectedTags {
}
export declare function dataGitlabProjectProtectedTagsProtectedTagsToTerraform(struct?: DataGitlabProjectProtectedTagsProtectedTags): any;
export declare function dataGitlabProjectProtectedTagsProtectedTagsToHclTerraform(struct?: DataGitlabProjectProtectedTagsProtectedTags): any;
export declare class DataGitlabProjectProtectedTagsProtectedTagsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedTagsProtectedTags | undefined;
    set internalValue(value: DataGitlabProjectProtectedTagsProtectedTags | undefined);
    private _createAccessLevels;
    get createAccessLevels(): DataGitlabProjectProtectedTagsProtectedTagsCreateAccessLevelsList;
    get tag(): string;
}
export declare class DataGitlabProjectProtectedTagsProtectedTagsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedTagsProtectedTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags gitlab_project_protected_tags}
*/
export declare class DataGitlabProjectProtectedTags extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_protected_tags";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectProtectedTags resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectProtectedTags to import
    * @param importFromId The id of the existing DataGitlabProjectProtectedTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectProtectedTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tags gitlab_project_protected_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectProtectedTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectProtectedTagsConfig);
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _protectedTags;
    get protectedTags(): DataGitlabProjectProtectedTagsProtectedTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
