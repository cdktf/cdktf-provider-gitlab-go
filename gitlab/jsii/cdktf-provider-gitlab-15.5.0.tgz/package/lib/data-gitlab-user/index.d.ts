/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * The public email address of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#email DataGitlabUser#email}
    */
    readonly email?: string;
    /**
    * (Experimental) If true, returns only an exact match. Otherwise, fuzzy matching might return the closest result. If no exact match is available, the data source returns an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#email_exact_match DataGitlabUser#email_exact_match}
    */
    readonly emailExactMatch?: boolean | cdktf.IResolvable;
    /**
    * The ID of the user's namespace. Requires admin token to access this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#namespace_id DataGitlabUser#namespace_id}
    */
    readonly namespaceId?: number;
    /**
    * The ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#user_id DataGitlabUser#user_id}
    */
    readonly userId?: number;
    /**
    * The username of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#username DataGitlabUser#username}
    */
    readonly username?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user gitlab_user}
*/
export declare class DataGitlabUser extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_user";
    /**
    * Generates CDKTF code for importing a DataGitlabUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabUser to import
    * @param importFromId The id of the existing DataGitlabUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/user gitlab_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabUserConfig);
    get avatarUrl(): string;
    get bio(): string;
    get canCreateGroup(): cdktf.IResolvable;
    get canCreateProject(): cdktf.IResolvable;
    get colorSchemeId(): number;
    get createdAt(): string;
    get currentSignInAt(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _emailExactMatch?;
    get emailExactMatch(): boolean | cdktf.IResolvable;
    set emailExactMatch(value: boolean | cdktf.IResolvable);
    resetEmailExactMatch(): void;
    get emailExactMatchInput(): boolean | cdktf.IResolvable | undefined;
    get externUid(): string;
    get external(): cdktf.IResolvable;
    get id(): string;
    get isAdmin(): cdktf.IResolvable;
    get isBot(): cdktf.IResolvable;
    get lastSignInAt(): string;
    get linkedin(): string;
    get location(): string;
    get name(): string;
    private _namespaceId?;
    get namespaceId(): number;
    set namespaceId(value: number);
    resetNamespaceId(): void;
    get namespaceIdInput(): number | undefined;
    get note(): string;
    get organization(): string;
    get projectsLimit(): number;
    get skype(): string;
    get state(): string;
    get themeId(): number;
    get twitter(): string;
    get twoFactorEnabled(): cdktf.IResolvable;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
    get userProvider(): string;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    get websiteUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
