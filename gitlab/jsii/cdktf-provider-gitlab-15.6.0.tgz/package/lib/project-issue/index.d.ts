/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectIssueConfig extends cdktf.TerraformMetaArguments {
    /**
    * The IDs of the users to assign the issue to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#assignee_ids ProjectIssue#assignee_ids}
    */
    readonly assigneeIds?: number[];
    /**
    * Set an issue to be confidential.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#confidential ProjectIssue#confidential}
    */
    readonly confidential?: boolean | cdktf.IResolvable;
    /**
    * When the issue was created. Date time string, ISO 8601 formatted, for example 2016-03-11T03:45:40Z. Requires administrator or project/group owner rights.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#created_at ProjectIssue#created_at}
    */
    readonly createdAt?: string;
    /**
    * Whether the issue is deleted instead of closed during destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#delete_on_destroy ProjectIssue#delete_on_destroy}
    */
    readonly deleteOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * The description of an issue. Limited to 1,048,576 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#description ProjectIssue#description}
    */
    readonly description?: string;
    /**
    * Whether the issue is locked for discussions or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#discussion_locked ProjectIssue#discussion_locked}
    */
    readonly discussionLocked?: boolean | cdktf.IResolvable;
    /**
    * The ID of a discussion to resolve. This fills out the issue with a default description and mark the discussion as resolved. Use in combination with merge_request_to_resolve_discussions_of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#discussion_to_resolve ProjectIssue#discussion_to_resolve}
    */
    readonly discussionToResolve?: string;
    /**
    * The due date. Date time string in the format YYYY-MM-DD, for example 2016-03-11.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#due_date ProjectIssue#due_date}
    */
    readonly dueDate?: string;
    /**
    * The ID of the epic issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#epic_issue_id ProjectIssue#epic_issue_id}
    */
    readonly epicIssueId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#id ProjectIssue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The internal ID of the project's issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#iid ProjectIssue#iid}
    */
    readonly iid?: number;
    /**
    * The type of issue. Valid values are: `issue`, `incident`, `test_case`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#issue_type ProjectIssue#issue_type}
    */
    readonly issueType?: string;
    /**
    * The labels of an issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#labels ProjectIssue#labels}
    */
    readonly labels?: string[];
    /**
    * The IID of a merge request in which to resolve all issues. This fills out the issue with a default description and mark all discussions as resolved. When passing a description or title, these values take precedence over the default values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#merge_request_to_resolve_discussions_of ProjectIssue#merge_request_to_resolve_discussions_of}
    */
    readonly mergeRequestToResolveDiscussionsOf?: number;
    /**
    * The global ID of a milestone to assign issue. To find the milestone_id associated with a milestone, view an issue with the milestone assigned and use the API to retrieve the issue's details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#milestone_id ProjectIssue#milestone_id}
    */
    readonly milestoneId?: number;
    /**
    * The name or ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#project ProjectIssue#project}
    */
    readonly project: string;
    /**
    * The state of the issue. Valid values are: `opened`, `closed`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#state ProjectIssue#state}
    */
    readonly state?: string;
    /**
    * The title of the issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#title ProjectIssue#title}
    */
    readonly title: string;
    /**
    * When the issue was updated. Date time string, ISO 8601 formatted, for example 2016-03-11T03:45:40Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#updated_at ProjectIssue#updated_at}
    */
    readonly updatedAt?: string;
    /**
    * The weight of the issue. Valid values are greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#weight ProjectIssue#weight}
    */
    readonly weight?: number;
}
export interface ProjectIssueTaskCompletionStatus {
}
export declare function projectIssueTaskCompletionStatusToTerraform(struct?: ProjectIssueTaskCompletionStatus): any;
export declare function projectIssueTaskCompletionStatusToHclTerraform(struct?: ProjectIssueTaskCompletionStatus): any;
export declare class ProjectIssueTaskCompletionStatusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectIssueTaskCompletionStatus | undefined;
    set internalValue(value: ProjectIssueTaskCompletionStatus | undefined);
    get completedCount(): number;
    get count(): number;
}
export declare class ProjectIssueTaskCompletionStatusList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectIssueTaskCompletionStatusOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue gitlab_project_issue}
*/
export declare class ProjectIssue extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_issue";
    /**
    * Generates CDKTF code for importing a ProjectIssue resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectIssue to import
    * @param importFromId The id of the existing ProjectIssue that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectIssue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_issue gitlab_project_issue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectIssueConfig
    */
    constructor(scope: Construct, id: string, config: ProjectIssueConfig);
    private _assigneeIds?;
    get assigneeIds(): number[];
    set assigneeIds(value: number[]);
    resetAssigneeIds(): void;
    get assigneeIdsInput(): number[] | undefined;
    get authorId(): number;
    get closedAt(): string;
    get closedByUserId(): number;
    private _confidential?;
    get confidential(): boolean | cdktf.IResolvable;
    set confidential(value: boolean | cdktf.IResolvable);
    resetConfidential(): void;
    get confidentialInput(): boolean | cdktf.IResolvable | undefined;
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    private _deleteOnDestroy?;
    get deleteOnDestroy(): boolean | cdktf.IResolvable;
    set deleteOnDestroy(value: boolean | cdktf.IResolvable);
    resetDeleteOnDestroy(): void;
    get deleteOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discussionLocked?;
    get discussionLocked(): boolean | cdktf.IResolvable;
    set discussionLocked(value: boolean | cdktf.IResolvable);
    resetDiscussionLocked(): void;
    get discussionLockedInput(): boolean | cdktf.IResolvable | undefined;
    private _discussionToResolve?;
    get discussionToResolve(): string;
    set discussionToResolve(value: string);
    resetDiscussionToResolve(): void;
    get discussionToResolveInput(): string | undefined;
    get downvotes(): number;
    private _dueDate?;
    get dueDate(): string;
    set dueDate(value: string);
    resetDueDate(): void;
    get dueDateInput(): string | undefined;
    get epicId(): number;
    private _epicIssueId?;
    get epicIssueId(): number;
    set epicIssueId(value: number);
    resetEpicIssueId(): void;
    get epicIssueIdInput(): number | undefined;
    get externalId(): string;
    get humanTimeEstimate(): string;
    get humanTotalTimeSpent(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _iid?;
    get iid(): number;
    set iid(value: number);
    resetIid(): void;
    get iidInput(): number | undefined;
    get issueId(): number;
    get issueLinkId(): number;
    private _issueType?;
    get issueType(): string;
    set issueType(value: string);
    resetIssueType(): void;
    get issueTypeInput(): string | undefined;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _links;
    get links(): cdktf.StringMap;
    private _mergeRequestToResolveDiscussionsOf?;
    get mergeRequestToResolveDiscussionsOf(): number;
    set mergeRequestToResolveDiscussionsOf(value: number);
    resetMergeRequestToResolveDiscussionsOf(): void;
    get mergeRequestToResolveDiscussionsOfInput(): number | undefined;
    get mergeRequestsCount(): number;
    private _milestoneId?;
    get milestoneId(): number;
    set milestoneId(value: number);
    resetMilestoneId(): void;
    get milestoneIdInput(): number | undefined;
    get movedToId(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _references;
    get references(): cdktf.StringMap;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    get subscribed(): cdktf.IResolvable;
    private _taskCompletionStatus;
    get taskCompletionStatus(): ProjectIssueTaskCompletionStatusList;
    get timeEstimate(): number;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    get totalTimeSpent(): number;
    private _updatedAt?;
    get updatedAt(): string;
    set updatedAt(value: string);
    resetUpdatedAt(): void;
    get updatedAtInput(): string | undefined;
    get upvotes(): number;
    get userNotesCount(): number;
    get webUrl(): string;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
