/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectRunnerEnablementConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement#id ProjectRunnerEnablement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID or URL-encoded path of the project owned by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement#project ProjectRunnerEnablement#project}
    */
    readonly project: string;
    /**
    * The ID of a runner to enable for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement#runner_id ProjectRunnerEnablement#runner_id}
    */
    readonly runnerId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement gitlab_project_runner_enablement}
*/
export declare class ProjectRunnerEnablement extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_runner_enablement";
    /**
    * Generates CDKTF code for importing a ProjectRunnerEnablement resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectRunnerEnablement to import
    * @param importFromId The id of the existing ProjectRunnerEnablement that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectRunnerEnablement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_runner_enablement gitlab_project_runner_enablement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectRunnerEnablementConfig
    */
    constructor(scope: Construct, id: string, config: ProjectRunnerEnablementConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _runnerId?;
    get runnerId(): number;
    set runnerId(value: number);
    get runnerIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
