/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupAccessTokensConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name or id of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/group_access_tokens#group DataGitlabGroupAccessTokens#group}
    */
    readonly group: string;
}
export interface DataGitlabGroupAccessTokensAccessTokens {
}
export declare function dataGitlabGroupAccessTokensAccessTokensToTerraform(struct?: DataGitlabGroupAccessTokensAccessTokens): any;
export declare function dataGitlabGroupAccessTokensAccessTokensToHclTerraform(struct?: DataGitlabGroupAccessTokensAccessTokens): any;
export declare class DataGitlabGroupAccessTokensAccessTokensOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupAccessTokensAccessTokens | undefined;
    set internalValue(value: DataGitlabGroupAccessTokensAccessTokens | undefined);
    get accessLevel(): string;
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get expiresAt(): string;
    get group(): string;
    get id(): string;
    get name(): string;
    get revoked(): cdktf.IResolvable;
    get scopes(): string[];
    get userId(): number;
}
export declare class DataGitlabGroupAccessTokensAccessTokensList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupAccessTokensAccessTokensOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/group_access_tokens gitlab_group_access_tokens}
*/
export declare class DataGitlabGroupAccessTokens extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_access_tokens";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupAccessTokens resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupAccessTokens to import
    * @param importFromId The id of the existing DataGitlabGroupAccessTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/group_access_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupAccessTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/group_access_tokens gitlab_group_access_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupAccessTokensConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupAccessTokensConfig);
    private _accessTokens;
    get accessTokens(): DataGitlabGroupAccessTokensAccessTokensList;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
