/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupSamlLinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * Access level for members of the SAML group. Valid values are: `guest`, `planner`, `reporter`, `developer`, `maintainer`, `owner`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#access_level GroupSamlLink#access_level}
    */
    readonly accessLevel: string;
    /**
    * The ID or path of the group to add the SAML Group Link to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#group GroupSamlLink#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#id GroupSamlLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of a custom member role. Only available for Ultimate instances. When using a custom role, the `access_level` must match the base role used to create the custom role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#member_role_id GroupSamlLink#member_role_id}
    */
    readonly memberRoleId?: number;
    /**
    * The name of the SAML group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#saml_group_name GroupSamlLink#saml_group_name}
    */
    readonly samlGroupName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link gitlab_group_saml_link}
*/
export declare class GroupSamlLink extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_saml_link";
    /**
    * Generates CDKTF code for importing a GroupSamlLink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupSamlLink to import
    * @param importFromId The id of the existing GroupSamlLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupSamlLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_saml_link gitlab_group_saml_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupSamlLinkConfig
    */
    constructor(scope: Construct, id: string, config: GroupSamlLinkConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    get accessLevelInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberRoleId?;
    get memberRoleId(): number;
    set memberRoleId(value: number);
    resetMemberRoleId(): void;
    get memberRoleIdInput(): number | undefined;
    private _samlGroupName?;
    get samlGroupName(): string;
    set samlGroupName(value: string);
    get samlGroupNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
