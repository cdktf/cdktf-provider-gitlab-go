/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupSamlLinksConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name or id of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_saml_links#group DataGitlabGroupSamlLinks#group}
    */
    readonly group: string;
}
export interface DataGitlabGroupSamlLinksSamlLinks {
}
export declare function dataGitlabGroupSamlLinksSamlLinksToTerraform(struct?: DataGitlabGroupSamlLinksSamlLinks): any;
export declare function dataGitlabGroupSamlLinksSamlLinksToHclTerraform(struct?: DataGitlabGroupSamlLinksSamlLinks): any;
export declare class DataGitlabGroupSamlLinksSamlLinksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupSamlLinksSamlLinks | undefined;
    set internalValue(value: DataGitlabGroupSamlLinksSamlLinks | undefined);
    get accessLevel(): string;
    get memberRoleId(): number;
    get name(): string;
}
export declare class DataGitlabGroupSamlLinksSamlLinksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupSamlLinksSamlLinksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_saml_links gitlab_group_saml_links}
*/
export declare class DataGitlabGroupSamlLinks extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_saml_links";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupSamlLinks resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupSamlLinks to import
    * @param importFromId The id of the existing DataGitlabGroupSamlLinks that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_saml_links#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupSamlLinks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_saml_links gitlab_group_saml_links} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupSamlLinksConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupSamlLinksConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _samlLinks;
    get samlLinks(): DataGitlabGroupSamlLinksSamlLinksList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
