/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectJobTokenScopeConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope#project ProjectJobTokenScope#project}
    */
    readonly project: string;
    /**
    * The ID of the group that is in the CI/CD job token inbound allowlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope#target_group_id ProjectJobTokenScope#target_group_id}
    */
    readonly targetGroupId?: number;
    /**
    * The ID of the project that is in the CI/CD job token inbound allowlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope#target_project_id ProjectJobTokenScope#target_project_id}
    */
    readonly targetProjectId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope gitlab_project_job_token_scope}
*/
export declare class ProjectJobTokenScope extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_job_token_scope";
    /**
    * Generates CDKTF code for importing a ProjectJobTokenScope resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectJobTokenScope to import
    * @param importFromId The id of the existing ProjectJobTokenScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectJobTokenScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_job_token_scope gitlab_project_job_token_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectJobTokenScopeConfig
    */
    constructor(scope: Construct, id: string, config: ProjectJobTokenScopeConfig);
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _targetGroupId?;
    get targetGroupId(): number;
    set targetGroupId(value: number);
    resetTargetGroupId(): void;
    get targetGroupIdInput(): number | undefined;
    private _targetProjectId?;
    get targetProjectId(): number;
    set targetProjectId(value: number);
    resetTargetProjectId(): void;
    get targetProjectIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
