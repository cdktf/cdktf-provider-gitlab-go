/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabPipelineScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The timezone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule#cron_timezone DataGitlabPipelineSchedule#cron_timezone}
    */
    readonly cronTimezone?: string;
    /**
    * The pipeline schedule id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule#pipeline_schedule_id DataGitlabPipelineSchedule#pipeline_schedule_id}
    */
    readonly pipelineScheduleId: number;
    /**
    * The name or id of the project to add the schedule to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule#project DataGitlabPipelineSchedule#project}
    */
    readonly project: string;
}
export interface DataGitlabPipelineScheduleLastPipeline {
}
export declare function dataGitlabPipelineScheduleLastPipelineToTerraform(struct?: DataGitlabPipelineScheduleLastPipeline): any;
export declare function dataGitlabPipelineScheduleLastPipelineToHclTerraform(struct?: DataGitlabPipelineScheduleLastPipeline): any;
export declare class DataGitlabPipelineScheduleLastPipelineOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabPipelineScheduleLastPipeline | undefined;
    set internalValue(value: DataGitlabPipelineScheduleLastPipeline | undefined);
    get id(): number;
    get ref(): string;
    get sha(): string;
    get status(): string;
}
export interface DataGitlabPipelineScheduleOwner {
}
export declare function dataGitlabPipelineScheduleOwnerToTerraform(struct?: DataGitlabPipelineScheduleOwner): any;
export declare function dataGitlabPipelineScheduleOwnerToHclTerraform(struct?: DataGitlabPipelineScheduleOwner): any;
export declare class DataGitlabPipelineScheduleOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabPipelineScheduleOwner | undefined;
    set internalValue(value: DataGitlabPipelineScheduleOwner | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabPipelineScheduleVariables {
}
export declare function dataGitlabPipelineScheduleVariablesToTerraform(struct?: DataGitlabPipelineScheduleVariables): any;
export declare function dataGitlabPipelineScheduleVariablesToHclTerraform(struct?: DataGitlabPipelineScheduleVariables): any;
export declare class DataGitlabPipelineScheduleVariablesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabPipelineScheduleVariables | undefined;
    set internalValue(value: DataGitlabPipelineScheduleVariables | undefined);
    get key(): string;
    get value(): string;
    get variableType(): string;
}
export declare class DataGitlabPipelineScheduleVariablesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabPipelineScheduleVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule gitlab_pipeline_schedule}
*/
export declare class DataGitlabPipelineSchedule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_pipeline_schedule";
    /**
    * Generates CDKTF code for importing a DataGitlabPipelineSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabPipelineSchedule to import
    * @param importFromId The id of the existing DataGitlabPipelineSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabPipelineSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/pipeline_schedule gitlab_pipeline_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabPipelineScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabPipelineScheduleConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get cron(): string;
    private _cronTimezone?;
    get cronTimezone(): string;
    set cronTimezone(value: string);
    resetCronTimezone(): void;
    get cronTimezoneInput(): string | undefined;
    get description(): string;
    get id(): string;
    private _lastPipeline;
    get lastPipeline(): DataGitlabPipelineScheduleLastPipelineOutputReference;
    get nextRunAt(): string;
    private _owner;
    get owner(): DataGitlabPipelineScheduleOwnerOutputReference;
    private _pipelineScheduleId?;
    get pipelineScheduleId(): number;
    set pipelineScheduleId(value: number);
    get pipelineScheduleIdInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get ref(): string;
    get updatedAt(): string;
    private _variables;
    get variables(): DataGitlabPipelineScheduleVariablesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
