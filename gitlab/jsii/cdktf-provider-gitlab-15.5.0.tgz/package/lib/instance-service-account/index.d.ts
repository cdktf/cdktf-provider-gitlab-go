/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface InstanceServiceAccountConfig extends cdktf.TerraformMetaArguments {
    /**
    * The email of the user account. If not set, generates a no-reply email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#email InstanceServiceAccount#email}
    */
    readonly email?: string;
    /**
    * The name of the user. If not set, uses Service account user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#name InstanceServiceAccount#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#timeouts InstanceServiceAccount#timeouts}
    */
    readonly timeouts?: InstanceServiceAccountTimeouts;
    /**
    * The username of the user account. If not set, generates a name prepended with service_account_.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#username InstanceServiceAccount#username}
    */
    readonly username?: string;
}
export interface InstanceServiceAccountTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#delete InstanceServiceAccount#delete}
    */
    readonly delete?: string;
}
export declare function instanceServiceAccountTimeoutsToTerraform(struct?: InstanceServiceAccountTimeouts | cdktf.IResolvable): any;
export declare function instanceServiceAccountTimeoutsToHclTerraform(struct?: InstanceServiceAccountTimeouts | cdktf.IResolvable): any;
export declare class InstanceServiceAccountTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InstanceServiceAccountTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: InstanceServiceAccountTimeouts | cdktf.IResolvable | undefined);
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account gitlab_instance_service_account}
*/
export declare class InstanceServiceAccount extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_instance_service_account";
    /**
    * Generates CDKTF code for importing a InstanceServiceAccount resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the InstanceServiceAccount to import
    * @param importFromId The id of the existing InstanceServiceAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the InstanceServiceAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/instance_service_account gitlab_instance_service_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InstanceServiceAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: InstanceServiceAccountConfig);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get serviceAccountId(): string;
    private _timeouts;
    get timeouts(): InstanceServiceAccountTimeoutsOutputReference;
    putTimeouts(value: InstanceServiceAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | InstanceServiceAccountTimeouts | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
