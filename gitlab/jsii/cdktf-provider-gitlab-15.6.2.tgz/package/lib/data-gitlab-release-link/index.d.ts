/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabReleaseLinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link#link_id DataGitlabReleaseLink#link_id}
    */
    readonly linkId: number;
    /**
    * The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/index/#namespaced-path-encoding).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link#project DataGitlabReleaseLink#project}
    */
    readonly project: string;
    /**
    * The tag associated with the Release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link#tag_name DataGitlabReleaseLink#tag_name}
    */
    readonly tagName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link gitlab_release_link}
*/
export declare class DataGitlabReleaseLink extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_release_link";
    /**
    * Generates CDKTF code for importing a DataGitlabReleaseLink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabReleaseLink to import
    * @param importFromId The id of the existing DataGitlabReleaseLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabReleaseLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release_link gitlab_release_link} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabReleaseLinkConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabReleaseLinkConfig);
    get directAssetUrl(): string;
    get external(): cdktf.IResolvable;
    get filepath(): string;
    get id(): string;
    private _linkId?;
    get linkId(): number;
    set linkId(value: number);
    get linkIdInput(): number | undefined;
    get linkType(): string;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    get tagNameInput(): string | undefined;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
