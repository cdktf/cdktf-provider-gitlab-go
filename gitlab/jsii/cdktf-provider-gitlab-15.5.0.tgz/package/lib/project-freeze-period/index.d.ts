/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectFreezePeriodConfig extends cdktf.TerraformMetaArguments {
    /**
    * The timezone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period#cron_timezone ProjectFreezePeriod#cron_timezone}
    */
    readonly cronTimezone?: string;
    /**
    * End of the Freeze Period in cron format (for example, `0 2 * * *`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period#freeze_end ProjectFreezePeriod#freeze_end}
    */
    readonly freezeEnd: string;
    /**
    * Start of the Freeze Period in cron format (for example, `0 1 * * *`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period#freeze_start ProjectFreezePeriod#freeze_start}
    */
    readonly freezeStart: string;
    /**
    * The ID or path of the project to add the freeze period to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period#project ProjectFreezePeriod#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period gitlab_project_freeze_period}
*/
export declare class ProjectFreezePeriod extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_freeze_period";
    /**
    * Generates CDKTF code for importing a ProjectFreezePeriod resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectFreezePeriod to import
    * @param importFromId The id of the existing ProjectFreezePeriod that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectFreezePeriod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_freeze_period gitlab_project_freeze_period} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectFreezePeriodConfig
    */
    constructor(scope: Construct, id: string, config: ProjectFreezePeriodConfig);
    private _cronTimezone?;
    get cronTimezone(): string;
    set cronTimezone(value: string);
    resetCronTimezone(): void;
    get cronTimezoneInput(): string | undefined;
    private _freezeEnd?;
    get freezeEnd(): string;
    set freezeEnd(value: string);
    get freezeEndInput(): string | undefined;
    private _freezeStart?;
    get freezeStart(): string;
    set freezeStart(value: string);
    get freezeStartInput(): string | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
