/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Set to true if you want to treat skipped pipelines as if they finished with success.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#allow_merge_on_skipped_pipeline Project#allow_merge_on_skipped_pipeline}
    */
    readonly allowMergeOnSkippedPipeline?: boolean | cdktf.IResolvable;
    /**
    * Set whether or not a pipeline triggerer is allowed to approve deployments. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#allow_pipeline_trigger_approve_deployment Project#allow_pipeline_trigger_approve_deployment}
    */
    readonly allowPipelineTriggerApproveDeployment?: boolean | cdktf.IResolvable;
    /**
    * Set the analytics access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#analytics_access_level Project#analytics_access_level}
    */
    readonly analyticsAccessLevel?: string;
    /**
    * Number of merge request approvals required for merging. Default is 0. This field **does not** work well in combination with the `gitlab_project_approval_rule` resource. We recommend you do not use this deprecated field and use `gitlab_project_approval_rule` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#approvals_before_merge Project#approvals_before_merge}
    */
    readonly approvalsBeforeMerge?: number;
    /**
    * Set to `true` to archive the project instead of deleting on destroy. If set to `true` it will entire omit the `DELETE` operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#archive_on_destroy Project#archive_on_destroy}
    */
    readonly archiveOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * Whether the project is in read-only mode (archived). Repositories can be archived/unarchived by toggling this parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#archived Project#archived}
    */
    readonly archived?: boolean | cdktf.IResolvable;
    /**
    * Auto-cancel pending pipelines. This isn’t a boolean, but enabled/disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#auto_cancel_pending_pipelines Project#auto_cancel_pending_pipelines}
    */
    readonly autoCancelPendingPipelines?: string;
    /**
    * Auto Deploy strategy. Valid values are `continuous`, `manual`, `timed_incremental`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#auto_devops_deploy_strategy Project#auto_devops_deploy_strategy}
    */
    readonly autoDevopsDeployStrategy?: string;
    /**
    * Enable Auto DevOps for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#auto_devops_enabled Project#auto_devops_enabled}
    */
    readonly autoDevopsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable automatic reviews by GitLab Duo on merge requests. Ultimate only. Automatic reviews only work with the GitLab Duo Enterprise add-on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#auto_duo_code_review_enabled Project#auto_duo_code_review_enabled}
    */
    readonly autoDuoCodeReviewEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set whether auto-closing referenced issues on default branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#autoclose_referenced_issues Project#autoclose_referenced_issues}
    */
    readonly autocloseReferencedIssues?: boolean | cdktf.IResolvable;
    /**
    * A local path to the avatar image to upload. **Note**: not available for imported resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#avatar Project#avatar}
    */
    readonly avatar?: string;
    /**
    * The hash of the avatar image. Use `filesha256("path/to/avatar.png")` whenever possible. **Note**: this is used to trigger an update of the avatar. If it's not given, but an avatar is given, the avatar will be updated each time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#avatar_hash Project#avatar_hash}
    */
    readonly avatarHash?: string;
    /**
    * Branches to fork (empty for all branches).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#branches Project#branches}
    */
    readonly branches?: string;
    /**
    * The Git strategy. Defaults to fetch. Valid values are `clone`, `fetch`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#build_git_strategy Project#build_git_strategy}
    */
    readonly buildGitStrategy?: string;
    /**
    * The maximum amount of time, in seconds, that a job can run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#build_timeout Project#build_timeout}
    */
    readonly buildTimeout?: number;
    /**
    * Set the builds access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#builds_access_level Project#builds_access_level}
    */
    readonly buildsAccessLevel?: string;
    /**
    * Custom Path to CI config file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_config_path Project#ci_config_path}
    */
    readonly ciConfigPath?: string;
    /**
    * Default number of revisions for shallow cloning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_default_git_depth Project#ci_default_git_depth}
    */
    readonly ciDefaultGitDepth?: number;
    /**
    * Pipelines older than the configured time are deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_delete_pipelines_in_seconds Project#ci_delete_pipelines_in_seconds}
    */
    readonly ciDeletePipelinesInSeconds?: number;
    /**
    * When a new deployment job starts, skip older deployment jobs that are still pending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_forward_deployment_enabled Project#ci_forward_deployment_enabled}
    */
    readonly ciForwardDeploymentEnabled?: boolean | cdktf.IResolvable;
    /**
    * Allow job retries even if the deployment job is outdated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_forward_deployment_rollback_allowed Project#ci_forward_deployment_rollback_allowed}
    */
    readonly ciForwardDeploymentRollbackAllowed?: boolean | cdktf.IResolvable;
    /**
    * Fields included in the sub claim of the ID Token. Accepts an array starting with project_path. The array might also include ref_type and ref. Defaults to ["project_path", "ref_type", "ref"]. Introduced in GitLab 17.10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_id_token_sub_claim_components Project#ci_id_token_sub_claim_components}
    */
    readonly ciIdTokenSubClaimComponents?: string[];
    /**
    * The minimum role required to set variables when running pipelines and jobs. Introduced in GitLab 17.1. Valid values are `developer`, `maintainer`, `owner`, `no_one_allowed`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_pipeline_variables_minimum_override_role Project#ci_pipeline_variables_minimum_override_role}
    */
    readonly ciPipelineVariablesMinimumOverrideRole?: string;
    /**
    * Allow Git push requests to your project repository that are authenticated with a CI/CD job token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_push_repository_for_job_token_allowed Project#ci_push_repository_for_job_token_allowed}
    */
    readonly ciPushRepositoryForJobTokenAllowed?: boolean | cdktf.IResolvable;
    /**
    * The role required to cancel a pipeline or job. Premium and Ultimate only. Valid values are `developer`, `maintainer`, `no one`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_restrict_pipeline_cancellation_role Project#ci_restrict_pipeline_cancellation_role}
    */
    readonly ciRestrictPipelineCancellationRole?: string;
    /**
    * Use separate caches for protected branches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#ci_separated_caches Project#ci_separated_caches}
    */
    readonly ciSeparatedCaches?: boolean | cdktf.IResolvable;
    /**
    * Set visibility of container registry, for this project. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#container_registry_access_level Project#container_registry_access_level}
    */
    readonly containerRegistryAccessLevel?: string;
    /**
    * Enable container registry for the project. Use `container_registry_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#container_registry_enabled Project#container_registry_enabled}
    */
    readonly containerRegistryEnabled?: boolean | cdktf.IResolvable;
    /**
    * The default branch for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#default_branch Project#default_branch}
    */
    readonly defaultBranch?: string;
    /**
    * A description of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#description Project#description}
    */
    readonly description?: string;
    /**
    * Enable email notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#emails_enabled Project#emails_enabled}
    */
    readonly emailsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set the environments access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#environments_access_level Project#environments_access_level}
    */
    readonly environmentsAccessLevel?: string;
    /**
    * The classification label for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#external_authorization_classification_label Project#external_authorization_classification_label}
    */
    readonly externalAuthorizationClassificationLabel?: string;
    /**
    * Set the feature flags access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#feature_flags_access_level Project#feature_flags_access_level}
    */
    readonly featureFlagsAccessLevel?: string;
    /**
    * The id of the project to fork. During create the project is forked and during an update the fork relation is changed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#forked_from_project_id Project#forked_from_project_id}
    */
    readonly forkedFromProjectId?: number;
    /**
    * Set the forking access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#forking_access_level Project#forking_access_level}
    */
    readonly forkingAccessLevel?: string;
    /**
    * Enable group runners for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#group_runners_enabled Project#group_runners_enabled}
    */
    readonly groupRunnersEnabled?: boolean | cdktf.IResolvable;
    /**
    * For group-level custom templates, specifies ID of group from which all the custom project templates are sourced. Leave empty for instance-level templates. Requires use_custom_template to be true (enterprise edition).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#group_with_project_templates_id Project#group_with_project_templates_id}
    */
    readonly groupWithProjectTemplatesId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#id Project#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Git URL to a repository to be imported. Together with `mirror = true` it will setup a Pull Mirror. This can also be used together with `forked_from_project_id` to setup a Pull Mirror for a fork. The fork takes precedence over the import. Make sure to provide the credentials in `import_url_username` and `import_url_password`. GitLab never returns the credentials, thus the provider cannot detect configuration drift in the credentials. They can also not be imported using `terraform import`. See the examples section for how to properly use it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#import_url Project#import_url}
    */
    readonly importUrl?: string;
    /**
    * The password for the `import_url`. The value of this field is used to construct a valid `import_url` and is only related to the provider. This field cannot be imported using `terraform import`. See the examples section for how to properly use it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#import_url_password Project#import_url_password}
    */
    readonly importUrlPassword?: string;
    /**
    * The username for the `import_url`. The value of this field is used to construct a valid `import_url` and is only related to the provider. This field cannot be imported using `terraform import`.  See the examples section for how to properly use it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#import_url_username Project#import_url_username}
    */
    readonly importUrlUsername?: string;
    /**
    * Set the infrastructure access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#infrastructure_access_level Project#infrastructure_access_level}
    */
    readonly infrastructureAccessLevel?: string;
    /**
    * Create main branch with first commit containing a README.md file. Must be set to `true` if importing an uninitialized project with a different `default_branch`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#initialize_with_readme Project#initialize_with_readme}
    */
    readonly initializeWithReadme?: boolean | cdktf.IResolvable;
    /**
    * Set the issues access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#issues_access_level Project#issues_access_level}
    */
    readonly issuesAccessLevel?: string;
    /**
    * Enable issue tracking for the project. Use `issues_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#issues_enabled Project#issues_enabled}
    */
    readonly issuesEnabled?: boolean | cdktf.IResolvable;
    /**
    * Sets the template for new issues in the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#issues_template Project#issues_template}
    */
    readonly issuesTemplate?: string;
    /**
    * Disable or enable the ability to keep the latest artifact for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#keep_latest_artifact Project#keep_latest_artifact}
    */
    readonly keepLatestArtifact?: boolean | cdktf.IResolvable;
    /**
    * Enable LFS for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#lfs_enabled Project#lfs_enabled}
    */
    readonly lfsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Template used to create merge commit message in merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_commit_template Project#merge_commit_template}
    */
    readonly mergeCommitTemplate?: string;
    /**
    * Set the merge method. Valid values are `merge`, `rebase_merge`, `ff`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_method Project#merge_method}
    */
    readonly mergeMethod?: string;
    /**
    * Enable or disable merge pipelines.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_pipelines_enabled Project#merge_pipelines_enabled}
    */
    readonly mergePipelinesEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set the merge requests access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_requests_access_level Project#merge_requests_access_level}
    */
    readonly mergeRequestsAccessLevel?: string;
    /**
    * Enable merge requests for the project. Use `merge_requests_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_requests_enabled Project#merge_requests_enabled}
    */
    readonly mergeRequestsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Sets the template for new merge requests in the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_requests_template Project#merge_requests_template}
    */
    readonly mergeRequestsTemplate?: string;
    /**
    * Enable or disable merge trains. Requires `merge_pipelines_enabled` to be set to `true` to take effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#merge_trains_enabled Project#merge_trains_enabled}
    */
    readonly mergeTrainsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable project pull mirror.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#mirror Project#mirror}
    */
    readonly mirror?: boolean | cdktf.IResolvable;
    /**
    * Enable overwrite diverged branches for a mirrored project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#mirror_overwrites_diverged_branches Project#mirror_overwrites_diverged_branches}
    */
    readonly mirrorOverwritesDivergedBranches?: boolean | cdktf.IResolvable;
    /**
    * Enable trigger builds on pushes for a mirrored project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#mirror_trigger_builds Project#mirror_trigger_builds}
    */
    readonly mirrorTriggerBuilds?: boolean | cdktf.IResolvable;
    /**
    * Set visibility of machine learning model experiments. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#model_experiments_access_level Project#model_experiments_access_level}
    */
    readonly modelExperimentsAccessLevel?: string;
    /**
    * Set visibility of machine learning model registry. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#model_registry_access_level Project#model_registry_access_level}
    */
    readonly modelRegistryAccessLevel?: string;
    /**
    * Set the monitor access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#monitor_access_level Project#monitor_access_level}
    */
    readonly monitorAccessLevel?: string;
    /**
    * For forked projects, target merge requests to this project. If false, the target will be the upstream project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#mr_default_target_self Project#mr_default_target_self}
    */
    readonly mrDefaultTargetSelf?: boolean | cdktf.IResolvable;
    /**
    * The name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#name Project#name}
    */
    readonly name: string;
    /**
    * The namespace (group or user) of the project. Defaults to your user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#namespace_id Project#namespace_id}
    */
    readonly namespaceId?: number;
    /**
    * Set to true if you want allow merges only if all discussions are resolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#only_allow_merge_if_all_discussions_are_resolved Project#only_allow_merge_if_all_discussions_are_resolved}
    */
    readonly onlyAllowMergeIfAllDiscussionsAreResolved?: boolean | cdktf.IResolvable;
    /**
    * Set to true if you want allow merges only if a pipeline succeeds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#only_allow_merge_if_pipeline_succeeds Project#only_allow_merge_if_pipeline_succeeds}
    */
    readonly onlyAllowMergeIfPipelineSucceeds?: boolean | cdktf.IResolvable;
    /**
    * Enable only mirror protected branches for a mirrored project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#only_mirror_protected_branches Project#only_mirror_protected_branches}
    */
    readonly onlyMirrorProtectedBranches?: boolean | cdktf.IResolvable;
    /**
    * Enable packages repository for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#packages_enabled Project#packages_enabled}
    */
    readonly packagesEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable pages access control. Valid values are `public`, `private`, `enabled`, `disabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#pages_access_level Project#pages_access_level}
    */
    readonly pagesAccessLevel?: string;
    /**
    * The path of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#path Project#path}
    */
    readonly path?: string;
    /**
    * Set to `true` to immediately permanently delete the project instead of scheduling a delete for Premium and Ultimate tiers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#permanently_delete_on_destroy Project#permanently_delete_on_destroy}
    */
    readonly permanentlyDeleteOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * Enable pipelines for the project. The `pipelines_enabled` field is being sent as `jobs_enabled` in the GitLab API calls. Use `builds_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#pipelines_enabled Project#pipelines_enabled}
    */
    readonly pipelinesEnabled?: boolean | cdktf.IResolvable;
    /**
    * Whether Secret Push Detection is enabled. Requires GitLab Ultimate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#pre_receive_secret_detection_enabled Project#pre_receive_secret_detection_enabled}
    */
    readonly preReceiveSecretDetectionEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set whether merge requests require an associated issue from Jira. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#prevent_merge_without_jira_issue Project#prevent_merge_without_jira_issue}
    */
    readonly preventMergeWithoutJiraIssue?: boolean | cdktf.IResolvable;
    /**
    * Show link to create/view merge request when pushing from the command line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#printing_merge_request_link_enabled Project#printing_merge_request_link_enabled}
    */
    readonly printingMergeRequestLinkEnabled?: boolean | cdktf.IResolvable;
    /**
    * If true, jobs can be viewed by non-project members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#public_builds Project#public_builds}
    */
    readonly publicBuilds?: boolean | cdktf.IResolvable;
    /**
    * If true, jobs can be viewed by non-project members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#public_jobs Project#public_jobs}
    */
    readonly publicJobs?: boolean | cdktf.IResolvable;
    /**
    * Set the releases access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#releases_access_level Project#releases_access_level}
    */
    readonly releasesAccessLevel?: string;
    /**
    * Enable `Delete source branch` option by default for all new merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#remove_source_branch_after_merge Project#remove_source_branch_after_merge}
    */
    readonly removeSourceBranchAfterMerge?: boolean | cdktf.IResolvable;
    /**
    * Set the repository access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#repository_access_level Project#repository_access_level}
    */
    readonly repositoryAccessLevel?: string;
    /**
    * 	Which storage shard the repository is on. (administrator only)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#repository_storage Project#repository_storage}
    */
    readonly repositoryStorage?: string;
    /**
    * Allow users to request member access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#request_access_enabled Project#request_access_enabled}
    */
    readonly requestAccessEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set the requirements access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#requirements_access_level Project#requirements_access_level}
    */
    readonly requirementsAccessLevel?: string;
    /**
    * Automatically resolve merge request diffs discussions on lines changed with a push.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#resolve_outdated_diff_discussions Project#resolve_outdated_diff_discussions}
    */
    readonly resolveOutdatedDiffDiscussions?: boolean | cdktf.IResolvable;
    /**
    * The default resource group process mode for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#resource_group_default_process_mode Project#resource_group_default_process_mode}
    */
    readonly resourceGroupDefaultProcessMode?: string;
    /**
    * Allow only users with the Maintainer role to pass user-defined variables when triggering a pipeline. Use `ci_pipeline_variables_minimum_override_role` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#restrict_user_defined_variables Project#restrict_user_defined_variables}
    */
    readonly restrictUserDefinedVariables?: boolean | cdktf.IResolvable;
    /**
    * Set the security and compliance access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#security_and_compliance_access_level Project#security_and_compliance_access_level}
    */
    readonly securityAndComplianceAccessLevel?: string;
    /**
    * Enable shared runners for this project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#shared_runners_enabled Project#shared_runners_enabled}
    */
    readonly sharedRunnersEnabled?: boolean | cdktf.IResolvable;
    /**
    * If `true`, the default behavior to wait for the default branch protection to be created is skipped.
    * This is necessary if the current user is not an admin and the default branch protection is disabled on an instance-level.
    * There is currently no known way to determine if the default branch protection is disabled on an instance-level for non-admin users.
    * This attribute is only used during resource creation, thus changes are suppressed and the attribute cannot be imported.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#skip_wait_for_default_branch_protection Project#skip_wait_for_default_branch_protection}
    */
    readonly skipWaitForDefaultBranchProtection?: boolean | cdktf.IResolvable;
    /**
    * Set the snippets access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#snippets_access_level Project#snippets_access_level}
    */
    readonly snippetsAccessLevel?: string;
    /**
    * Enable snippets for the project. Use `snippets_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#snippets_enabled Project#snippets_enabled}
    */
    readonly snippetsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Template used to create squash commit message in merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#squash_commit_template Project#squash_commit_template}
    */
    readonly squashCommitTemplate?: string;
    /**
    * Squash commits when merge request is merged. Valid values are `never` (Do not allow), `always` (Require), `default_on` (Encourage), or `default_off` (Allow). The default value is `default_off` (Allow).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#squash_option Project#squash_option}
    */
    readonly squashOption?: string;
    /**
    * The commit message used to apply merge request suggestions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#suggestion_commit_message Project#suggestion_commit_message}
    */
    readonly suggestionCommitMessage?: string;
    /**
    * The list of tags for a project; put array of tags, that should be finally assigned to a project. Use `topics` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#tags Project#tags}
    */
    readonly tags?: string[];
    /**
    * When used without use_custom_template, name of a built-in project template. When used with use_custom_template, name of a custom project template. This option is mutually exclusive with `template_project_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#template_name Project#template_name}
    */
    readonly templateName?: string;
    /**
    * When used with use_custom_template, project ID of a custom project template. This is preferable to using template_name since template_name may be ambiguous (enterprise edition). This option is mutually exclusive with `template_name`. See `gitlab_group_project_file_template` to set a project as a template project. If a project has not been set as a template, using it here will result in an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#template_project_id Project#template_project_id}
    */
    readonly templateProjectId?: number;
    /**
    * The list of topics for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#topics Project#topics}
    */
    readonly topics?: string[];
    /**
    * Use either custom instance or group (with group_with_project_templates_id) project template (enterprise edition).
    * 		~> When using a custom template, [Group Tokens won't work](https://docs.gitlab.com/15.7/ee/user/project/settings/import_export_troubleshooting/#import-using-the-rest-api-fails-when-using-a-group-access-token). You must use a real user's Personal Access Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#use_custom_template Project#use_custom_template}
    */
    readonly useCustomTemplate?: boolean | cdktf.IResolvable;
    /**
    * Set to `public` to create a public project. Valid values are `private`, `internal`, `public`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#visibility_level Project#visibility_level}
    */
    readonly visibilityLevel?: string;
    /**
    * Set the wiki access level. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#wiki_access_level Project#wiki_access_level}
    */
    readonly wikiAccessLevel?: string;
    /**
    * Enable wiki for the project. Use `wiki_access_level` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#wiki_enabled Project#wiki_enabled}
    */
    readonly wikiEnabled?: boolean | cdktf.IResolvable;
    /**
    * container_expiration_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#container_expiration_policy Project#container_expiration_policy}
    */
    readonly containerExpirationPolicy?: ProjectContainerExpirationPolicy;
    /**
    * push_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#push_rules Project#push_rules}
    */
    readonly pushRules?: ProjectPushRules;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#timeouts Project#timeouts}
    */
    readonly timeouts?: ProjectTimeouts;
}
export interface ProjectContainerExpirationPolicy {
    /**
    * The cadence of the policy. Valid values are: `1d`, `7d`, `14d`, `1month`, `3month`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#cadence Project#cadence}
    */
    readonly cadence?: string;
    /**
    * If true, the policy is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#enabled Project#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The number of images to keep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#keep_n Project#keep_n}
    */
    readonly keepN?: number;
    /**
    * The regular expression to match image names to delete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#name_regex_delete Project#name_regex_delete}
    */
    readonly nameRegexDelete?: string;
    /**
    * The regular expression to match image names to keep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#name_regex_keep Project#name_regex_keep}
    */
    readonly nameRegexKeep?: string;
    /**
    * The number of days to keep images.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#older_than Project#older_than}
    */
    readonly olderThan?: string;
}
export declare function projectContainerExpirationPolicyToTerraform(struct?: ProjectContainerExpirationPolicyOutputReference | ProjectContainerExpirationPolicy): any;
export declare function projectContainerExpirationPolicyToHclTerraform(struct?: ProjectContainerExpirationPolicyOutputReference | ProjectContainerExpirationPolicy): any;
export declare class ProjectContainerExpirationPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectContainerExpirationPolicy | undefined;
    set internalValue(value: ProjectContainerExpirationPolicy | undefined);
    private _cadence?;
    get cadence(): string;
    set cadence(value: string);
    resetCadence(): void;
    get cadenceInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _keepN?;
    get keepN(): number;
    set keepN(value: number);
    resetKeepN(): void;
    get keepNInput(): number | undefined;
    private _nameRegexDelete?;
    get nameRegexDelete(): string;
    set nameRegexDelete(value: string);
    resetNameRegexDelete(): void;
    get nameRegexDeleteInput(): string | undefined;
    private _nameRegexKeep?;
    get nameRegexKeep(): string;
    set nameRegexKeep(value: string);
    resetNameRegexKeep(): void;
    get nameRegexKeepInput(): string | undefined;
    get nextRunAt(): string;
    private _olderThan?;
    get olderThan(): string;
    set olderThan(value: string);
    resetOlderThan(): void;
    get olderThanInput(): string | undefined;
}
export interface ProjectPushRules {
    /**
    * All commit author emails must match this regex, e.g. `@my-company.com$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#author_email_regex Project#author_email_regex}
    */
    readonly authorEmailRegex?: string;
    /**
    * All branch names must match this regex, e.g. `(feature|hotfix)\/*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#branch_name_regex Project#branch_name_regex}
    */
    readonly branchNameRegex?: string;
    /**
    * Users can only push commits to this repository that were committed with one of their own verified emails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#commit_committer_check Project#commit_committer_check}
    */
    readonly commitCommitterCheck?: boolean | cdktf.IResolvable;
    /**
    * Users can only push commits to this repository if the commit author name is consistent with their GitLab account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#commit_committer_name_check Project#commit_committer_name_check}
    */
    readonly commitCommitterNameCheck?: boolean | cdktf.IResolvable;
    /**
    * No commit message is allowed to match this regex, e.g. `ssh\:\/\/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#commit_message_negative_regex Project#commit_message_negative_regex}
    */
    readonly commitMessageNegativeRegex?: string;
    /**
    * All commit messages must match this regex, e.g. `Fixed \d+\..*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#commit_message_regex Project#commit_message_regex}
    */
    readonly commitMessageRegex?: string;
    /**
    * Deny deleting a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#deny_delete_tag Project#deny_delete_tag}
    */
    readonly denyDeleteTag?: boolean | cdktf.IResolvable;
    /**
    * All committed filenames must not match this regex, e.g. `(jar|exe)$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#file_name_regex Project#file_name_regex}
    */
    readonly fileNameRegex?: string;
    /**
    * Maximum file size (MB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#max_file_size Project#max_file_size}
    */
    readonly maxFileSize?: number;
    /**
    * Restrict commits by author (email) to existing GitLab users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#member_check Project#member_check}
    */
    readonly memberCheck?: boolean | cdktf.IResolvable;
    /**
    * GitLab will reject any files that are likely to contain secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#prevent_secrets Project#prevent_secrets}
    */
    readonly preventSecrets?: boolean | cdktf.IResolvable;
    /**
    * Reject commit when it’s not DCO certified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#reject_non_dco_commits Project#reject_non_dco_commits}
    */
    readonly rejectNonDcoCommits?: boolean | cdktf.IResolvable;
    /**
    * Reject commit when it’s not signed through GPG.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#reject_unsigned_commits Project#reject_unsigned_commits}
    */
    readonly rejectUnsignedCommits?: boolean | cdktf.IResolvable;
}
export declare function projectPushRulesToTerraform(struct?: ProjectPushRulesOutputReference | ProjectPushRules): any;
export declare function projectPushRulesToHclTerraform(struct?: ProjectPushRulesOutputReference | ProjectPushRules): any;
export declare class ProjectPushRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectPushRules | undefined;
    set internalValue(value: ProjectPushRules | undefined);
    private _authorEmailRegex?;
    get authorEmailRegex(): string;
    set authorEmailRegex(value: string);
    resetAuthorEmailRegex(): void;
    get authorEmailRegexInput(): string | undefined;
    private _branchNameRegex?;
    get branchNameRegex(): string;
    set branchNameRegex(value: string);
    resetBranchNameRegex(): void;
    get branchNameRegexInput(): string | undefined;
    private _commitCommitterCheck?;
    get commitCommitterCheck(): boolean | cdktf.IResolvable;
    set commitCommitterCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterCheck(): void;
    get commitCommitterCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitCommitterNameCheck?;
    get commitCommitterNameCheck(): boolean | cdktf.IResolvable;
    set commitCommitterNameCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterNameCheck(): void;
    get commitCommitterNameCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitMessageNegativeRegex?;
    get commitMessageNegativeRegex(): string;
    set commitMessageNegativeRegex(value: string);
    resetCommitMessageNegativeRegex(): void;
    get commitMessageNegativeRegexInput(): string | undefined;
    private _commitMessageRegex?;
    get commitMessageRegex(): string;
    set commitMessageRegex(value: string);
    resetCommitMessageRegex(): void;
    get commitMessageRegexInput(): string | undefined;
    private _denyDeleteTag?;
    get denyDeleteTag(): boolean | cdktf.IResolvable;
    set denyDeleteTag(value: boolean | cdktf.IResolvable);
    resetDenyDeleteTag(): void;
    get denyDeleteTagInput(): boolean | cdktf.IResolvable | undefined;
    private _fileNameRegex?;
    get fileNameRegex(): string;
    set fileNameRegex(value: string);
    resetFileNameRegex(): void;
    get fileNameRegexInput(): string | undefined;
    private _maxFileSize?;
    get maxFileSize(): number;
    set maxFileSize(value: number);
    resetMaxFileSize(): void;
    get maxFileSizeInput(): number | undefined;
    private _memberCheck?;
    get memberCheck(): boolean | cdktf.IResolvable;
    set memberCheck(value: boolean | cdktf.IResolvable);
    resetMemberCheck(): void;
    get memberCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _preventSecrets?;
    get preventSecrets(): boolean | cdktf.IResolvable;
    set preventSecrets(value: boolean | cdktf.IResolvable);
    resetPreventSecrets(): void;
    get preventSecretsInput(): boolean | cdktf.IResolvable | undefined;
    private _rejectNonDcoCommits?;
    get rejectNonDcoCommits(): boolean | cdktf.IResolvable;
    set rejectNonDcoCommits(value: boolean | cdktf.IResolvable);
    resetRejectNonDcoCommits(): void;
    get rejectNonDcoCommitsInput(): boolean | cdktf.IResolvable | undefined;
    private _rejectUnsignedCommits?;
    get rejectUnsignedCommits(): boolean | cdktf.IResolvable;
    set rejectUnsignedCommits(value: boolean | cdktf.IResolvable);
    resetRejectUnsignedCommits(): void;
    get rejectUnsignedCommitsInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ProjectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#create Project#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#delete Project#delete}
    */
    readonly delete?: string;
}
export declare function projectTimeoutsToTerraform(struct?: ProjectTimeouts | cdktf.IResolvable): any;
export declare function projectTimeoutsToHclTerraform(struct?: ProjectTimeouts | cdktf.IResolvable): any;
export declare class ProjectTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project gitlab_project}
*/
export declare class Project extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project";
    /**
    * Generates CDKTF code for importing a Project resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Project to import
    * @param importFromId The id of the existing Project that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Project to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project gitlab_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectConfig
    */
    constructor(scope: Construct, id: string, config: ProjectConfig);
    private _allowMergeOnSkippedPipeline?;
    get allowMergeOnSkippedPipeline(): boolean | cdktf.IResolvable;
    set allowMergeOnSkippedPipeline(value: boolean | cdktf.IResolvable);
    resetAllowMergeOnSkippedPipeline(): void;
    get allowMergeOnSkippedPipelineInput(): boolean | cdktf.IResolvable | undefined;
    private _allowPipelineTriggerApproveDeployment?;
    get allowPipelineTriggerApproveDeployment(): boolean | cdktf.IResolvable;
    set allowPipelineTriggerApproveDeployment(value: boolean | cdktf.IResolvable);
    resetAllowPipelineTriggerApproveDeployment(): void;
    get allowPipelineTriggerApproveDeploymentInput(): boolean | cdktf.IResolvable | undefined;
    private _analyticsAccessLevel?;
    get analyticsAccessLevel(): string;
    set analyticsAccessLevel(value: string);
    resetAnalyticsAccessLevel(): void;
    get analyticsAccessLevelInput(): string | undefined;
    private _approvalsBeforeMerge?;
    get approvalsBeforeMerge(): number;
    set approvalsBeforeMerge(value: number);
    resetApprovalsBeforeMerge(): void;
    get approvalsBeforeMergeInput(): number | undefined;
    private _archiveOnDestroy?;
    get archiveOnDestroy(): boolean | cdktf.IResolvable;
    set archiveOnDestroy(value: boolean | cdktf.IResolvable);
    resetArchiveOnDestroy(): void;
    get archiveOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _archived?;
    get archived(): boolean | cdktf.IResolvable;
    set archived(value: boolean | cdktf.IResolvable);
    resetArchived(): void;
    get archivedInput(): boolean | cdktf.IResolvable | undefined;
    private _autoCancelPendingPipelines?;
    get autoCancelPendingPipelines(): string;
    set autoCancelPendingPipelines(value: string);
    resetAutoCancelPendingPipelines(): void;
    get autoCancelPendingPipelinesInput(): string | undefined;
    private _autoDevopsDeployStrategy?;
    get autoDevopsDeployStrategy(): string;
    set autoDevopsDeployStrategy(value: string);
    resetAutoDevopsDeployStrategy(): void;
    get autoDevopsDeployStrategyInput(): string | undefined;
    private _autoDevopsEnabled?;
    get autoDevopsEnabled(): boolean | cdktf.IResolvable;
    set autoDevopsEnabled(value: boolean | cdktf.IResolvable);
    resetAutoDevopsEnabled(): void;
    get autoDevopsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _autoDuoCodeReviewEnabled?;
    get autoDuoCodeReviewEnabled(): boolean | cdktf.IResolvable;
    set autoDuoCodeReviewEnabled(value: boolean | cdktf.IResolvable);
    resetAutoDuoCodeReviewEnabled(): void;
    get autoDuoCodeReviewEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _autocloseReferencedIssues?;
    get autocloseReferencedIssues(): boolean | cdktf.IResolvable;
    set autocloseReferencedIssues(value: boolean | cdktf.IResolvable);
    resetAutocloseReferencedIssues(): void;
    get autocloseReferencedIssuesInput(): boolean | cdktf.IResolvable | undefined;
    private _avatar?;
    get avatar(): string;
    set avatar(value: string);
    resetAvatar(): void;
    get avatarInput(): string | undefined;
    private _avatarHash?;
    get avatarHash(): string;
    set avatarHash(value: string);
    resetAvatarHash(): void;
    get avatarHashInput(): string | undefined;
    get avatarUrl(): string;
    private _branches?;
    get branches(): string;
    set branches(value: string);
    resetBranches(): void;
    get branchesInput(): string | undefined;
    private _buildGitStrategy?;
    get buildGitStrategy(): string;
    set buildGitStrategy(value: string);
    resetBuildGitStrategy(): void;
    get buildGitStrategyInput(): string | undefined;
    private _buildTimeout?;
    get buildTimeout(): number;
    set buildTimeout(value: number);
    resetBuildTimeout(): void;
    get buildTimeoutInput(): number | undefined;
    private _buildsAccessLevel?;
    get buildsAccessLevel(): string;
    set buildsAccessLevel(value: string);
    resetBuildsAccessLevel(): void;
    get buildsAccessLevelInput(): string | undefined;
    private _ciConfigPath?;
    get ciConfigPath(): string;
    set ciConfigPath(value: string);
    resetCiConfigPath(): void;
    get ciConfigPathInput(): string | undefined;
    private _ciDefaultGitDepth?;
    get ciDefaultGitDepth(): number;
    set ciDefaultGitDepth(value: number);
    resetCiDefaultGitDepth(): void;
    get ciDefaultGitDepthInput(): number | undefined;
    private _ciDeletePipelinesInSeconds?;
    get ciDeletePipelinesInSeconds(): number;
    set ciDeletePipelinesInSeconds(value: number);
    resetCiDeletePipelinesInSeconds(): void;
    get ciDeletePipelinesInSecondsInput(): number | undefined;
    private _ciForwardDeploymentEnabled?;
    get ciForwardDeploymentEnabled(): boolean | cdktf.IResolvable;
    set ciForwardDeploymentEnabled(value: boolean | cdktf.IResolvable);
    resetCiForwardDeploymentEnabled(): void;
    get ciForwardDeploymentEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _ciForwardDeploymentRollbackAllowed?;
    get ciForwardDeploymentRollbackAllowed(): boolean | cdktf.IResolvable;
    set ciForwardDeploymentRollbackAllowed(value: boolean | cdktf.IResolvable);
    resetCiForwardDeploymentRollbackAllowed(): void;
    get ciForwardDeploymentRollbackAllowedInput(): boolean | cdktf.IResolvable | undefined;
    private _ciIdTokenSubClaimComponents?;
    get ciIdTokenSubClaimComponents(): string[];
    set ciIdTokenSubClaimComponents(value: string[]);
    resetCiIdTokenSubClaimComponents(): void;
    get ciIdTokenSubClaimComponentsInput(): string[] | undefined;
    private _ciPipelineVariablesMinimumOverrideRole?;
    get ciPipelineVariablesMinimumOverrideRole(): string;
    set ciPipelineVariablesMinimumOverrideRole(value: string);
    resetCiPipelineVariablesMinimumOverrideRole(): void;
    get ciPipelineVariablesMinimumOverrideRoleInput(): string | undefined;
    private _ciPushRepositoryForJobTokenAllowed?;
    get ciPushRepositoryForJobTokenAllowed(): boolean | cdktf.IResolvable;
    set ciPushRepositoryForJobTokenAllowed(value: boolean | cdktf.IResolvable);
    resetCiPushRepositoryForJobTokenAllowed(): void;
    get ciPushRepositoryForJobTokenAllowedInput(): boolean | cdktf.IResolvable | undefined;
    private _ciRestrictPipelineCancellationRole?;
    get ciRestrictPipelineCancellationRole(): string;
    set ciRestrictPipelineCancellationRole(value: string);
    resetCiRestrictPipelineCancellationRole(): void;
    get ciRestrictPipelineCancellationRoleInput(): string | undefined;
    private _ciSeparatedCaches?;
    get ciSeparatedCaches(): boolean | cdktf.IResolvable;
    set ciSeparatedCaches(value: boolean | cdktf.IResolvable);
    resetCiSeparatedCaches(): void;
    get ciSeparatedCachesInput(): boolean | cdktf.IResolvable | undefined;
    private _containerRegistryAccessLevel?;
    get containerRegistryAccessLevel(): string;
    set containerRegistryAccessLevel(value: string);
    resetContainerRegistryAccessLevel(): void;
    get containerRegistryAccessLevelInput(): string | undefined;
    private _containerRegistryEnabled?;
    get containerRegistryEnabled(): boolean | cdktf.IResolvable;
    set containerRegistryEnabled(value: boolean | cdktf.IResolvable);
    resetContainerRegistryEnabled(): void;
    get containerRegistryEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    resetDefaultBranch(): void;
    get defaultBranchInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _emailsEnabled?;
    get emailsEnabled(): boolean | cdktf.IResolvable;
    set emailsEnabled(value: boolean | cdktf.IResolvable);
    resetEmailsEnabled(): void;
    get emailsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    get emptyRepo(): cdktf.IResolvable;
    private _environmentsAccessLevel?;
    get environmentsAccessLevel(): string;
    set environmentsAccessLevel(value: string);
    resetEnvironmentsAccessLevel(): void;
    get environmentsAccessLevelInput(): string | undefined;
    private _externalAuthorizationClassificationLabel?;
    get externalAuthorizationClassificationLabel(): string;
    set externalAuthorizationClassificationLabel(value: string);
    resetExternalAuthorizationClassificationLabel(): void;
    get externalAuthorizationClassificationLabelInput(): string | undefined;
    private _featureFlagsAccessLevel?;
    get featureFlagsAccessLevel(): string;
    set featureFlagsAccessLevel(value: string);
    resetFeatureFlagsAccessLevel(): void;
    get featureFlagsAccessLevelInput(): string | undefined;
    private _forkedFromProjectId?;
    get forkedFromProjectId(): number;
    set forkedFromProjectId(value: number);
    resetForkedFromProjectId(): void;
    get forkedFromProjectIdInput(): number | undefined;
    private _forkingAccessLevel?;
    get forkingAccessLevel(): string;
    set forkingAccessLevel(value: string);
    resetForkingAccessLevel(): void;
    get forkingAccessLevelInput(): string | undefined;
    private _groupRunnersEnabled?;
    get groupRunnersEnabled(): boolean | cdktf.IResolvable;
    set groupRunnersEnabled(value: boolean | cdktf.IResolvable);
    resetGroupRunnersEnabled(): void;
    get groupRunnersEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _groupWithProjectTemplatesId?;
    get groupWithProjectTemplatesId(): number;
    set groupWithProjectTemplatesId(value: number);
    resetGroupWithProjectTemplatesId(): void;
    get groupWithProjectTemplatesIdInput(): number | undefined;
    get httpUrlToRepo(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importUrl?;
    get importUrl(): string;
    set importUrl(value: string);
    resetImportUrl(): void;
    get importUrlInput(): string | undefined;
    private _importUrlPassword?;
    get importUrlPassword(): string;
    set importUrlPassword(value: string);
    resetImportUrlPassword(): void;
    get importUrlPasswordInput(): string | undefined;
    private _importUrlUsername?;
    get importUrlUsername(): string;
    set importUrlUsername(value: string);
    resetImportUrlUsername(): void;
    get importUrlUsernameInput(): string | undefined;
    private _infrastructureAccessLevel?;
    get infrastructureAccessLevel(): string;
    set infrastructureAccessLevel(value: string);
    resetInfrastructureAccessLevel(): void;
    get infrastructureAccessLevelInput(): string | undefined;
    private _initializeWithReadme?;
    get initializeWithReadme(): boolean | cdktf.IResolvable;
    set initializeWithReadme(value: boolean | cdktf.IResolvable);
    resetInitializeWithReadme(): void;
    get initializeWithReadmeInput(): boolean | cdktf.IResolvable | undefined;
    private _issuesAccessLevel?;
    get issuesAccessLevel(): string;
    set issuesAccessLevel(value: string);
    resetIssuesAccessLevel(): void;
    get issuesAccessLevelInput(): string | undefined;
    private _issuesEnabled?;
    get issuesEnabled(): boolean | cdktf.IResolvable;
    set issuesEnabled(value: boolean | cdktf.IResolvable);
    resetIssuesEnabled(): void;
    get issuesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _issuesTemplate?;
    get issuesTemplate(): string;
    set issuesTemplate(value: string);
    resetIssuesTemplate(): void;
    get issuesTemplateInput(): string | undefined;
    private _keepLatestArtifact?;
    get keepLatestArtifact(): boolean | cdktf.IResolvable;
    set keepLatestArtifact(value: boolean | cdktf.IResolvable);
    resetKeepLatestArtifact(): void;
    get keepLatestArtifactInput(): boolean | cdktf.IResolvable | undefined;
    private _lfsEnabled?;
    get lfsEnabled(): boolean | cdktf.IResolvable;
    set lfsEnabled(value: boolean | cdktf.IResolvable);
    resetLfsEnabled(): void;
    get lfsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeCommitTemplate?;
    get mergeCommitTemplate(): string;
    set mergeCommitTemplate(value: string);
    resetMergeCommitTemplate(): void;
    get mergeCommitTemplateInput(): string | undefined;
    private _mergeMethod?;
    get mergeMethod(): string;
    set mergeMethod(value: string);
    resetMergeMethod(): void;
    get mergeMethodInput(): string | undefined;
    private _mergePipelinesEnabled?;
    get mergePipelinesEnabled(): boolean | cdktf.IResolvable;
    set mergePipelinesEnabled(value: boolean | cdktf.IResolvable);
    resetMergePipelinesEnabled(): void;
    get mergePipelinesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestsAccessLevel?;
    get mergeRequestsAccessLevel(): string;
    set mergeRequestsAccessLevel(value: string);
    resetMergeRequestsAccessLevel(): void;
    get mergeRequestsAccessLevelInput(): string | undefined;
    private _mergeRequestsEnabled?;
    get mergeRequestsEnabled(): boolean | cdktf.IResolvable;
    set mergeRequestsEnabled(value: boolean | cdktf.IResolvable);
    resetMergeRequestsEnabled(): void;
    get mergeRequestsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestsTemplate?;
    get mergeRequestsTemplate(): string;
    set mergeRequestsTemplate(value: string);
    resetMergeRequestsTemplate(): void;
    get mergeRequestsTemplateInput(): string | undefined;
    private _mergeTrainsEnabled?;
    get mergeTrainsEnabled(): boolean | cdktf.IResolvable;
    set mergeTrainsEnabled(value: boolean | cdktf.IResolvable);
    resetMergeTrainsEnabled(): void;
    get mergeTrainsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _mirror?;
    get mirror(): boolean | cdktf.IResolvable;
    set mirror(value: boolean | cdktf.IResolvable);
    resetMirror(): void;
    get mirrorInput(): boolean | cdktf.IResolvable | undefined;
    private _mirrorOverwritesDivergedBranches?;
    get mirrorOverwritesDivergedBranches(): boolean | cdktf.IResolvable;
    set mirrorOverwritesDivergedBranches(value: boolean | cdktf.IResolvable);
    resetMirrorOverwritesDivergedBranches(): void;
    get mirrorOverwritesDivergedBranchesInput(): boolean | cdktf.IResolvable | undefined;
    private _mirrorTriggerBuilds?;
    get mirrorTriggerBuilds(): boolean | cdktf.IResolvable;
    set mirrorTriggerBuilds(value: boolean | cdktf.IResolvable);
    resetMirrorTriggerBuilds(): void;
    get mirrorTriggerBuildsInput(): boolean | cdktf.IResolvable | undefined;
    private _modelExperimentsAccessLevel?;
    get modelExperimentsAccessLevel(): string;
    set modelExperimentsAccessLevel(value: string);
    resetModelExperimentsAccessLevel(): void;
    get modelExperimentsAccessLevelInput(): string | undefined;
    private _modelRegistryAccessLevel?;
    get modelRegistryAccessLevel(): string;
    set modelRegistryAccessLevel(value: string);
    resetModelRegistryAccessLevel(): void;
    get modelRegistryAccessLevelInput(): string | undefined;
    private _monitorAccessLevel?;
    get monitorAccessLevel(): string;
    set monitorAccessLevel(value: string);
    resetMonitorAccessLevel(): void;
    get monitorAccessLevelInput(): string | undefined;
    private _mrDefaultTargetSelf?;
    get mrDefaultTargetSelf(): boolean | cdktf.IResolvable;
    set mrDefaultTargetSelf(value: boolean | cdktf.IResolvable);
    resetMrDefaultTargetSelf(): void;
    get mrDefaultTargetSelfInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceId?;
    get namespaceId(): number;
    set namespaceId(value: number);
    resetNamespaceId(): void;
    get namespaceIdInput(): number | undefined;
    private _onlyAllowMergeIfAllDiscussionsAreResolved?;
    get onlyAllowMergeIfAllDiscussionsAreResolved(): boolean | cdktf.IResolvable;
    set onlyAllowMergeIfAllDiscussionsAreResolved(value: boolean | cdktf.IResolvable);
    resetOnlyAllowMergeIfAllDiscussionsAreResolved(): void;
    get onlyAllowMergeIfAllDiscussionsAreResolvedInput(): boolean | cdktf.IResolvable | undefined;
    private _onlyAllowMergeIfPipelineSucceeds?;
    get onlyAllowMergeIfPipelineSucceeds(): boolean | cdktf.IResolvable;
    set onlyAllowMergeIfPipelineSucceeds(value: boolean | cdktf.IResolvable);
    resetOnlyAllowMergeIfPipelineSucceeds(): void;
    get onlyAllowMergeIfPipelineSucceedsInput(): boolean | cdktf.IResolvable | undefined;
    private _onlyMirrorProtectedBranches?;
    get onlyMirrorProtectedBranches(): boolean | cdktf.IResolvable;
    set onlyMirrorProtectedBranches(value: boolean | cdktf.IResolvable);
    resetOnlyMirrorProtectedBranches(): void;
    get onlyMirrorProtectedBranchesInput(): boolean | cdktf.IResolvable | undefined;
    private _packagesEnabled?;
    get packagesEnabled(): boolean | cdktf.IResolvable;
    set packagesEnabled(value: boolean | cdktf.IResolvable);
    resetPackagesEnabled(): void;
    get packagesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _pagesAccessLevel?;
    get pagesAccessLevel(): string;
    set pagesAccessLevel(value: string);
    resetPagesAccessLevel(): void;
    get pagesAccessLevelInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    get pathWithNamespace(): string;
    private _permanentlyDeleteOnDestroy?;
    get permanentlyDeleteOnDestroy(): boolean | cdktf.IResolvable;
    set permanentlyDeleteOnDestroy(value: boolean | cdktf.IResolvable);
    resetPermanentlyDeleteOnDestroy(): void;
    get permanentlyDeleteOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _pipelinesEnabled?;
    get pipelinesEnabled(): boolean | cdktf.IResolvable;
    set pipelinesEnabled(value: boolean | cdktf.IResolvable);
    resetPipelinesEnabled(): void;
    get pipelinesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _preReceiveSecretDetectionEnabled?;
    get preReceiveSecretDetectionEnabled(): boolean | cdktf.IResolvable;
    set preReceiveSecretDetectionEnabled(value: boolean | cdktf.IResolvable);
    resetPreReceiveSecretDetectionEnabled(): void;
    get preReceiveSecretDetectionEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _preventMergeWithoutJiraIssue?;
    get preventMergeWithoutJiraIssue(): boolean | cdktf.IResolvable;
    set preventMergeWithoutJiraIssue(value: boolean | cdktf.IResolvable);
    resetPreventMergeWithoutJiraIssue(): void;
    get preventMergeWithoutJiraIssueInput(): boolean | cdktf.IResolvable | undefined;
    private _printingMergeRequestLinkEnabled?;
    get printingMergeRequestLinkEnabled(): boolean | cdktf.IResolvable;
    set printingMergeRequestLinkEnabled(value: boolean | cdktf.IResolvable);
    resetPrintingMergeRequestLinkEnabled(): void;
    get printingMergeRequestLinkEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _publicBuilds?;
    get publicBuilds(): boolean | cdktf.IResolvable;
    set publicBuilds(value: boolean | cdktf.IResolvable);
    resetPublicBuilds(): void;
    get publicBuildsInput(): boolean | cdktf.IResolvable | undefined;
    private _publicJobs?;
    get publicJobs(): boolean | cdktf.IResolvable;
    set publicJobs(value: boolean | cdktf.IResolvable);
    resetPublicJobs(): void;
    get publicJobsInput(): boolean | cdktf.IResolvable | undefined;
    private _releasesAccessLevel?;
    get releasesAccessLevel(): string;
    set releasesAccessLevel(value: string);
    resetReleasesAccessLevel(): void;
    get releasesAccessLevelInput(): string | undefined;
    private _removeSourceBranchAfterMerge?;
    get removeSourceBranchAfterMerge(): boolean | cdktf.IResolvable;
    set removeSourceBranchAfterMerge(value: boolean | cdktf.IResolvable);
    resetRemoveSourceBranchAfterMerge(): void;
    get removeSourceBranchAfterMergeInput(): boolean | cdktf.IResolvable | undefined;
    private _repositoryAccessLevel?;
    get repositoryAccessLevel(): string;
    set repositoryAccessLevel(value: string);
    resetRepositoryAccessLevel(): void;
    get repositoryAccessLevelInput(): string | undefined;
    private _repositoryStorage?;
    get repositoryStorage(): string;
    set repositoryStorage(value: string);
    resetRepositoryStorage(): void;
    get repositoryStorageInput(): string | undefined;
    private _requestAccessEnabled?;
    get requestAccessEnabled(): boolean | cdktf.IResolvable;
    set requestAccessEnabled(value: boolean | cdktf.IResolvable);
    resetRequestAccessEnabled(): void;
    get requestAccessEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _requirementsAccessLevel?;
    get requirementsAccessLevel(): string;
    set requirementsAccessLevel(value: string);
    resetRequirementsAccessLevel(): void;
    get requirementsAccessLevelInput(): string | undefined;
    private _resolveOutdatedDiffDiscussions?;
    get resolveOutdatedDiffDiscussions(): boolean | cdktf.IResolvable;
    set resolveOutdatedDiffDiscussions(value: boolean | cdktf.IResolvable);
    resetResolveOutdatedDiffDiscussions(): void;
    get resolveOutdatedDiffDiscussionsInput(): boolean | cdktf.IResolvable | undefined;
    private _resourceGroupDefaultProcessMode?;
    get resourceGroupDefaultProcessMode(): string;
    set resourceGroupDefaultProcessMode(value: string);
    resetResourceGroupDefaultProcessMode(): void;
    get resourceGroupDefaultProcessModeInput(): string | undefined;
    private _restrictUserDefinedVariables?;
    get restrictUserDefinedVariables(): boolean | cdktf.IResolvable;
    set restrictUserDefinedVariables(value: boolean | cdktf.IResolvable);
    resetRestrictUserDefinedVariables(): void;
    get restrictUserDefinedVariablesInput(): boolean | cdktf.IResolvable | undefined;
    get runnersToken(): string;
    private _securityAndComplianceAccessLevel?;
    get securityAndComplianceAccessLevel(): string;
    set securityAndComplianceAccessLevel(value: string);
    resetSecurityAndComplianceAccessLevel(): void;
    get securityAndComplianceAccessLevelInput(): string | undefined;
    private _sharedRunnersEnabled?;
    get sharedRunnersEnabled(): boolean | cdktf.IResolvable;
    set sharedRunnersEnabled(value: boolean | cdktf.IResolvable);
    resetSharedRunnersEnabled(): void;
    get sharedRunnersEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _skipWaitForDefaultBranchProtection?;
    get skipWaitForDefaultBranchProtection(): boolean | cdktf.IResolvable;
    set skipWaitForDefaultBranchProtection(value: boolean | cdktf.IResolvable);
    resetSkipWaitForDefaultBranchProtection(): void;
    get skipWaitForDefaultBranchProtectionInput(): boolean | cdktf.IResolvable | undefined;
    private _snippetsAccessLevel?;
    get snippetsAccessLevel(): string;
    set snippetsAccessLevel(value: string);
    resetSnippetsAccessLevel(): void;
    get snippetsAccessLevelInput(): string | undefined;
    private _snippetsEnabled?;
    get snippetsEnabled(): boolean | cdktf.IResolvable;
    set snippetsEnabled(value: boolean | cdktf.IResolvable);
    resetSnippetsEnabled(): void;
    get snippetsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _squashCommitTemplate?;
    get squashCommitTemplate(): string;
    set squashCommitTemplate(value: string);
    resetSquashCommitTemplate(): void;
    get squashCommitTemplateInput(): string | undefined;
    private _squashOption?;
    get squashOption(): string;
    set squashOption(value: string);
    resetSquashOption(): void;
    get squashOptionInput(): string | undefined;
    get sshUrlToRepo(): string;
    private _suggestionCommitMessage?;
    get suggestionCommitMessage(): string;
    set suggestionCommitMessage(value: string);
    resetSuggestionCommitMessage(): void;
    get suggestionCommitMessageInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    resetTemplateName(): void;
    get templateNameInput(): string | undefined;
    private _templateProjectId?;
    get templateProjectId(): number;
    set templateProjectId(value: number);
    resetTemplateProjectId(): void;
    get templateProjectIdInput(): number | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _useCustomTemplate?;
    get useCustomTemplate(): boolean | cdktf.IResolvable;
    set useCustomTemplate(value: boolean | cdktf.IResolvable);
    resetUseCustomTemplate(): void;
    get useCustomTemplateInput(): boolean | cdktf.IResolvable | undefined;
    private _visibilityLevel?;
    get visibilityLevel(): string;
    set visibilityLevel(value: string);
    resetVisibilityLevel(): void;
    get visibilityLevelInput(): string | undefined;
    get webUrl(): string;
    private _wikiAccessLevel?;
    get wikiAccessLevel(): string;
    set wikiAccessLevel(value: string);
    resetWikiAccessLevel(): void;
    get wikiAccessLevelInput(): string | undefined;
    private _wikiEnabled?;
    get wikiEnabled(): boolean | cdktf.IResolvable;
    set wikiEnabled(value: boolean | cdktf.IResolvable);
    resetWikiEnabled(): void;
    get wikiEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _containerExpirationPolicy;
    get containerExpirationPolicy(): ProjectContainerExpirationPolicyOutputReference;
    putContainerExpirationPolicy(value: ProjectContainerExpirationPolicy): void;
    resetContainerExpirationPolicy(): void;
    get containerExpirationPolicyInput(): ProjectContainerExpirationPolicy | undefined;
    private _pushRules;
    get pushRules(): ProjectPushRulesOutputReference;
    putPushRules(value: ProjectPushRules): void;
    resetPushRules(): void;
    get pushRulesInput(): ProjectPushRules | undefined;
    private _timeouts;
    get timeouts(): ProjectTimeoutsOutputReference;
    putTimeouts(value: ProjectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ProjectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
