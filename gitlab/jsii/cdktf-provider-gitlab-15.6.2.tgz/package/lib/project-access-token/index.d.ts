/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access level for the project access token. Valid values are: `no one`, `minimal`, `guest`, `planner`, `reporter`, `developer`, `maintainer`, `owner`. Default is `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#access_level ProjectAccessToken#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The description of the project access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#description ProjectAccessToken#description}
    */
    readonly description?: string;
    /**
    * When the token will expire, YYYY-MM-DD format. Is automatically set when `rotation_configuration` is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#expires_at ProjectAccessToken#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The name of the project access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#name ProjectAccessToken#name}
    */
    readonly name: string;
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#project ProjectAccessToken#project}
    */
    readonly project: string;
    /**
    * The configuration for when to rotate a token automatically. Will not rotate a token until `terraform apply` is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#rotation_configuration ProjectAccessToken#rotation_configuration}
    */
    readonly rotationConfiguration?: ProjectAccessTokenRotationConfiguration;
    /**
    * The scopes of the project access token. valid values are: `api`, `read_api`, `read_registry`, `write_registry`, `read_repository`, `write_repository`, `create_runner`, `manage_runner`, `ai_features`, `k8s_proxy`, `read_observability`, `write_observability`, `self_rotate`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#scopes ProjectAccessToken#scopes}
    */
    readonly scopes: string[];
    /**
    * Wether to validate if the expiration date is in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#validate_past_expiration_date ProjectAccessToken#validate_past_expiration_date}
    */
    readonly validatePastExpirationDate?: boolean | cdktf.IResolvable;
}
export interface ProjectAccessTokenRotationConfiguration {
    /**
    * The duration (in days) the new token should be valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#expiration_days ProjectAccessToken#expiration_days}
    */
    readonly expirationDays: number;
    /**
    * The duration (in days) before the expiration when the token should be rotated. As an example, if set to 7 days, the token will rotate 7 days before the expiration date, but only when `terraform apply` is run in that timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#rotate_before_days ProjectAccessToken#rotate_before_days}
    */
    readonly rotateBeforeDays: number;
}
export declare function projectAccessTokenRotationConfigurationToTerraform(struct?: ProjectAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare function projectAccessTokenRotationConfigurationToHclTerraform(struct?: ProjectAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare class ProjectAccessTokenRotationConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectAccessTokenRotationConfiguration | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectAccessTokenRotationConfiguration | cdktf.IResolvable | undefined);
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    get expirationDaysInput(): number | undefined;
    private _rotateBeforeDays?;
    get rotateBeforeDays(): number;
    set rotateBeforeDays(value: number);
    get rotateBeforeDaysInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token gitlab_project_access_token}
*/
export declare class ProjectAccessToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_access_token";
    /**
    * Generates CDKTF code for importing a ProjectAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectAccessToken to import
    * @param importFromId The id of the existing ProjectAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_access_token gitlab_project_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: ProjectAccessTokenConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get revoked(): cdktf.IResolvable;
    private _rotationConfiguration;
    get rotationConfiguration(): ProjectAccessTokenRotationConfigurationOutputReference;
    putRotationConfiguration(value: ProjectAccessTokenRotationConfiguration): void;
    resetRotationConfiguration(): void;
    get rotationConfigurationInput(): cdktf.IResolvable | ProjectAccessTokenRotationConfiguration | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    get token(): string;
    get userId(): number;
    private _validatePastExpirationDate?;
    get validatePastExpirationDate(): boolean | cdktf.IResolvable;
    set validatePastExpirationDate(value: boolean | cdktf.IResolvable);
    resetValidatePastExpirationDate(): void;
    get validatePastExpirationDateInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
