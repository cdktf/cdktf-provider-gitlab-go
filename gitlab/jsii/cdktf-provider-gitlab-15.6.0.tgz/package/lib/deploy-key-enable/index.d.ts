/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DeployKeyEnableConfig extends cdktf.TerraformMetaArguments {
    /**
    * Can deploy key push to the project's repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable#can_push DeployKeyEnable#can_push}
    */
    readonly canPush?: boolean | cdktf.IResolvable;
    /**
    * The Gitlab key id for the pre-existing deploy key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable#key_id DeployKeyEnable#key_id}
    */
    readonly keyId: string;
    /**
    * The name or id of the project to add the deploy key to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable#project DeployKeyEnable#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable gitlab_deploy_key_enable}
*/
export declare class DeployKeyEnable extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_deploy_key_enable";
    /**
    * Generates CDKTF code for importing a DeployKeyEnable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeployKeyEnable to import
    * @param importFromId The id of the existing DeployKeyEnable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeployKeyEnable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/deploy_key_enable gitlab_deploy_key_enable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeployKeyEnableConfig
    */
    constructor(scope: Construct, id: string, config: DeployKeyEnableConfig);
    private _canPush?;
    get canPush(): boolean | cdktf.IResolvable;
    set canPush(value: boolean | cdktf.IResolvable);
    resetCanPush(): void;
    get canPushInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    get key(): string;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get title(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
