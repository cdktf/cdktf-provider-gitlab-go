/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupSecurityPolicyAttachmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or Full Path of the group which will have the security policy project assigned to it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_security_policy_attachment#group GroupSecurityPolicyAttachment#group}
    */
    readonly group: string;
    /**
    * The ID or Full Path of the security policy project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_security_policy_attachment#policy_project GroupSecurityPolicyAttachment#policy_project}
    */
    readonly policyProject: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_security_policy_attachment gitlab_group_security_policy_attachment}
*/
export declare class GroupSecurityPolicyAttachment extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_security_policy_attachment";
    /**
    * Generates CDKTF code for importing a GroupSecurityPolicyAttachment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupSecurityPolicyAttachment to import
    * @param importFromId The id of the existing GroupSecurityPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_security_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupSecurityPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_security_policy_attachment gitlab_group_security_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupSecurityPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: GroupSecurityPolicyAttachmentConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get groupGraphqlId(): string;
    get id(): string;
    private _policyProject?;
    get policyProject(): string;
    set policyProject(value: string);
    get policyProjectInput(): string | undefined;
    get policyProjectGraphqlId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
