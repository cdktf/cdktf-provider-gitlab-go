/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectApprovalRulesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or path with namespace that identifies the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_approval_rules#project DataGitlabProjectApprovalRules#project}
    */
    readonly project: string;
    /**
    * approval_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_approval_rules#approval_rules DataGitlabProjectApprovalRules#approval_rules}
    */
    readonly approvalRules?: DataGitlabProjectApprovalRulesApprovalRules[] | cdktf.IResolvable;
}
export interface DataGitlabProjectApprovalRulesApprovalRules {
}
export declare function dataGitlabProjectApprovalRulesApprovalRulesToTerraform(struct?: DataGitlabProjectApprovalRulesApprovalRules | cdktf.IResolvable): any;
export declare function dataGitlabProjectApprovalRulesApprovalRulesToHclTerraform(struct?: DataGitlabProjectApprovalRulesApprovalRules | cdktf.IResolvable): any;
export declare class DataGitlabProjectApprovalRulesApprovalRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectApprovalRulesApprovalRules | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectApprovalRulesApprovalRules | cdktf.IResolvable | undefined);
    get appliesToAllProtectedBranches(): cdktf.IResolvable;
    get approvalsRequired(): number;
    get eligibleApproverIds(): number[];
    get groupIds(): number[];
    get id(): number;
    get name(): string;
    get protectedBranchIds(): number[];
    get reportType(): string;
    get ruleType(): string;
    get userIds(): number[];
}
export declare class DataGitlabProjectApprovalRulesApprovalRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectApprovalRulesApprovalRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectApprovalRulesApprovalRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_approval_rules gitlab_project_approval_rules}
*/
export declare class DataGitlabProjectApprovalRules extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_approval_rules";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectApprovalRules resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectApprovalRules to import
    * @param importFromId The id of the existing DataGitlabProjectApprovalRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_approval_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectApprovalRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_approval_rules gitlab_project_approval_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectApprovalRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectApprovalRulesConfig);
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _approvalRules;
    get approvalRules(): DataGitlabProjectApprovalRulesApprovalRulesList;
    putApprovalRules(value: DataGitlabProjectApprovalRulesApprovalRules[] | cdktf.IResolvable): void;
    resetApprovalRules(): void;
    get approvalRulesInput(): cdktf.IResolvable | DataGitlabProjectApprovalRulesApprovalRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
