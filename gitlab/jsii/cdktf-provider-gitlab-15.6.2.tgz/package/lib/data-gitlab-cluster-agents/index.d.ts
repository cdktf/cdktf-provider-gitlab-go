/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabClusterAgentsConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID or full path of the project maintained by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/cluster_agents#project DataGitlabClusterAgents#project}
    */
    readonly project: string;
}
export interface DataGitlabClusterAgentsClusterAgents {
}
export declare function dataGitlabClusterAgentsClusterAgentsToTerraform(struct?: DataGitlabClusterAgentsClusterAgents): any;
export declare function dataGitlabClusterAgentsClusterAgentsToHclTerraform(struct?: DataGitlabClusterAgentsClusterAgents): any;
export declare class DataGitlabClusterAgentsClusterAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabClusterAgentsClusterAgents | undefined;
    set internalValue(value: DataGitlabClusterAgentsClusterAgents | undefined);
    get agentId(): number;
    get createdAt(): string;
    get createdByUserId(): number;
    get name(): string;
    get project(): string;
}
export declare class DataGitlabClusterAgentsClusterAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabClusterAgentsClusterAgentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/cluster_agents gitlab_cluster_agents}
*/
export declare class DataGitlabClusterAgents extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_cluster_agents";
    /**
    * Generates CDKTF code for importing a DataGitlabClusterAgents resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabClusterAgents to import
    * @param importFromId The id of the existing DataGitlabClusterAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/cluster_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabClusterAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/cluster_agents gitlab_cluster_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabClusterAgentsConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabClusterAgentsConfig);
    private _clusterAgents;
    get clusterAgents(): DataGitlabClusterAgentsClusterAgentsList;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
