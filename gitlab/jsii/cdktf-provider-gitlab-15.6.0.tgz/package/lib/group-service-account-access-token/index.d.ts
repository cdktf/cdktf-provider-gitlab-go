/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupServiceAccountAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The service account access token expiry date. When left blank, the token follows the standard rule of expiry for personal access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#expires_at GroupServiceAccountAccessToken#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The ID or URL-encoded path of the group containing the service account. Must be a top level group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#group GroupServiceAccountAccessToken#group}
    */
    readonly group: string;
    /**
    * The name of the personal access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#name GroupServiceAccountAccessToken#name}
    */
    readonly name: string;
    /**
    * The configuration for when to rotate a token automatically. Will not rotate a token until `terraform apply` is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#rotation_configuration GroupServiceAccountAccessToken#rotation_configuration}
    */
    readonly rotationConfiguration?: GroupServiceAccountAccessTokenRotationConfiguration;
    /**
    * The scopes of the group service account access token. Valid values are: `api`, `read_user`, `read_api`, `read_repository`, `write_repository`, `read_registry`, `write_registry`, `read_virtual_registry`, `write_virtual_registry`, `sudo`, `admin_mode`, `create_runner`, `manage_runner`, `ai_features`, `k8s_proxy`, `self_rotate`, `read_service_ping`. If `self_rotate` is included, you must also provide either `expires_at` or `rotation_configuration`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#scopes GroupServiceAccountAccessToken#scopes}
    */
    readonly scopes: string[];
    /**
    * The ID of a service account user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#user_id GroupServiceAccountAccessToken#user_id}
    */
    readonly userId: number;
    /**
    * Wether to validate if the expiration date is in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#validate_past_expiration_date GroupServiceAccountAccessToken#validate_past_expiration_date}
    */
    readonly validatePastExpirationDate?: boolean | cdktf.IResolvable;
}
export interface GroupServiceAccountAccessTokenRotationConfiguration {
    /**
    * The duration (in days) the new token should be valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#expiration_days GroupServiceAccountAccessToken#expiration_days}
    */
    readonly expirationDays?: number;
    /**
    * The duration (in days) before the expiration when the token should be rotated. As an example, if set to 7 days, the token will rotate 7 days before the expiration date, but only when `terraform apply` is run in that timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#rotate_before_days GroupServiceAccountAccessToken#rotate_before_days}
    */
    readonly rotateBeforeDays: number;
}
export declare function groupServiceAccountAccessTokenRotationConfigurationToTerraform(struct?: GroupServiceAccountAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare function groupServiceAccountAccessTokenRotationConfigurationToHclTerraform(struct?: GroupServiceAccountAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare class GroupServiceAccountAccessTokenRotationConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupServiceAccountAccessTokenRotationConfiguration | cdktf.IResolvable | undefined;
    set internalValue(value: GroupServiceAccountAccessTokenRotationConfiguration | cdktf.IResolvable | undefined);
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    resetExpirationDays(): void;
    get expirationDaysInput(): number | undefined;
    private _rotateBeforeDays?;
    get rotateBeforeDays(): number;
    set rotateBeforeDays(value: number);
    get rotateBeforeDaysInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token gitlab_group_service_account_access_token}
*/
export declare class GroupServiceAccountAccessToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_service_account_access_token";
    /**
    * Generates CDKTF code for importing a GroupServiceAccountAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupServiceAccountAccessToken to import
    * @param importFromId The id of the existing GroupServiceAccountAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupServiceAccountAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_service_account_access_token gitlab_group_service_account_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupServiceAccountAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: GroupServiceAccountAccessTokenConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get revoked(): cdktf.IResolvable;
    private _rotationConfiguration;
    get rotationConfiguration(): GroupServiceAccountAccessTokenRotationConfigurationOutputReference;
    putRotationConfiguration(value: GroupServiceAccountAccessTokenRotationConfiguration): void;
    resetRotationConfiguration(): void;
    get rotationConfigurationInput(): cdktf.IResolvable | GroupServiceAccountAccessTokenRotationConfiguration | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    get token(): string;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    private _validatePastExpirationDate?;
    get validatePastExpirationDate(): boolean | cdktf.IResolvable;
    set validatePastExpirationDate(value: boolean | cdktf.IResolvable);
    resetValidatePastExpirationDate(): void;
    get validatePastExpirationDateInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
