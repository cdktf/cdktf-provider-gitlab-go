/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabReleaseConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#project_id DataGitlabRelease#project_id}
    */
    readonly projectId: string;
    /**
    * The Git tag the release is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#tag_name DataGitlabRelease#tag_name}
    */
    readonly tagName: string;
    /**
    * assets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#assets DataGitlabRelease#assets}
    */
    readonly assets?: DataGitlabReleaseAssets;
}
export interface DataGitlabReleaseAssetsLinks {
}
export declare function dataGitlabReleaseAssetsLinksToTerraform(struct?: DataGitlabReleaseAssetsLinks | cdktf.IResolvable): any;
export declare function dataGitlabReleaseAssetsLinksToHclTerraform(struct?: DataGitlabReleaseAssetsLinks | cdktf.IResolvable): any;
export declare class DataGitlabReleaseAssetsLinksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabReleaseAssetsLinks | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabReleaseAssetsLinks | cdktf.IResolvable | undefined);
    get id(): number;
    get linkType(): string;
    get name(): string;
    get url(): string;
}
export declare class DataGitlabReleaseAssetsLinksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabReleaseAssetsLinks[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabReleaseAssetsLinksOutputReference;
}
export interface DataGitlabReleaseAssetsSources {
}
export declare function dataGitlabReleaseAssetsSourcesToTerraform(struct?: DataGitlabReleaseAssetsSources | cdktf.IResolvable): any;
export declare function dataGitlabReleaseAssetsSourcesToHclTerraform(struct?: DataGitlabReleaseAssetsSources | cdktf.IResolvable): any;
export declare class DataGitlabReleaseAssetsSourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabReleaseAssetsSources | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabReleaseAssetsSources | cdktf.IResolvable | undefined);
    get format(): string;
    get url(): string;
}
export declare class DataGitlabReleaseAssetsSourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabReleaseAssetsSources[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabReleaseAssetsSourcesOutputReference;
}
export interface DataGitlabReleaseAssets {
    /**
    * links block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#links DataGitlabRelease#links}
    */
    readonly links?: DataGitlabReleaseAssetsLinks[] | cdktf.IResolvable;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#sources DataGitlabRelease#sources}
    */
    readonly sources?: DataGitlabReleaseAssetsSources[] | cdktf.IResolvable;
}
export declare function dataGitlabReleaseAssetsToTerraform(struct?: DataGitlabReleaseAssets | cdktf.IResolvable): any;
export declare function dataGitlabReleaseAssetsToHclTerraform(struct?: DataGitlabReleaseAssets | cdktf.IResolvable): any;
export declare class DataGitlabReleaseAssetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabReleaseAssets | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabReleaseAssets | cdktf.IResolvable | undefined);
    get count(): number;
    private _links;
    get links(): DataGitlabReleaseAssetsLinksList;
    putLinks(value: DataGitlabReleaseAssetsLinks[] | cdktf.IResolvable): void;
    resetLinks(): void;
    get linksInput(): cdktf.IResolvable | DataGitlabReleaseAssetsLinks[] | undefined;
    private _sources;
    get sources(): DataGitlabReleaseAssetsSourcesList;
    putSources(value: DataGitlabReleaseAssetsSources[] | cdktf.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktf.IResolvable | DataGitlabReleaseAssetsSources[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release gitlab_release}
*/
export declare class DataGitlabRelease extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_release";
    /**
    * Generates CDKTF code for importing a DataGitlabRelease resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabRelease to import
    * @param importFromId The id of the existing DataGitlabRelease that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabRelease to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/release gitlab_release} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabReleaseConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabReleaseConfig);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get releasedAt(): string;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    get tagNameInput(): string | undefined;
    private _assets;
    get assets(): DataGitlabReleaseAssetsOutputReference;
    putAssets(value: DataGitlabReleaseAssets): void;
    resetAssets(): void;
    get assetsInput(): cdktf.IResolvable | DataGitlabReleaseAssets | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
