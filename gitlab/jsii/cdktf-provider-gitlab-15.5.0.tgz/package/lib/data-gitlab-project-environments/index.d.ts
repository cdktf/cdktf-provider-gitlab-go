/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectEnvironmentsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return the environment with this name. Mutually exclusive with search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments#name DataGitlabProjectEnvironments#name}
    */
    readonly name?: string;
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments#project DataGitlabProjectEnvironments#project}
    */
    readonly project: string;
    /**
    * Return list of environments matching the search criteria. Mutually exclusive with name. Must be at least 3 characters long.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments#search DataGitlabProjectEnvironments#search}
    */
    readonly search?: string;
    /**
    * List all environments that match the specified state. Valid values are `available`, `stopping`, `stopped`. Returns all environments if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments#states DataGitlabProjectEnvironments#states}
    */
    readonly states?: string;
}
export interface DataGitlabProjectEnvironmentsEnvironments {
}
export declare function dataGitlabProjectEnvironmentsEnvironmentsToTerraform(struct?: DataGitlabProjectEnvironmentsEnvironments): any;
export declare function dataGitlabProjectEnvironmentsEnvironmentsToHclTerraform(struct?: DataGitlabProjectEnvironmentsEnvironments): any;
export declare class DataGitlabProjectEnvironmentsEnvironmentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectEnvironmentsEnvironments | undefined;
    set internalValue(value: DataGitlabProjectEnvironmentsEnvironments | undefined);
    get autoStopAt(): string;
    get autoStopSetting(): string;
    get clusterAgentId(): number;
    get createdAt(): string;
    get description(): string;
    get externalUrl(): string;
    get fluxResourcePath(): string;
    get id(): number;
    get kubernetesNamespace(): string;
    get name(): string;
    get slug(): string;
    get state(): string;
    get tier(): string;
    get updatedAt(): string;
}
export declare class DataGitlabProjectEnvironmentsEnvironmentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectEnvironmentsEnvironmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments gitlab_project_environments}
*/
export declare class DataGitlabProjectEnvironments extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_environments";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectEnvironments resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectEnvironments to import
    * @param importFromId The id of the existing DataGitlabProjectEnvironments that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectEnvironments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_environments gitlab_project_environments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectEnvironmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectEnvironmentsConfig);
    private _environments;
    get environments(): DataGitlabProjectEnvironmentsEnvironmentsList;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _states?;
    get states(): string;
    set states(value: string);
    resetStates(): void;
    get statesInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
