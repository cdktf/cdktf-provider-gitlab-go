/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabRepositoryTreeConfig extends cdktf.TerraformMetaArguments {
    /**
    * The path inside repository. Used to get content of subdirectories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree#path DataGitlabRepositoryTree#path}
    */
    readonly path?: string;
    /**
    * The ID or full path of the project owned by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree#project DataGitlabRepositoryTree#project}
    */
    readonly project: string;
    /**
    * Boolean value used to get a recursive tree (false by default).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree#recursive DataGitlabRepositoryTree#recursive}
    */
    readonly recursive?: boolean | cdktf.IResolvable;
    /**
    * The name of a repository branch or tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree#ref DataGitlabRepositoryTree#ref}
    */
    readonly ref: string;
}
export interface DataGitlabRepositoryTreeTree {
}
export declare function dataGitlabRepositoryTreeTreeToTerraform(struct?: DataGitlabRepositoryTreeTree): any;
export declare function dataGitlabRepositoryTreeTreeToHclTerraform(struct?: DataGitlabRepositoryTreeTree): any;
export declare class DataGitlabRepositoryTreeTreeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabRepositoryTreeTree | undefined;
    set internalValue(value: DataGitlabRepositoryTreeTree | undefined);
    get id(): string;
    get mode(): string;
    get name(): string;
    get nodeId(): string;
    get path(): string;
    get type(): string;
}
export declare class DataGitlabRepositoryTreeTreeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabRepositoryTreeTreeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree gitlab_repository_tree}
*/
export declare class DataGitlabRepositoryTree extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_repository_tree";
    /**
    * Generates CDKTF code for importing a DataGitlabRepositoryTree resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabRepositoryTree to import
    * @param importFromId The id of the existing DataGitlabRepositoryTree that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabRepositoryTree to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/repository_tree gitlab_repository_tree} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabRepositoryTreeConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabRepositoryTreeConfig);
    get id(): string;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _recursive?;
    get recursive(): boolean | cdktf.IResolvable;
    set recursive(value: boolean | cdktf.IResolvable);
    resetRecursive(): void;
    get recursiveInput(): boolean | cdktf.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    get refInput(): string | undefined;
    private _tree;
    get tree(): DataGitlabRepositoryTreeTreeList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
