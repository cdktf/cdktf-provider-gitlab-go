/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Order the groups' list by `id`, `name`, `path`, or `similarity`. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups#order_by DataGitlabGroups#order_by}
    */
    readonly orderBy?: string;
    /**
    * Search groups by name or path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups#search DataGitlabGroups#search}
    */
    readonly search?: string;
    /**
    * Sort groups' list in asc or desc order. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups#sort DataGitlabGroups#sort}
    */
    readonly sort?: string;
    /**
    * Limit to top level groups, excluding all subgroups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups#top_level_only DataGitlabGroups#top_level_only}
    */
    readonly topLevelOnly?: boolean | cdktf.IResolvable;
}
export interface DataGitlabGroupsGroups {
}
export declare function dataGitlabGroupsGroupsToTerraform(struct?: DataGitlabGroupsGroups): any;
export declare function dataGitlabGroupsGroupsToHclTerraform(struct?: DataGitlabGroupsGroups): any;
export declare class DataGitlabGroupsGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupsGroups | undefined;
    set internalValue(value: DataGitlabGroupsGroups | undefined);
    get defaultBranchProtection(): number;
    get description(): string;
    get fullName(): string;
    get fullPath(): string;
    get groupId(): number;
    get lfsEnabled(): cdktf.IResolvable;
    get name(): string;
    get parentId(): number;
    get path(): string;
    get preventForkingOutsideGroup(): cdktf.IResolvable;
    get requestAccessEnabled(): cdktf.IResolvable;
    get runnersToken(): string;
    get sharedRunnersSetting(): string;
    get visibilityLevel(): string;
    get webUrl(): string;
    get wikiAccessLevel(): string;
}
export declare class DataGitlabGroupsGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupsGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups gitlab_groups}
*/
export declare class DataGitlabGroups extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_groups";
    /**
    * Generates CDKTF code for importing a DataGitlabGroups resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroups to import
    * @param importFromId The id of the existing DataGitlabGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/groups gitlab_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabGroupsConfig);
    private _groups;
    get groups(): DataGitlabGroupsGroupsList;
    get id(): string;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _topLevelOnly?;
    get topLevelOnly(): boolean | cdktf.IResolvable;
    set topLevelOnly(value: boolean | cdktf.IResolvable);
    resetTopLevelOnly(): void;
    get topLevelOnlyInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
