/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabBranchConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/branch#name DataGitlabBranch#name}
    */
    readonly name: string;
    /**
    * The full path or id of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/branch#project DataGitlabBranch#project}
    */
    readonly project: string;
}
export interface DataGitlabBranchCommit {
}
export declare function dataGitlabBranchCommitToTerraform(struct?: DataGitlabBranchCommit): any;
export declare function dataGitlabBranchCommitToHclTerraform(struct?: DataGitlabBranchCommit): any;
export declare class DataGitlabBranchCommitOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabBranchCommit | undefined;
    set internalValue(value: DataGitlabBranchCommit | undefined);
    get authorEmail(): string;
    get authorName(): string;
    get authoredDate(): string;
    get committedDate(): string;
    get committerEmail(): string;
    get committerName(): string;
    get id(): string;
    get message(): string;
    get parentIds(): string[];
    get shortId(): string;
    get title(): string;
}
export declare class DataGitlabBranchCommitList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabBranchCommitOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/branch gitlab_branch}
*/
export declare class DataGitlabBranch extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_branch";
    /**
    * Generates CDKTF code for importing a DataGitlabBranch resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabBranch to import
    * @param importFromId The id of the existing DataGitlabBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/branch gitlab_branch} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabBranchConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabBranchConfig);
    get canPush(): cdktf.IResolvable;
    private _commit;
    get commit(): DataGitlabBranchCommitList;
    get default(): cdktf.IResolvable;
    get developerCanMerge(): cdktf.IResolvable;
    get developerCanPush(): cdktf.IResolvable;
    get id(): string;
    get merged(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get protected(): cdktf.IResolvable;
    get webUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
