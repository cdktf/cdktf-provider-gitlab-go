/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MemberRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The base access level for the custom role. Valid values are: `DEVELOPER`, `GUEST`, `MAINTAINER`, `MINIMAL_ACCESS`, `OWNER`, `REPORTER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#base_access_level MemberRole#base_access_level}
    */
    readonly baseAccessLevel: string;
    /**
    * Description for the member role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#description MemberRole#description}
    */
    readonly description?: string;
    /**
    * All permissions enabled for the custom role. Valid values are: `ADMIN_CICD_VARIABLES`, `ADMIN_COMPLIANCE_FRAMEWORK`, `ADMIN_GROUP_MEMBER`, `ADMIN_INTEGRATIONS`, `ADMIN_MERGE_REQUEST`, `ADMIN_PROTECTED_BRANCH`, `ADMIN_PUSH_RULES`, `ADMIN_RUNNERS`, `ADMIN_TERRAFORM_STATE`, `ADMIN_VULNERABILITY`, `ADMIN_WEB_HOOK`, `ARCHIVE_PROJECT`, `MANAGE_DEPLOY_TOKENS`, `MANAGE_GROUP_ACCESS_TOKENS`, `MANAGE_MERGE_REQUEST_SETTINGS`, `MANAGE_PROJECT_ACCESS_TOKENS`, `MANAGE_SECURITY_POLICY_LINK`, `READ_ADMIN_CICD`, `READ_ADMIN_DASHBOARD`, `READ_CODE`, `READ_COMPLIANCE_DASHBOARD`, `READ_CRM_CONTACT`, `READ_DEPENDENCY`, `READ_RUNNERS`, `READ_VULNERABILITY`, `REMOVE_GROUP`, `REMOVE_PROJECT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#enabled_permissions MemberRole#enabled_permissions}
    */
    readonly enabledPermissions: string[];
    /**
    * Full path of the namespace to create the member role in. **Required for SAAS** **Not allowed for self-managed**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#group_path MemberRole#group_path}
    */
    readonly groupPath?: string;
    /**
    * Name for the member role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#name MemberRole#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role gitlab_member_role}
*/
export declare class MemberRole extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_member_role";
    /**
    * Generates CDKTF code for importing a MemberRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MemberRole to import
    * @param importFromId The id of the existing MemberRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MemberRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/member_role gitlab_member_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MemberRoleConfig
    */
    constructor(scope: Construct, id: string, config: MemberRoleConfig);
    private _baseAccessLevel?;
    get baseAccessLevel(): string;
    set baseAccessLevel(value: string);
    get baseAccessLevelInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get editPath(): string;
    private _enabledPermissions?;
    get enabledPermissions(): string[];
    set enabledPermissions(value: string[]);
    get enabledPermissionsInput(): string[] | undefined;
    private _groupPath?;
    get groupPath(): string;
    set groupPath(value: string);
    resetGroupPath(): void;
    get groupPathInput(): string | undefined;
    get id(): string;
    get iid(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
