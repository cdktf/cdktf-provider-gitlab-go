/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabUsersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Filter users that are active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#active DataGitlabUsers#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * Filter users that are blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#blocked DataGitlabUsers#blocked}
    */
    readonly blocked?: boolean | cdktf.IResolvable;
    /**
    * Search for users created after a specific date. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#created_after DataGitlabUsers#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Search for users created before a specific date. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#created_before DataGitlabUsers#created_before}
    */
    readonly createdBefore?: string;
    /**
    * Filters only non external users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#exclude_external DataGitlabUsers#exclude_external}
    */
    readonly excludeExternal?: boolean | cdktf.IResolvable;
    /**
    * Filters only non internal users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#exclude_internal DataGitlabUsers#exclude_internal}
    */
    readonly excludeInternal?: boolean | cdktf.IResolvable;
    /**
    * Lookup users by external provider. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#extern_provider DataGitlabUsers#extern_provider}
    */
    readonly externProvider?: string;
    /**
    * Lookup users by external UID. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#extern_uid DataGitlabUsers#extern_uid}
    */
    readonly externUid?: string;
    /**
    * Filters only external users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#external DataGitlabUsers#external}
    */
    readonly external?: boolean | cdktf.IResolvable;
    /**
    * Filters only regular users that are not bot or internal users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#humans DataGitlabUsers#humans}
    */
    readonly humans?: boolean | cdktf.IResolvable;
    /**
    * Order the users' list by `id`, `name`, `username`, `created_at` or `updated_at`. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#order_by DataGitlabUsers#order_by}
    */
    readonly orderBy?: string;
    /**
    * Search users by username, name or email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#search DataGitlabUsers#search}
    */
    readonly search?: string;
    /**
    * Sort users' list in asc or desc order. (Requires administrator privileges)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#sort DataGitlabUsers#sort}
    */
    readonly sort?: string;
    /**
    * Get a single user with a specific username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#username DataGitlabUsers#username}
    */
    readonly username?: string;
    /**
    * Filters user without project bots.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#without_project_bots DataGitlabUsers#without_project_bots}
    */
    readonly withoutProjectBots?: boolean | cdktf.IResolvable;
}
export interface DataGitlabUsersUsers {
}
export declare function dataGitlabUsersUsersToTerraform(struct?: DataGitlabUsersUsers): any;
export declare function dataGitlabUsersUsersToHclTerraform(struct?: DataGitlabUsersUsers): any;
export declare class DataGitlabUsersUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabUsersUsers | undefined;
    set internalValue(value: DataGitlabUsersUsers | undefined);
    get avatarUrl(): string;
    get bio(): string;
    get canCreateGroup(): cdktf.IResolvable;
    get canCreateProject(): cdktf.IResolvable;
    get colorSchemeId(): number;
    get createdAt(): string;
    get currentSignInAt(): string;
    get email(): string;
    get externUid(): string;
    get external(): cdktf.IResolvable;
    get id(): number;
    get isAdmin(): cdktf.IResolvable;
    get isBot(): cdktf.IResolvable;
    get lastSignInAt(): string;
    get linkedin(): string;
    get location(): string;
    get name(): string;
    get namespaceId(): number;
    get organization(): string;
    get projectsLimit(): number;
    get provider(): string;
    get skype(): string;
    get state(): string;
    get themeId(): number;
    get twitter(): string;
    get twoFactorEnabled(): cdktf.IResolvable;
    get username(): string;
    get websiteUrl(): string;
}
export declare class DataGitlabUsersUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabUsersUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users gitlab_users}
*/
export declare class DataGitlabUsers extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_users";
    /**
    * Generates CDKTF code for importing a DataGitlabUsers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabUsers to import
    * @param importFromId The id of the existing DataGitlabUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/users gitlab_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabUsersConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _blocked?;
    get blocked(): boolean | cdktf.IResolvable;
    set blocked(value: boolean | cdktf.IResolvable);
    resetBlocked(): void;
    get blockedInput(): boolean | cdktf.IResolvable | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _excludeExternal?;
    get excludeExternal(): boolean | cdktf.IResolvable;
    set excludeExternal(value: boolean | cdktf.IResolvable);
    resetExcludeExternal(): void;
    get excludeExternalInput(): boolean | cdktf.IResolvable | undefined;
    private _excludeInternal?;
    get excludeInternal(): boolean | cdktf.IResolvable;
    set excludeInternal(value: boolean | cdktf.IResolvable);
    resetExcludeInternal(): void;
    get excludeInternalInput(): boolean | cdktf.IResolvable | undefined;
    private _externProvider?;
    get externProvider(): string;
    set externProvider(value: string);
    resetExternProvider(): void;
    get externProviderInput(): string | undefined;
    private _externUid?;
    get externUid(): string;
    set externUid(value: string);
    resetExternUid(): void;
    get externUidInput(): string | undefined;
    private _external?;
    get external(): boolean | cdktf.IResolvable;
    set external(value: boolean | cdktf.IResolvable);
    resetExternal(): void;
    get externalInput(): boolean | cdktf.IResolvable | undefined;
    private _humans?;
    get humans(): boolean | cdktf.IResolvable;
    set humans(value: boolean | cdktf.IResolvable);
    resetHumans(): void;
    get humansInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _users;
    get users(): DataGitlabUsersUsersList;
    private _withoutProjectBots?;
    get withoutProjectBots(): boolean | cdktf.IResolvable;
    set withoutProjectBots(value: boolean | cdktf.IResolvable);
    resetWithoutProjectBots(): void;
    get withoutProjectBotsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
