/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabReleaseLinksConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/index/#namespaced-path-encoding).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/release_links#project DataGitlabReleaseLinks#project}
    */
    readonly project: string;
    /**
    * The tag associated with the Release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/release_links#tag_name DataGitlabReleaseLinks#tag_name}
    */
    readonly tagName: string;
}
export interface DataGitlabReleaseLinksReleaseLinks {
}
export declare function dataGitlabReleaseLinksReleaseLinksToTerraform(struct?: DataGitlabReleaseLinksReleaseLinks): any;
export declare function dataGitlabReleaseLinksReleaseLinksToHclTerraform(struct?: DataGitlabReleaseLinksReleaseLinks): any;
export declare class DataGitlabReleaseLinksReleaseLinksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabReleaseLinksReleaseLinks | undefined;
    set internalValue(value: DataGitlabReleaseLinksReleaseLinks | undefined);
    get directAssetUrl(): string;
    get external(): cdktf.IResolvable;
    get filepath(): string;
    get linkId(): number;
    get linkType(): string;
    get name(): string;
    get project(): string;
    get tagName(): string;
    get url(): string;
}
export declare class DataGitlabReleaseLinksReleaseLinksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabReleaseLinksReleaseLinksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/release_links gitlab_release_links}
*/
export declare class DataGitlabReleaseLinks extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_release_links";
    /**
    * Generates CDKTF code for importing a DataGitlabReleaseLinks resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabReleaseLinks to import
    * @param importFromId The id of the existing DataGitlabReleaseLinks that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/release_links#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabReleaseLinks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/release_links gitlab_release_links} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabReleaseLinksConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabReleaseLinksConfig);
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseLinks;
    get releaseLinks(): DataGitlabReleaseLinksReleaseLinksList;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    get tagNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
