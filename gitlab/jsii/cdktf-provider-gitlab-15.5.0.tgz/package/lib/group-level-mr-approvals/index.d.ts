/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupLevelMrApprovalsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Allow or prevent authors from self approving merge requests; `true` means authors can self approve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#allow_author_approval GroupLevelMrApprovals#allow_author_approval}
    */
    readonly allowAuthorApproval?: boolean | cdktf.IResolvable;
    /**
    * Allow or prevent committers from self approving merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#allow_committer_approval GroupLevelMrApprovals#allow_committer_approval}
    */
    readonly allowCommitterApproval?: boolean | cdktf.IResolvable;
    /**
    * Allow or prevent overriding approvers per merge request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#allow_overrides_to_approver_list_per_merge_request GroupLevelMrApprovals#allow_overrides_to_approver_list_per_merge_request}
    */
    readonly allowOverridesToApproverListPerMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * The ID or URL-encoded path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#group GroupLevelMrApprovals#group}
    */
    readonly group: string;
    /**
    * Set to true if the group merge request approval settings should not be reset to their pre-terraform defaults on destroy. You will need to apply the resource with the new setting before destroying the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#keep_settings_on_destroy GroupLevelMrApprovals#keep_settings_on_destroy}
    */
    readonly keepSettingsOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * Require approver to authenticate before adding the approval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#require_reauthentication_to_approve GroupLevelMrApprovals#require_reauthentication_to_approve}
    */
    readonly requireReauthenticationToApprove?: boolean | cdktf.IResolvable;
    /**
    * Retain approval count on a new push.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#retain_approvals_on_push GroupLevelMrApprovals#retain_approvals_on_push}
    */
    readonly retainApprovalsOnPush?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals gitlab_group_level_mr_approvals}
*/
export declare class GroupLevelMrApprovals extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_level_mr_approvals";
    /**
    * Generates CDKTF code for importing a GroupLevelMrApprovals resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupLevelMrApprovals to import
    * @param importFromId The id of the existing GroupLevelMrApprovals that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupLevelMrApprovals to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_level_mr_approvals gitlab_group_level_mr_approvals} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupLevelMrApprovalsConfig
    */
    constructor(scope: Construct, id: string, config: GroupLevelMrApprovalsConfig);
    private _allowAuthorApproval?;
    get allowAuthorApproval(): boolean | cdktf.IResolvable;
    set allowAuthorApproval(value: boolean | cdktf.IResolvable);
    resetAllowAuthorApproval(): void;
    get allowAuthorApprovalInput(): boolean | cdktf.IResolvable | undefined;
    private _allowCommitterApproval?;
    get allowCommitterApproval(): boolean | cdktf.IResolvable;
    set allowCommitterApproval(value: boolean | cdktf.IResolvable);
    resetAllowCommitterApproval(): void;
    get allowCommitterApprovalInput(): boolean | cdktf.IResolvable | undefined;
    private _allowOverridesToApproverListPerMergeRequest?;
    get allowOverridesToApproverListPerMergeRequest(): boolean | cdktf.IResolvable;
    set allowOverridesToApproverListPerMergeRequest(value: boolean | cdktf.IResolvable);
    resetAllowOverridesToApproverListPerMergeRequest(): void;
    get allowOverridesToApproverListPerMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _keepSettingsOnDestroy?;
    get keepSettingsOnDestroy(): boolean | cdktf.IResolvable;
    set keepSettingsOnDestroy(value: boolean | cdktf.IResolvable);
    resetKeepSettingsOnDestroy(): void;
    get keepSettingsOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _requireReauthenticationToApprove?;
    get requireReauthenticationToApprove(): boolean | cdktf.IResolvable;
    set requireReauthenticationToApprove(value: boolean | cdktf.IResolvable);
    resetRequireReauthenticationToApprove(): void;
    get requireReauthenticationToApproveInput(): boolean | cdktf.IResolvable | undefined;
    private _retainApprovalsOnPush?;
    get retainApprovalsOnPush(): boolean | cdktf.IResolvable;
    set retainApprovalsOnPush(value: boolean | cdktf.IResolvable);
    resetRetainApprovalsOnPush(): void;
    get retainApprovalsOnPushInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
