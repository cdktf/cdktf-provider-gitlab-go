/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectContainerRepositoryProtectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Minimum GitLab access level required to delete container images in the container registry. For example maintainer, owner, admin. Must be provided when `minimum_access_level_for_push` is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection#minimum_access_level_for_delete ProjectContainerRepositoryProtection#minimum_access_level_for_delete}
    */
    readonly minimumAccessLevelForDelete?: string;
    /**
    * Minimum GitLab access level required to push container images to the container registry. For example maintainer, owner or admin. Must be provided when `minimum_access_level_for_delete` is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection#minimum_access_level_for_push ProjectContainerRepositoryProtection#minimum_access_level_for_push}
    */
    readonly minimumAccessLevelForPush?: string;
    /**
    * ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection#project ProjectContainerRepositoryProtection#project}
    */
    readonly project: string;
    /**
    * Container repository path pattern protected by the protection rule. Wildcard character * allowed. Repository path pattern should start with the project's full path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection#repository_path_pattern ProjectContainerRepositoryProtection#repository_path_pattern}
    */
    readonly repositoryPathPattern: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection gitlab_project_container_repository_protection}
*/
export declare class ProjectContainerRepositoryProtection extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_container_repository_protection";
    /**
    * Generates CDKTF code for importing a ProjectContainerRepositoryProtection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectContainerRepositoryProtection to import
    * @param importFromId The id of the existing ProjectContainerRepositoryProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectContainerRepositoryProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_container_repository_protection gitlab_project_container_repository_protection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectContainerRepositoryProtectionConfig
    */
    constructor(scope: Construct, id: string, config: ProjectContainerRepositoryProtectionConfig);
    get id(): string;
    private _minimumAccessLevelForDelete?;
    get minimumAccessLevelForDelete(): string;
    set minimumAccessLevelForDelete(value: string);
    resetMinimumAccessLevelForDelete(): void;
    get minimumAccessLevelForDeleteInput(): string | undefined;
    private _minimumAccessLevelForPush?;
    get minimumAccessLevelForPush(): string;
    set minimumAccessLevelForPush(value: string);
    resetMinimumAccessLevelForPush(): void;
    get minimumAccessLevelForPushInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get protectionRuleId(): number;
    private _repositoryPathPattern?;
    get repositoryPathPattern(): string;
    set repositoryPathPattern(value: string);
    get repositoryPathPatternInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
