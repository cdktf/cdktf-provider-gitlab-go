/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectJobTokenScopesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Enable the given inbound allowlist. If false, will allow any project or group regardless of the values in `target_project_ids` or `target_group_ids`. Deleting the associated `gitlab_project_job_token_scopes` resource will reset `Enabled` on the group to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#enabled ProjectJobTokenScopes#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#project ProjectJobTokenScopes#project}
    */
    readonly project?: string;
    /**
    * The ID of the project. Use `project` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#project_id ProjectJobTokenScopes#project_id}
    */
    readonly projectId?: number;
    /**
    * A set of group IDs that are in the CI/CD job token inbound allowlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#target_group_ids ProjectJobTokenScopes#target_group_ids}
    */
    readonly targetGroupIds?: number[];
    /**
    * A set of project IDs that are in the CI/CD job token inbound allowlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#target_project_ids ProjectJobTokenScopes#target_project_ids}
    */
    readonly targetProjectIds?: number[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes gitlab_project_job_token_scopes}
*/
export declare class ProjectJobTokenScopes extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_job_token_scopes";
    /**
    * Generates CDKTF code for importing a ProjectJobTokenScopes resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectJobTokenScopes to import
    * @param importFromId The id of the existing ProjectJobTokenScopes that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectJobTokenScopes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_job_token_scopes gitlab_project_job_token_scopes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectJobTokenScopesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ProjectJobTokenScopesConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _projectId?;
    get projectId(): number;
    set projectId(value: number);
    resetProjectId(): void;
    get projectIdInput(): number | undefined;
    private _targetGroupIds?;
    get targetGroupIds(): number[];
    set targetGroupIds(value: number[]);
    resetTargetGroupIds(): void;
    get targetGroupIdsInput(): number[] | undefined;
    private _targetProjectIds?;
    get targetProjectIds(): number[];
    set targetProjectIds(value: number[]);
    resetTargetProjectIds(): void;
    get targetProjectIdsInput(): number[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
