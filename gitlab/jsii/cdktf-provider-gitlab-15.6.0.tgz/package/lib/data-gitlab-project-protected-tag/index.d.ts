/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectProtectedTagConfig extends cdktf.TerraformMetaArguments {
    /**
    * The integer or path with namespace that uniquely identifies the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag#project DataGitlabProjectProtectedTag#project}
    */
    readonly project: string;
    /**
    * The name of the protected tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag#tag DataGitlabProjectProtectedTag#tag}
    */
    readonly tag: string;
}
export interface DataGitlabProjectProtectedTagCreateAccessLevels {
    /**
    * The ID of a GitLab group allowed to perform the relevant action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag#group_id DataGitlabProjectProtectedTag#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag#user_id DataGitlabProjectProtectedTag#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedTagCreateAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedTagCreateAccessLevels): any;
export declare function dataGitlabProjectProtectedTagCreateAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedTagCreateAccessLevels): any;
export declare class DataGitlabProjectProtectedTagCreateAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedTagCreateAccessLevels | undefined;
    set internalValue(value: DataGitlabProjectProtectedTagCreateAccessLevels | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get id(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedTagCreateAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedTagCreateAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedTagCreateAccessLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag gitlab_project_protected_tag}
*/
export declare class DataGitlabProjectProtectedTag extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_protected_tag";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectProtectedTag resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectProtectedTag to import
    * @param importFromId The id of the existing DataGitlabProjectProtectedTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectProtectedTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_tag gitlab_project_protected_tag} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectProtectedTagConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectProtectedTagConfig);
    private _createAccessLevels;
    get createAccessLevels(): DataGitlabProjectProtectedTagCreateAccessLevelsList;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
