/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabRunnersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Filters for runners with the given paused value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners#paused DataGitlabRunners#paused}
    */
    readonly paused?: boolean | cdktf.IResolvable;
    /**
    * Filters for runners with the given status. Valid Values are `online`, `offline`, `stale`, and `never_contacted`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners#status DataGitlabRunners#status}
    */
    readonly status?: string;
    /**
    * Filters for runners with all of the given tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners#tag_list DataGitlabRunners#tag_list}
    */
    readonly tagList?: string[];
    /**
    * The type of runner to return. Valid values are `instance_type`, `group_type` and `project_type`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners#type DataGitlabRunners#type}
    */
    readonly type?: string;
}
export interface DataGitlabRunnersRunners {
}
export declare function dataGitlabRunnersRunnersToTerraform(struct?: DataGitlabRunnersRunners): any;
export declare function dataGitlabRunnersRunnersToHclTerraform(struct?: DataGitlabRunnersRunners): any;
export declare class DataGitlabRunnersRunnersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabRunnersRunners | undefined;
    set internalValue(value: DataGitlabRunnersRunners | undefined);
    get description(): string;
    get id(): number;
    get isShared(): cdktf.IResolvable;
    get online(): cdktf.IResolvable;
    get paused(): cdktf.IResolvable;
    get runnerType(): string;
    get status(): string;
}
export declare class DataGitlabRunnersRunnersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabRunnersRunnersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners gitlab_runners}
*/
export declare class DataGitlabRunners extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_runners";
    /**
    * Generates CDKTF code for importing a DataGitlabRunners resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabRunners to import
    * @param importFromId The id of the existing DataGitlabRunners that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabRunners to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/runners gitlab_runners} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabRunnersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabRunnersConfig);
    get id(): string;
    private _paused?;
    get paused(): boolean | cdktf.IResolvable;
    set paused(value: boolean | cdktf.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktf.IResolvable | undefined;
    private _runners;
    get runners(): DataGitlabRunnersRunnersList;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tagList?;
    get tagList(): string[];
    set tagList(value: string[]);
    resetTagList(): void;
    get tagListInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
