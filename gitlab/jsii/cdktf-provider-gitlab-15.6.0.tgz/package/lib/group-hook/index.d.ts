/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupHookConfig extends cdktf.TerraformMetaArguments {
    /**
    * Filter push events by branch. Valid values are: `wildcard`, `regex`, `all_branches`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#branch_filter_strategy GroupHook#branch_filter_strategy}
    */
    readonly branchFilterStrategy?: string;
    /**
    * Invoke the hook for confidential issues events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#confidential_issues_events GroupHook#confidential_issues_events}
    */
    readonly confidentialIssuesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for confidential note events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#confidential_note_events GroupHook#confidential_note_events}
    */
    readonly confidentialNoteEvents?: boolean | cdktf.IResolvable;
    /**
    * Custom headers for the project webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#custom_headers GroupHook#custom_headers}
    */
    readonly customHeaders?: GroupHookCustomHeaders[] | cdktf.IResolvable;
    /**
    * Custom webhook template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#custom_webhook_template GroupHook#custom_webhook_template}
    */
    readonly customWebhookTemplate?: string;
    /**
    * Invoke the hook for deployment events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#deployment_events GroupHook#deployment_events}
    */
    readonly deploymentEvents?: boolean | cdktf.IResolvable;
    /**
    * Description of the group webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#description GroupHook#description}
    */
    readonly description?: string;
    /**
    * Invoke the hook for emoji events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#emoji_events GroupHook#emoji_events}
    */
    readonly emojiEvents?: boolean | cdktf.IResolvable;
    /**
    * Enable SSL verification when invoking the hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#enable_ssl_verification GroupHook#enable_ssl_verification}
    */
    readonly enableSslVerification?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for feature flag events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#feature_flag_events GroupHook#feature_flag_events}
    */
    readonly featureFlagEvents?: boolean | cdktf.IResolvable;
    /**
    * The full path or id of the group to add the hook to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#group GroupHook#group}
    */
    readonly group: string;
    /**
    * Invoke the hook for issues events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#issues_events GroupHook#issues_events}
    */
    readonly issuesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for job events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#job_events GroupHook#job_events}
    */
    readonly jobEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for merge requests events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#merge_requests_events GroupHook#merge_requests_events}
    */
    readonly mergeRequestsEvents?: boolean | cdktf.IResolvable;
    /**
    * Name of the group webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#name GroupHook#name}
    */
    readonly name?: string;
    /**
    * Invoke the hook for note events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#note_events GroupHook#note_events}
    */
    readonly noteEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for pipeline events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#pipeline_events GroupHook#pipeline_events}
    */
    readonly pipelineEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#push_events GroupHook#push_events}
    */
    readonly pushEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for push events on matching branches only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#push_events_branch_filter GroupHook#push_events_branch_filter}
    */
    readonly pushEventsBranchFilter?: string;
    /**
    * Invoke the hook for release events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#releases_events GroupHook#releases_events}
    */
    readonly releasesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for subgroup events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#subgroup_events GroupHook#subgroup_events}
    */
    readonly subgroupEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for tag push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#tag_push_events GroupHook#tag_push_events}
    */
    readonly tagPushEvents?: boolean | cdktf.IResolvable;
    /**
    * A token to present when invoking the hook. The token is not available for imported resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#token GroupHook#token}
    */
    readonly token?: string;
    /**
    * The url of the hook to invoke. Forces re-creation to preserve `token`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#url GroupHook#url}
    */
    readonly url: string;
    /**
    * Invoke the hook for wiki page events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#wiki_page_events GroupHook#wiki_page_events}
    */
    readonly wikiPageEvents?: boolean | cdktf.IResolvable;
}
export interface GroupHookCustomHeaders {
    /**
    * Key of the custom header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#key GroupHook#key}
    */
    readonly key: string;
    /**
    * Value of the custom header. This value cannot be imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#value GroupHook#value}
    */
    readonly value: string;
}
export declare function groupHookCustomHeadersToTerraform(struct?: GroupHookCustomHeaders | cdktf.IResolvable): any;
export declare function groupHookCustomHeadersToHclTerraform(struct?: GroupHookCustomHeaders | cdktf.IResolvable): any;
export declare class GroupHookCustomHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupHookCustomHeaders | cdktf.IResolvable | undefined;
    set internalValue(value: GroupHookCustomHeaders | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class GroupHookCustomHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GroupHookCustomHeaders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupHookCustomHeadersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook gitlab_group_hook}
*/
export declare class GroupHook extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_hook";
    /**
    * Generates CDKTF code for importing a GroupHook resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupHook to import
    * @param importFromId The id of the existing GroupHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_hook gitlab_group_hook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupHookConfig
    */
    constructor(scope: Construct, id: string, config: GroupHookConfig);
    private _branchFilterStrategy?;
    get branchFilterStrategy(): string;
    set branchFilterStrategy(value: string);
    resetBranchFilterStrategy(): void;
    get branchFilterStrategyInput(): string | undefined;
    private _confidentialIssuesEvents?;
    get confidentialIssuesEvents(): boolean | cdktf.IResolvable;
    set confidentialIssuesEvents(value: boolean | cdktf.IResolvable);
    resetConfidentialIssuesEvents(): void;
    get confidentialIssuesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _confidentialNoteEvents?;
    get confidentialNoteEvents(): boolean | cdktf.IResolvable;
    set confidentialNoteEvents(value: boolean | cdktf.IResolvable);
    resetConfidentialNoteEvents(): void;
    get confidentialNoteEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _customHeaders;
    get customHeaders(): GroupHookCustomHeadersList;
    putCustomHeaders(value: GroupHookCustomHeaders[] | cdktf.IResolvable): void;
    resetCustomHeaders(): void;
    get customHeadersInput(): cdktf.IResolvable | GroupHookCustomHeaders[] | undefined;
    private _customWebhookTemplate?;
    get customWebhookTemplate(): string;
    set customWebhookTemplate(value: string);
    resetCustomWebhookTemplate(): void;
    get customWebhookTemplateInput(): string | undefined;
    private _deploymentEvents?;
    get deploymentEvents(): boolean | cdktf.IResolvable;
    set deploymentEvents(value: boolean | cdktf.IResolvable);
    resetDeploymentEvents(): void;
    get deploymentEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _emojiEvents?;
    get emojiEvents(): boolean | cdktf.IResolvable;
    set emojiEvents(value: boolean | cdktf.IResolvable);
    resetEmojiEvents(): void;
    get emojiEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _enableSslVerification?;
    get enableSslVerification(): boolean | cdktf.IResolvable;
    set enableSslVerification(value: boolean | cdktf.IResolvable);
    resetEnableSslVerification(): void;
    get enableSslVerificationInput(): boolean | cdktf.IResolvable | undefined;
    private _featureFlagEvents?;
    get featureFlagEvents(): boolean | cdktf.IResolvable;
    set featureFlagEvents(value: boolean | cdktf.IResolvable);
    resetFeatureFlagEvents(): void;
    get featureFlagEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get groupId(): number;
    get hookId(): number;
    get id(): string;
    private _issuesEvents?;
    get issuesEvents(): boolean | cdktf.IResolvable;
    set issuesEvents(value: boolean | cdktf.IResolvable);
    resetIssuesEvents(): void;
    get issuesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _jobEvents?;
    get jobEvents(): boolean | cdktf.IResolvable;
    set jobEvents(value: boolean | cdktf.IResolvable);
    resetJobEvents(): void;
    get jobEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestsEvents?;
    get mergeRequestsEvents(): boolean | cdktf.IResolvable;
    set mergeRequestsEvents(value: boolean | cdktf.IResolvable);
    resetMergeRequestsEvents(): void;
    get mergeRequestsEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _noteEvents?;
    get noteEvents(): boolean | cdktf.IResolvable;
    set noteEvents(value: boolean | cdktf.IResolvable);
    resetNoteEvents(): void;
    get noteEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _pipelineEvents?;
    get pipelineEvents(): boolean | cdktf.IResolvable;
    set pipelineEvents(value: boolean | cdktf.IResolvable);
    resetPipelineEvents(): void;
    get pipelineEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _pushEvents?;
    get pushEvents(): boolean | cdktf.IResolvable;
    set pushEvents(value: boolean | cdktf.IResolvable);
    resetPushEvents(): void;
    get pushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _pushEventsBranchFilter?;
    get pushEventsBranchFilter(): string;
    set pushEventsBranchFilter(value: string);
    resetPushEventsBranchFilter(): void;
    get pushEventsBranchFilterInput(): string | undefined;
    private _releasesEvents?;
    get releasesEvents(): boolean | cdktf.IResolvable;
    set releasesEvents(value: boolean | cdktf.IResolvable);
    resetReleasesEvents(): void;
    get releasesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _subgroupEvents?;
    get subgroupEvents(): boolean | cdktf.IResolvable;
    set subgroupEvents(value: boolean | cdktf.IResolvable);
    resetSubgroupEvents(): void;
    get subgroupEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _tagPushEvents?;
    get tagPushEvents(): boolean | cdktf.IResolvable;
    set tagPushEvents(value: boolean | cdktf.IResolvable);
    resetTagPushEvents(): void;
    get tagPushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _wikiPageEvents?;
    get wikiPageEvents(): boolean | cdktf.IResolvable;
    set wikiPageEvents(value: boolean | cdktf.IResolvable);
    resetWikiPageEvents(): void;
    get wikiPageEventsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
