/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface InstanceClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The base domain of the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#domain InstanceCluster#domain}
    */
    readonly domain?: string;
    /**
    * Determines if cluster is active or not. Defaults to `true`. This attribute cannot be read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#enabled InstanceCluster#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The associated environment to the cluster. Defaults to `*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#environment_scope InstanceCluster#environment_scope}
    */
    readonly environmentScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#id InstanceCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL to access the Kubernetes API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#kubernetes_api_url InstanceCluster#kubernetes_api_url}
    */
    readonly kubernetesApiUrl: string;
    /**
    * The cluster authorization type. Valid values are `rbac`, `abac`, `unknown_authorization`. Defaults to `rbac`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#kubernetes_authorization_type InstanceCluster#kubernetes_authorization_type}
    */
    readonly kubernetesAuthorizationType?: string;
    /**
    * TLS certificate (needed if API is using a self-signed TLS certificate).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#kubernetes_ca_cert InstanceCluster#kubernetes_ca_cert}
    */
    readonly kubernetesCaCert?: string;
    /**
    * The unique namespace related to the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#kubernetes_namespace InstanceCluster#kubernetes_namespace}
    */
    readonly kubernetesNamespace?: string;
    /**
    * The token to authenticate against Kubernetes. This attribute cannot be read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#kubernetes_token InstanceCluster#kubernetes_token}
    */
    readonly kubernetesToken: string;
    /**
    * Determines if cluster is managed by gitlab or not. Defaults to `true`. This attribute cannot be read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#managed InstanceCluster#managed}
    */
    readonly managed?: boolean | cdktf.IResolvable;
    /**
    * The ID of the management project for the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#management_project_id InstanceCluster#management_project_id}
    */
    readonly managementProjectId?: string;
    /**
    * The name of cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#name InstanceCluster#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster gitlab_instance_cluster}
*/
export declare class InstanceCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_instance_cluster";
    /**
    * Generates CDKTF code for importing a InstanceCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the InstanceCluster to import
    * @param importFromId The id of the existing InstanceCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the InstanceCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/instance_cluster gitlab_instance_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InstanceClusterConfig
    */
    constructor(scope: Construct, id: string, config: InstanceClusterConfig);
    get clusterType(): string;
    get createdAt(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _environmentScope?;
    get environmentScope(): string;
    set environmentScope(value: string);
    resetEnvironmentScope(): void;
    get environmentScopeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kubernetesApiUrl?;
    get kubernetesApiUrl(): string;
    set kubernetesApiUrl(value: string);
    get kubernetesApiUrlInput(): string | undefined;
    private _kubernetesAuthorizationType?;
    get kubernetesAuthorizationType(): string;
    set kubernetesAuthorizationType(value: string);
    resetKubernetesAuthorizationType(): void;
    get kubernetesAuthorizationTypeInput(): string | undefined;
    private _kubernetesCaCert?;
    get kubernetesCaCert(): string;
    set kubernetesCaCert(value: string);
    resetKubernetesCaCert(): void;
    get kubernetesCaCertInput(): string | undefined;
    private _kubernetesNamespace?;
    get kubernetesNamespace(): string;
    set kubernetesNamespace(value: string);
    resetKubernetesNamespace(): void;
    get kubernetesNamespaceInput(): string | undefined;
    private _kubernetesToken?;
    get kubernetesToken(): string;
    set kubernetesToken(value: string);
    get kubernetesTokenInput(): string | undefined;
    private _managed?;
    get managed(): boolean | cdktf.IResolvable;
    set managed(value: boolean | cdktf.IResolvable);
    resetManaged(): void;
    get managedInput(): boolean | cdktf.IResolvable | undefined;
    private _managementProjectId?;
    get managementProjectId(): string;
    set managementProjectId(value: string);
    resetManagementProjectId(): void;
    get managementProjectIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platformType(): string;
    get providerType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
