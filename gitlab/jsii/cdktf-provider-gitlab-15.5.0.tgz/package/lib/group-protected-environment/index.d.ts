/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupProtectedEnvironmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Array of approval rules to deploy, with each described by a hash. Elements in the `approval_rules` should be one of `user_id`, `group_id` or `access_level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#approval_rules GroupProtectedEnvironment#approval_rules}
    */
    readonly approvalRules?: GroupProtectedEnvironmentApprovalRules[] | cdktf.IResolvable;
    /**
    * Array of access levels allowed to deploy, with each described by a hash. Elements in the `deploy_access_levels` should be one of `user_id`, `group_id` or `access_level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#deploy_access_levels GroupProtectedEnvironment#deploy_access_levels}
    */
    readonly deployAccessLevels: GroupProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable;
    /**
    * The deployment tier of the environment.  Valid values are `production`, `staging`, `testing`, `development`, `other`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#environment GroupProtectedEnvironment#environment}
    */
    readonly environment: string;
    /**
    * The ID or full path of the group which the protected environment is created against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#group GroupProtectedEnvironment#group}
    */
    readonly group: string;
}
export interface GroupProtectedEnvironmentApprovalRules {
    /**
    * Levels of access allowed to approve a deployment to this protected environment. Mutually exclusive with `user_id` and `group_id`. Valid values are `developer`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#access_level GroupProtectedEnvironment#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of the group allowed to approve a deployment to this protected environment. TThe group must be a sub-group under the given group. Mutually exclusive with `access_level` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#group_id GroupProtectedEnvironment#group_id}
    */
    readonly groupId?: number;
    /**
    * Group inheritance allows access rules to take inherited group membership into account. Valid values are `0`, `1`. `0` => Direct group membership only, `1` => All inherited groups. Default: `0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#group_inheritance_type GroupProtectedEnvironment#group_inheritance_type}
    */
    readonly groupInheritanceType?: number;
    /**
    * The number of approval required to allow deployment to this protected environment. This is mutually exclusive with user_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#required_approvals GroupProtectedEnvironment#required_approvals}
    */
    readonly requiredApprovals?: number;
    /**
    * The ID of the user allowed to approve a deployment to this protected environment. The user must be a member of the group with Maintainer role or higher. Mutually exclusive with `access_level` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#user_id GroupProtectedEnvironment#user_id}
    */
    readonly userId?: number;
}
export declare function groupProtectedEnvironmentApprovalRulesToTerraform(struct?: GroupProtectedEnvironmentApprovalRules | cdktf.IResolvable): any;
export declare function groupProtectedEnvironmentApprovalRulesToHclTerraform(struct?: GroupProtectedEnvironmentApprovalRules | cdktf.IResolvable): any;
export declare class GroupProtectedEnvironmentApprovalRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupProtectedEnvironmentApprovalRules | cdktf.IResolvable | undefined;
    set internalValue(value: GroupProtectedEnvironmentApprovalRules | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _groupInheritanceType?;
    get groupInheritanceType(): number;
    set groupInheritanceType(value: number);
    resetGroupInheritanceType(): void;
    get groupInheritanceTypeInput(): number | undefined;
    get id(): number;
    private _requiredApprovals?;
    get requiredApprovals(): number;
    set requiredApprovals(value: number);
    resetRequiredApprovals(): void;
    get requiredApprovalsInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class GroupProtectedEnvironmentApprovalRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GroupProtectedEnvironmentApprovalRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupProtectedEnvironmentApprovalRulesOutputReference;
}
export interface GroupProtectedEnvironmentDeployAccessLevels {
    /**
    * Levels of access required to deploy to this protected environment. Mutually exclusive with `user_id` and `group_id`. Valid values are `developer`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#access_level GroupProtectedEnvironment#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of the group allowed to deploy to this protected environment. The group must be a sub-group under the given group. Mutually exclusive with `access_level` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#group_id GroupProtectedEnvironment#group_id}
    */
    readonly groupId?: number;
    /**
    * Group inheritance allows deploy access levels to take inherited group membership into account. Valid values are `0`, `1`. `0` => Direct group membership only, `1` => All inherited groups. Default: `0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#group_inheritance_type GroupProtectedEnvironment#group_inheritance_type}
    */
    readonly groupInheritanceType?: number;
    /**
    * The ID of the user allowed to deploy to this protected environment. The user must be a member of the group with Maintainer role or higher. Mutually exclusive with `access_level` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#user_id GroupProtectedEnvironment#user_id}
    */
    readonly userId?: number;
}
export declare function groupProtectedEnvironmentDeployAccessLevelsToTerraform(struct?: GroupProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable): any;
export declare function groupProtectedEnvironmentDeployAccessLevelsToHclTerraform(struct?: GroupProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable): any;
export declare class GroupProtectedEnvironmentDeployAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: GroupProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _groupInheritanceType?;
    get groupInheritanceType(): number;
    set groupInheritanceType(value: number);
    resetGroupInheritanceType(): void;
    get groupInheritanceTypeInput(): number | undefined;
    get id(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class GroupProtectedEnvironmentDeployAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GroupProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupProtectedEnvironmentDeployAccessLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment gitlab_group_protected_environment}
*/
export declare class GroupProtectedEnvironment extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_protected_environment";
    /**
    * Generates CDKTF code for importing a GroupProtectedEnvironment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupProtectedEnvironment to import
    * @param importFromId The id of the existing GroupProtectedEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupProtectedEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/group_protected_environment gitlab_group_protected_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupProtectedEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: GroupProtectedEnvironmentConfig);
    private _approvalRules;
    get approvalRules(): GroupProtectedEnvironmentApprovalRulesList;
    putApprovalRules(value: GroupProtectedEnvironmentApprovalRules[] | cdktf.IResolvable): void;
    resetApprovalRules(): void;
    get approvalRulesInput(): cdktf.IResolvable | GroupProtectedEnvironmentApprovalRules[] | undefined;
    private _deployAccessLevels;
    get deployAccessLevels(): GroupProtectedEnvironmentDeployAccessLevelsList;
    putDeployAccessLevels(value: GroupProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable): void;
    get deployAccessLevelsInput(): cdktf.IResolvable | GroupProtectedEnvironmentDeployAccessLevels[] | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
