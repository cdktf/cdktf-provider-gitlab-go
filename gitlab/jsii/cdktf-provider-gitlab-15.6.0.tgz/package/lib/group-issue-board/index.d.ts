/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupIssueBoardConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or URL-encoded path of the group owned by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#group GroupIssueBoard#group}
    */
    readonly group: string;
    /**
    * The list of label names which the board should be scoped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#labels GroupIssueBoard#labels}
    */
    readonly labels?: string[];
    /**
    * The milestone the board should be scoped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#milestone_id GroupIssueBoard#milestone_id}
    */
    readonly milestoneId?: number;
    /**
    * The name of the board.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#name GroupIssueBoard#name}
    */
    readonly name: string;
    /**
    * lists block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#lists GroupIssueBoard#lists}
    */
    readonly lists?: GroupIssueBoardLists[] | cdktf.IResolvable;
}
export interface GroupIssueBoardLists {
    /**
    * The ID of the label the list should be scoped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#label_id GroupIssueBoard#label_id}
    */
    readonly labelId?: number;
    /**
    * The explicit position of the list within the board, zero based.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#position GroupIssueBoard#position}
    */
    readonly position?: number;
}
export declare function groupIssueBoardListsToTerraform(struct?: GroupIssueBoardLists | cdktf.IResolvable): any;
export declare function groupIssueBoardListsToHclTerraform(struct?: GroupIssueBoardLists | cdktf.IResolvable): any;
export declare class GroupIssueBoardListsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupIssueBoardLists | cdktf.IResolvable | undefined;
    set internalValue(value: GroupIssueBoardLists | cdktf.IResolvable | undefined);
    get id(): number;
    private _labelId?;
    get labelId(): number;
    set labelId(value: number);
    resetLabelId(): void;
    get labelIdInput(): number | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
}
export declare class GroupIssueBoardListsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GroupIssueBoardLists[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupIssueBoardListsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board gitlab_group_issue_board}
*/
export declare class GroupIssueBoard extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_issue_board";
    /**
    * Generates CDKTF code for importing a GroupIssueBoard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupIssueBoard to import
    * @param importFromId The id of the existing GroupIssueBoard that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupIssueBoard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_issue_board gitlab_group_issue_board} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupIssueBoardConfig
    */
    constructor(scope: Construct, id: string, config: GroupIssueBoardConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _milestoneId?;
    get milestoneId(): number;
    set milestoneId(value: number);
    resetMilestoneId(): void;
    get milestoneIdInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _lists;
    get lists(): GroupIssueBoardListsList;
    putLists(value: GroupIssueBoardLists[] | cdktf.IResolvable): void;
    resetLists(): void;
    get listsInput(): cdktf.IResolvable | GroupIssueBoardLists[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
