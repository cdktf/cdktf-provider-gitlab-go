/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ComplianceFrameworkConfig extends cdktf.TerraformMetaArguments {
    /**
    * New color representation of the compliance framework in hex format. e.g. #FCA121.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#color ComplianceFramework#color}
    */
    readonly color: string;
    /**
    * Set this compliance framework as the default framework for the group. Default: `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#default ComplianceFramework#default}
    */
    readonly default?: boolean | cdktf.IResolvable;
    /**
    * Description for the compliance framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#description ComplianceFramework#description}
    */
    readonly description: string;
    /**
    * Name for the compliance framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#name ComplianceFramework#name}
    */
    readonly name: string;
    /**
    * Full path of the namespace to add the compliance framework to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#namespace_path ComplianceFramework#namespace_path}
    */
    readonly namespacePath: string;
    /**
    * Full path of the compliance pipeline configuration stored in a project repository, such as `.gitlab/.compliance-gitlab-ci.yml@compliance/hipaa`. Required format: `path/file.y[a]ml@group-name/project-name` **Note**: Ultimate license required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#pipeline_configuration_full_path ComplianceFramework#pipeline_configuration_full_path}
    */
    readonly pipelineConfigurationFullPath?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework gitlab_compliance_framework}
*/
export declare class ComplianceFramework extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_compliance_framework";
    /**
    * Generates CDKTF code for importing a ComplianceFramework resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComplianceFramework to import
    * @param importFromId The id of the existing ComplianceFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComplianceFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/compliance_framework gitlab_compliance_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComplianceFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: ComplianceFrameworkConfig);
    private _color?;
    get color(): string;
    set color(value: string);
    get colorInput(): string | undefined;
    private _default?;
    get default(): boolean | cdktf.IResolvable;
    set default(value: boolean | cdktf.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get frameworkId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespacePath?;
    get namespacePath(): string;
    set namespacePath(value: string);
    get namespacePathInput(): string | undefined;
    private _pipelineConfigurationFullPath?;
    get pipelineConfigurationFullPath(): string;
    set pipelineConfigurationFullPath(value: string);
    resetPipelineConfigurationFullPath(): void;
    get pipelineConfigurationFullPathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
