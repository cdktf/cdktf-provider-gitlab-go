/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabArtifactFileConfig extends cdktf.TerraformMetaArguments {
    /**
    * Path to the artifact file within the job's artifacts archive. This path is relative to the archive contents (not the local filesystem). Ensure each `gitlab_artifact_file` data source in your configuration uses a unique artifact_path to avoid ambiguity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#artifact_path DataGitlabArtifactFile#artifact_path}
    */
    readonly artifactPath: string;
    /**
    * The name of the job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#job DataGitlabArtifactFile#job}
    */
    readonly job: string;
    /**
    * Maximum bytes to read from the artifact. Defaults to 10MB (10485760 bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#max_size_bytes DataGitlabArtifactFile#max_size_bytes}
    */
    readonly maxSizeBytes?: number;
    /**
    * The ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#project DataGitlabArtifactFile#project}
    */
    readonly project: string;
    /**
    * The name of the branch, tag, or commit SHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#ref DataGitlabArtifactFile#ref}
    */
    readonly ref: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file gitlab_artifact_file}
*/
export declare class DataGitlabArtifactFile extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_artifact_file";
    /**
    * Generates CDKTF code for importing a DataGitlabArtifactFile resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabArtifactFile to import
    * @param importFromId The id of the existing DataGitlabArtifactFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabArtifactFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/artifact_file gitlab_artifact_file} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabArtifactFileConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabArtifactFileConfig);
    private _artifactPath?;
    get artifactPath(): string;
    set artifactPath(value: string);
    get artifactPathInput(): string | undefined;
    get content(): string;
    get contentBase64(): string;
    get id(): string;
    private _job?;
    get job(): string;
    set job(value: string);
    get jobInput(): string | undefined;
    private _maxSizeBytes?;
    get maxSizeBytes(): number;
    set maxSizeBytes(value: number);
    resetMaxSizeBytes(): void;
    get maxSizeBytesInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    get refInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
