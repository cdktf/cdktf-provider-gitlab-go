/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GlobalLevelNotificationsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Enable notifications for closed issues. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#close_issue GlobalLevelNotifications#close_issue}
    */
    readonly closeIssue?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for closed merge requests. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#close_merge_request GlobalLevelNotifications#close_merge_request}
    */
    readonly closeMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for failed pipelines. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#failed_pipeline GlobalLevelNotifications#failed_pipeline}
    */
    readonly failedPipeline?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for fixed pipelines. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#fixed_pipeline GlobalLevelNotifications#fixed_pipeline}
    */
    readonly fixedPipeline?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for due issues. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#issue_due GlobalLevelNotifications#issue_due}
    */
    readonly issueDue?: boolean | cdktf.IResolvable;
    /**
    * The level of the notification. Valid values are: `disabled`, `participating`, `watch`, `global`, `mention`, `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#level GlobalLevelNotifications#level}
    */
    readonly level?: string;
    /**
    * Enable notifications for merged merge requests. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#merge_merge_request GlobalLevelNotifications#merge_merge_request}
    */
    readonly mergeMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for merged merge requests when the pipeline succeeds. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#merge_when_pipeline_succeeds GlobalLevelNotifications#merge_when_pipeline_succeeds}
    */
    readonly mergeWhenPipelineSucceeds?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for moved projects. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#moved_project GlobalLevelNotifications#moved_project}
    */
    readonly movedProject?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for new issues. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#new_issue GlobalLevelNotifications#new_issue}
    */
    readonly newIssue?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for new merge requests. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#new_merge_request GlobalLevelNotifications#new_merge_request}
    */
    readonly newMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for new notes on merge requests. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#new_note GlobalLevelNotifications#new_note}
    */
    readonly newNote?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for push to merge request branches. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#push_to_merge_request GlobalLevelNotifications#push_to_merge_request}
    */
    readonly pushToMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for issue reassignments. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#reassign_issue GlobalLevelNotifications#reassign_issue}
    */
    readonly reassignIssue?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for merge request reassignments. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#reassign_merge_request GlobalLevelNotifications#reassign_merge_request}
    */
    readonly reassignMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for reopened issues. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#reopen_issue GlobalLevelNotifications#reopen_issue}
    */
    readonly reopenIssue?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for reopened merge requests. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#reopen_merge_request GlobalLevelNotifications#reopen_merge_request}
    */
    readonly reopenMergeRequest?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for successful pipelines. Can only be used when `level` is `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#success_pipeline GlobalLevelNotifications#success_pipeline}
    */
    readonly successPipeline?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications gitlab_global_level_notifications}
*/
export declare class GlobalLevelNotifications extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_global_level_notifications";
    /**
    * Generates CDKTF code for importing a GlobalLevelNotifications resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GlobalLevelNotifications to import
    * @param importFromId The id of the existing GlobalLevelNotifications that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GlobalLevelNotifications to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/global_level_notifications gitlab_global_level_notifications} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GlobalLevelNotificationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: GlobalLevelNotificationsConfig);
    private _closeIssue?;
    get closeIssue(): boolean | cdktf.IResolvable;
    set closeIssue(value: boolean | cdktf.IResolvable);
    resetCloseIssue(): void;
    get closeIssueInput(): boolean | cdktf.IResolvable | undefined;
    private _closeMergeRequest?;
    get closeMergeRequest(): boolean | cdktf.IResolvable;
    set closeMergeRequest(value: boolean | cdktf.IResolvable);
    resetCloseMergeRequest(): void;
    get closeMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _failedPipeline?;
    get failedPipeline(): boolean | cdktf.IResolvable;
    set failedPipeline(value: boolean | cdktf.IResolvable);
    resetFailedPipeline(): void;
    get failedPipelineInput(): boolean | cdktf.IResolvable | undefined;
    private _fixedPipeline?;
    get fixedPipeline(): boolean | cdktf.IResolvable;
    set fixedPipeline(value: boolean | cdktf.IResolvable);
    resetFixedPipeline(): void;
    get fixedPipelineInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _issueDue?;
    get issueDue(): boolean | cdktf.IResolvable;
    set issueDue(value: boolean | cdktf.IResolvable);
    resetIssueDue(): void;
    get issueDueInput(): boolean | cdktf.IResolvable | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _mergeMergeRequest?;
    get mergeMergeRequest(): boolean | cdktf.IResolvable;
    set mergeMergeRequest(value: boolean | cdktf.IResolvable);
    resetMergeMergeRequest(): void;
    get mergeMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeWhenPipelineSucceeds?;
    get mergeWhenPipelineSucceeds(): boolean | cdktf.IResolvable;
    set mergeWhenPipelineSucceeds(value: boolean | cdktf.IResolvable);
    resetMergeWhenPipelineSucceeds(): void;
    get mergeWhenPipelineSucceedsInput(): boolean | cdktf.IResolvable | undefined;
    private _movedProject?;
    get movedProject(): boolean | cdktf.IResolvable;
    set movedProject(value: boolean | cdktf.IResolvable);
    resetMovedProject(): void;
    get movedProjectInput(): boolean | cdktf.IResolvable | undefined;
    private _newIssue?;
    get newIssue(): boolean | cdktf.IResolvable;
    set newIssue(value: boolean | cdktf.IResolvable);
    resetNewIssue(): void;
    get newIssueInput(): boolean | cdktf.IResolvable | undefined;
    private _newMergeRequest?;
    get newMergeRequest(): boolean | cdktf.IResolvable;
    set newMergeRequest(value: boolean | cdktf.IResolvable);
    resetNewMergeRequest(): void;
    get newMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _newNote?;
    get newNote(): boolean | cdktf.IResolvable;
    set newNote(value: boolean | cdktf.IResolvable);
    resetNewNote(): void;
    get newNoteInput(): boolean | cdktf.IResolvable | undefined;
    private _pushToMergeRequest?;
    get pushToMergeRequest(): boolean | cdktf.IResolvable;
    set pushToMergeRequest(value: boolean | cdktf.IResolvable);
    resetPushToMergeRequest(): void;
    get pushToMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _reassignIssue?;
    get reassignIssue(): boolean | cdktf.IResolvable;
    set reassignIssue(value: boolean | cdktf.IResolvable);
    resetReassignIssue(): void;
    get reassignIssueInput(): boolean | cdktf.IResolvable | undefined;
    private _reassignMergeRequest?;
    get reassignMergeRequest(): boolean | cdktf.IResolvable;
    set reassignMergeRequest(value: boolean | cdktf.IResolvable);
    resetReassignMergeRequest(): void;
    get reassignMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _reopenIssue?;
    get reopenIssue(): boolean | cdktf.IResolvable;
    set reopenIssue(value: boolean | cdktf.IResolvable);
    resetReopenIssue(): void;
    get reopenIssueInput(): boolean | cdktf.IResolvable | undefined;
    private _reopenMergeRequest?;
    get reopenMergeRequest(): boolean | cdktf.IResolvable;
    set reopenMergeRequest(value: boolean | cdktf.IResolvable);
    resetReopenMergeRequest(): void;
    get reopenMergeRequestInput(): boolean | cdktf.IResolvable | undefined;
    private _successPipeline?;
    get successPipeline(): boolean | cdktf.IResolvable;
    set successPipeline(value: boolean | cdktf.IResolvable);
    resetSuccessPipeline(): void;
    get successPipelineInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
