/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectTargetBranchRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule#project ProjectTargetBranchRule#project}
    */
    readonly project: string;
    /**
    * A pattern matching the branch name for which the merge request should have a default target branch configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule#source_branch_pattern ProjectTargetBranchRule#source_branch_pattern}
    */
    readonly sourceBranchPattern: string;
    /**
    * The name of the branch to which the merge request should be addressed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule#target_branch_name ProjectTargetBranchRule#target_branch_name}
    */
    readonly targetBranchName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule gitlab_project_target_branch_rule}
*/
export declare class ProjectTargetBranchRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_target_branch_rule";
    /**
    * Generates CDKTF code for importing a ProjectTargetBranchRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectTargetBranchRule to import
    * @param importFromId The id of the existing ProjectTargetBranchRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectTargetBranchRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_target_branch_rule gitlab_project_target_branch_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectTargetBranchRuleConfig
    */
    constructor(scope: Construct, id: string, config: ProjectTargetBranchRuleConfig);
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _sourceBranchPattern?;
    get sourceBranchPattern(): string;
    set sourceBranchPattern(value: string);
    get sourceBranchPatternInput(): string | undefined;
    private _targetBranchName?;
    get targetBranchName(): string;
    set targetBranchName(value: string);
    get targetBranchNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
