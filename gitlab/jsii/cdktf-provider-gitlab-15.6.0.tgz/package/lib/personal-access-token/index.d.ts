/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PersonalAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the personal access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#description PersonalAccessToken#description}
    */
    readonly description?: string;
    /**
    * When the token will expire, YYYY-MM-DD format. Is automatically set when `rotation_configuration` is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#expires_at PersonalAccessToken#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The name of the personal access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#name PersonalAccessToken#name}
    */
    readonly name: string;
    /**
    * The configuration for when to rotate a token automatically. Will not rotate a token until `terraform apply` is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#rotation_configuration PersonalAccessToken#rotation_configuration}
    */
    readonly rotationConfiguration?: PersonalAccessTokenRotationConfiguration;
    /**
    * The scopes of the personal access token. valid values are: `api`, `read_user`, `read_api`, `read_repository`, `write_repository`, `read_registry`, `write_registry`, `read_virtual_registry`, `write_virtual_registry`, `sudo`, `admin_mode`, `create_runner`, `manage_runner`, `ai_features`, `k8s_proxy`, `self_rotate`, `read_service_ping`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#scopes PersonalAccessToken#scopes}
    */
    readonly scopes: string[];
    /**
    * The ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#user_id PersonalAccessToken#user_id}
    */
    readonly userId: number;
    /**
    * Wether to validate if the expiration date is in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#validate_past_expiration_date PersonalAccessToken#validate_past_expiration_date}
    */
    readonly validatePastExpirationDate?: boolean | cdktf.IResolvable;
}
export interface PersonalAccessTokenRotationConfiguration {
    /**
    * The duration (in days) the new token should be valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#expiration_days PersonalAccessToken#expiration_days}
    */
    readonly expirationDays: number;
    /**
    * The duration (in days) before the expiration when the token should be rotated. As an example, if set to 7 days, the token will rotate 7 days before the expiration date, but only when `terraform apply` is run in that timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#rotate_before_days PersonalAccessToken#rotate_before_days}
    */
    readonly rotateBeforeDays: number;
}
export declare function personalAccessTokenRotationConfigurationToTerraform(struct?: PersonalAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare function personalAccessTokenRotationConfigurationToHclTerraform(struct?: PersonalAccessTokenRotationConfiguration | cdktf.IResolvable): any;
export declare class PersonalAccessTokenRotationConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersonalAccessTokenRotationConfiguration | cdktf.IResolvable | undefined;
    set internalValue(value: PersonalAccessTokenRotationConfiguration | cdktf.IResolvable | undefined);
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    get expirationDaysInput(): number | undefined;
    private _rotateBeforeDays?;
    get rotateBeforeDays(): number;
    set rotateBeforeDays(value: number);
    get rotateBeforeDaysInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token gitlab_personal_access_token}
*/
export declare class PersonalAccessToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_personal_access_token";
    /**
    * Generates CDKTF code for importing a PersonalAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PersonalAccessToken to import
    * @param importFromId The id of the existing PersonalAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PersonalAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/personal_access_token gitlab_personal_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PersonalAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: PersonalAccessTokenConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get revoked(): cdktf.IResolvable;
    private _rotationConfiguration;
    get rotationConfiguration(): PersonalAccessTokenRotationConfigurationOutputReference;
    putRotationConfiguration(value: PersonalAccessTokenRotationConfiguration): void;
    resetRotationConfiguration(): void;
    get rotationConfigurationInput(): cdktf.IResolvable | PersonalAccessTokenRotationConfiguration | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    get token(): string;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    private _validatePastExpirationDate?;
    get validatePastExpirationDate(): boolean | cdktf.IResolvable;
    set validatePastExpirationDate(value: boolean | cdktf.IResolvable);
    resetValidatePastExpirationDate(): void;
    get validatePastExpirationDateInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
