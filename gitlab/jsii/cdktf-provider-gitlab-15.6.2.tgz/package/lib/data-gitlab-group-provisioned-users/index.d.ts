/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupProvisionedUsersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return only active provisioned users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#active DataGitlabGroupProvisionedUsers#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * Return only blocked provisioned users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#blocked DataGitlabGroupProvisionedUsers#blocked}
    */
    readonly blocked?: boolean | cdktf.IResolvable;
    /**
    * Return only provisioned users created on or after the specified date. Expected in ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#created_after DataGitlabGroupProvisionedUsers#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Return only provisioned users created on or before the specified date. Expected in ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#created_before DataGitlabGroupProvisionedUsers#created_before}
    */
    readonly createdBefore?: string;
    /**
    * The ID or URL-encoded path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#id DataGitlabGroupProvisionedUsers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The search query to filter the provisioned users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#search DataGitlabGroupProvisionedUsers#search}
    */
    readonly search?: string;
    /**
    * The username of the provisioned user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#username DataGitlabGroupProvisionedUsers#username}
    */
    readonly username?: string;
    /**
    * provisioned_users block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#provisioned_users DataGitlabGroupProvisionedUsers#provisioned_users}
    */
    readonly provisionedUsers?: DataGitlabGroupProvisionedUsersProvisionedUsers[] | cdktf.IResolvable;
}
export interface DataGitlabGroupProvisionedUsersProvisionedUsers {
}
export declare function dataGitlabGroupProvisionedUsersProvisionedUsersToTerraform(struct?: DataGitlabGroupProvisionedUsersProvisionedUsers | cdktf.IResolvable): any;
export declare function dataGitlabGroupProvisionedUsersProvisionedUsersToHclTerraform(struct?: DataGitlabGroupProvisionedUsersProvisionedUsers | cdktf.IResolvable): any;
export declare class DataGitlabGroupProvisionedUsersProvisionedUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupProvisionedUsersProvisionedUsers | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabGroupProvisionedUsersProvisionedUsers | cdktf.IResolvable | undefined);
    get avatarUrl(): string;
    get bio(): string;
    get bot(): cdktf.IResolvable;
    get confirmedAt(): string;
    get createdAt(): string;
    get email(): string;
    get external(): cdktf.IResolvable;
    get id(): string;
    get jobTitle(): string;
    get lastActivityOn(): string;
    get lastSignInAt(): string;
    get linkedin(): string;
    get location(): string;
    get name(): string;
    get organization(): string;
    get privateProfile(): cdktf.IResolvable;
    get pronouns(): string;
    get publicEmail(): string;
    get skype(): string;
    get state(): string;
    get twitter(): string;
    get twoFactorEnabled(): cdktf.IResolvable;
    get username(): string;
    get webUrl(): string;
    get websiteUrl(): string;
}
export declare class DataGitlabGroupProvisionedUsersProvisionedUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabGroupProvisionedUsersProvisionedUsers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupProvisionedUsersProvisionedUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users gitlab_group_provisioned_users}
*/
export declare class DataGitlabGroupProvisionedUsers extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_provisioned_users";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupProvisionedUsers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupProvisionedUsers to import
    * @param importFromId The id of the existing DataGitlabGroupProvisionedUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupProvisionedUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_provisioned_users gitlab_group_provisioned_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupProvisionedUsersConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupProvisionedUsersConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _blocked?;
    get blocked(): boolean | cdktf.IResolvable;
    set blocked(value: boolean | cdktf.IResolvable);
    resetBlocked(): void;
    get blockedInput(): boolean | cdktf.IResolvable | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _provisionedUsers;
    get provisionedUsers(): DataGitlabGroupProvisionedUsersProvisionedUsersList;
    putProvisionedUsers(value: DataGitlabGroupProvisionedUsersProvisionedUsers[] | cdktf.IResolvable): void;
    resetProvisionedUsers(): void;
    get provisionedUsersInput(): cdktf.IResolvable | DataGitlabGroupProvisionedUsersProvisionedUsers[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
