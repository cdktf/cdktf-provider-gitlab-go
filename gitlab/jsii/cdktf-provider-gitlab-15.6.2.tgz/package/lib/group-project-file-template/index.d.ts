/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupProjectFileTemplateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the project that will be used for file templates. This project must be the direct
    * 				child of the project defined by the group_id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template#file_template_project_id GroupProjectFileTemplate#file_template_project_id}
    */
    readonly fileTemplateProjectId: number;
    /**
    * The ID of the group that will use the file template project. This group must be the direct
    *                 parent of the project defined by project_id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template#group_id GroupProjectFileTemplate#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template#id GroupProjectFileTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template gitlab_group_project_file_template}
*/
export declare class GroupProjectFileTemplate extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_project_file_template";
    /**
    * Generates CDKTF code for importing a GroupProjectFileTemplate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupProjectFileTemplate to import
    * @param importFromId The id of the existing GroupProjectFileTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupProjectFileTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_project_file_template gitlab_group_project_file_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupProjectFileTemplateConfig
    */
    constructor(scope: Construct, id: string, config: GroupProjectFileTemplateConfig);
    private _fileTemplateProjectId?;
    get fileTemplateProjectId(): number;
    set fileTemplateProjectId(value: number);
    get fileTemplateProjectIdInput(): number | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
