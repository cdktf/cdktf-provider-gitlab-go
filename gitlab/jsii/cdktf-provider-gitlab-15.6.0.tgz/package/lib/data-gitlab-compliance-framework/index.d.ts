/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabComplianceFrameworkConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name for the compliance framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/compliance_framework#name DataGitlabComplianceFramework#name}
    */
    readonly name: string;
    /**
    * Full path of the namespace to where the compliance framework is.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/compliance_framework#namespace_path DataGitlabComplianceFramework#namespace_path}
    */
    readonly namespacePath: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/compliance_framework gitlab_compliance_framework}
*/
export declare class DataGitlabComplianceFramework extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_compliance_framework";
    /**
    * Generates CDKTF code for importing a DataGitlabComplianceFramework resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabComplianceFramework to import
    * @param importFromId The id of the existing DataGitlabComplianceFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/compliance_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabComplianceFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/compliance_framework gitlab_compliance_framework} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabComplianceFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabComplianceFrameworkConfig);
    get color(): string;
    get default(): cdktf.IResolvable;
    get description(): string;
    get frameworkId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespacePath?;
    get namespacePath(): string;
    set namespacePath(value: string);
    get namespacePathInput(): string | undefined;
    get pipelineConfigurationFullPath(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
