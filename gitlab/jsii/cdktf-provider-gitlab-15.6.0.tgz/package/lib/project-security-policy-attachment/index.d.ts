/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectSecurityPolicyAttachmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or Full Path of the security policy project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_security_policy_attachment#policy_project ProjectSecurityPolicyAttachment#policy_project}
    */
    readonly policyProject: string;
    /**
    * The ID or Full Path of the project which will have the security policy project assigned to it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_security_policy_attachment#project ProjectSecurityPolicyAttachment#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_security_policy_attachment gitlab_project_security_policy_attachment}
*/
export declare class ProjectSecurityPolicyAttachment extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_security_policy_attachment";
    /**
    * Generates CDKTF code for importing a ProjectSecurityPolicyAttachment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectSecurityPolicyAttachment to import
    * @param importFromId The id of the existing ProjectSecurityPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_security_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectSecurityPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_security_policy_attachment gitlab_project_security_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectSecurityPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: ProjectSecurityPolicyAttachmentConfig);
    get id(): string;
    private _policyProject?;
    get policyProject(): string;
    set policyProject(value: string);
    get policyProjectInput(): string | undefined;
    get policyProjectGraphqlId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectGraphqlId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
