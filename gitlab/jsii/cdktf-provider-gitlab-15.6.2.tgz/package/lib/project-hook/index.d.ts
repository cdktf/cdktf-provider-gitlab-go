/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectHookConfig extends cdktf.TerraformMetaArguments {
    /**
    * Invoke the hook for confidential issues events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#confidential_issues_events ProjectHook#confidential_issues_events}
    */
    readonly confidentialIssuesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for confidential note events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#confidential_note_events ProjectHook#confidential_note_events}
    */
    readonly confidentialNoteEvents?: boolean | cdktf.IResolvable;
    /**
    * Custom headers for the project webhook. Available from GitLab 17.1 onwards.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#custom_headers ProjectHook#custom_headers}
    */
    readonly customHeaders?: ProjectHookCustomHeaders[] | cdktf.IResolvable;
    /**
    * Custom webhook template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#custom_webhook_template ProjectHook#custom_webhook_template}
    */
    readonly customWebhookTemplate?: string;
    /**
    * Invoke the hook for deployment events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#deployment_events ProjectHook#deployment_events}
    */
    readonly deploymentEvents?: boolean | cdktf.IResolvable;
    /**
    * Description of the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#description ProjectHook#description}
    */
    readonly description?: string;
    /**
    * Enable SSL verification when invoking the hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#enable_ssl_verification ProjectHook#enable_ssl_verification}
    */
    readonly enableSslVerification?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for issues events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#issues_events ProjectHook#issues_events}
    */
    readonly issuesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for job events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#job_events ProjectHook#job_events}
    */
    readonly jobEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for merge requests events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#merge_requests_events ProjectHook#merge_requests_events}
    */
    readonly mergeRequestsEvents?: boolean | cdktf.IResolvable;
    /**
    * Name of the project webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#name ProjectHook#name}
    */
    readonly name?: string;
    /**
    * Invoke the hook for note events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#note_events ProjectHook#note_events}
    */
    readonly noteEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for pipeline events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#pipeline_events ProjectHook#pipeline_events}
    */
    readonly pipelineEvents?: boolean | cdktf.IResolvable;
    /**
    * The name or id of the project to add the hook to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#project ProjectHook#project}
    */
    readonly project: string;
    /**
    * Invoke the hook for push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#push_events ProjectHook#push_events}
    */
    readonly pushEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for push events on matching branches only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#push_events_branch_filter ProjectHook#push_events_branch_filter}
    */
    readonly pushEventsBranchFilter?: string;
    /**
    * Invoke the hook for release events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#releases_events ProjectHook#releases_events}
    */
    readonly releasesEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for project access token expiry events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#resource_access_token_events ProjectHook#resource_access_token_events}
    */
    readonly resourceAccessTokenEvents?: boolean | cdktf.IResolvable;
    /**
    * Invoke the hook for tag push events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#tag_push_events ProjectHook#tag_push_events}
    */
    readonly tagPushEvents?: boolean | cdktf.IResolvable;
    /**
    * A token to present when invoking the hook. The token is not available for imported resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#token ProjectHook#token}
    */
    readonly token?: string;
    /**
    * The url of the hook to invoke. Forces re-creation to preserve `token`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#url ProjectHook#url}
    */
    readonly url: string;
    /**
    * Invoke the hook for wiki page events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#wiki_page_events ProjectHook#wiki_page_events}
    */
    readonly wikiPageEvents?: boolean | cdktf.IResolvable;
}
export interface ProjectHookCustomHeaders {
    /**
    * Key of the custom header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#key ProjectHook#key}
    */
    readonly key: string;
    /**
    * Value of the custom header. This value cannot be imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#value ProjectHook#value}
    */
    readonly value: string;
}
export declare function projectHookCustomHeadersToTerraform(struct?: ProjectHookCustomHeaders | cdktf.IResolvable): any;
export declare function projectHookCustomHeadersToHclTerraform(struct?: ProjectHookCustomHeaders | cdktf.IResolvable): any;
export declare class ProjectHookCustomHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectHookCustomHeaders | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectHookCustomHeaders | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ProjectHookCustomHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ProjectHookCustomHeaders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectHookCustomHeadersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook gitlab_project_hook}
*/
export declare class ProjectHook extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_hook";
    /**
    * Generates CDKTF code for importing a ProjectHook resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectHook to import
    * @param importFromId The id of the existing ProjectHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_hook gitlab_project_hook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectHookConfig
    */
    constructor(scope: Construct, id: string, config: ProjectHookConfig);
    private _confidentialIssuesEvents?;
    get confidentialIssuesEvents(): boolean | cdktf.IResolvable;
    set confidentialIssuesEvents(value: boolean | cdktf.IResolvable);
    resetConfidentialIssuesEvents(): void;
    get confidentialIssuesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _confidentialNoteEvents?;
    get confidentialNoteEvents(): boolean | cdktf.IResolvable;
    set confidentialNoteEvents(value: boolean | cdktf.IResolvable);
    resetConfidentialNoteEvents(): void;
    get confidentialNoteEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _customHeaders;
    get customHeaders(): ProjectHookCustomHeadersList;
    putCustomHeaders(value: ProjectHookCustomHeaders[] | cdktf.IResolvable): void;
    resetCustomHeaders(): void;
    get customHeadersInput(): cdktf.IResolvable | ProjectHookCustomHeaders[] | undefined;
    private _customWebhookTemplate?;
    get customWebhookTemplate(): string;
    set customWebhookTemplate(value: string);
    resetCustomWebhookTemplate(): void;
    get customWebhookTemplateInput(): string | undefined;
    private _deploymentEvents?;
    get deploymentEvents(): boolean | cdktf.IResolvable;
    set deploymentEvents(value: boolean | cdktf.IResolvable);
    resetDeploymentEvents(): void;
    get deploymentEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableSslVerification?;
    get enableSslVerification(): boolean | cdktf.IResolvable;
    set enableSslVerification(value: boolean | cdktf.IResolvable);
    resetEnableSslVerification(): void;
    get enableSslVerificationInput(): boolean | cdktf.IResolvable | undefined;
    get hookId(): number;
    get id(): string;
    private _issuesEvents?;
    get issuesEvents(): boolean | cdktf.IResolvable;
    set issuesEvents(value: boolean | cdktf.IResolvable);
    resetIssuesEvents(): void;
    get issuesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _jobEvents?;
    get jobEvents(): boolean | cdktf.IResolvable;
    set jobEvents(value: boolean | cdktf.IResolvable);
    resetJobEvents(): void;
    get jobEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestsEvents?;
    get mergeRequestsEvents(): boolean | cdktf.IResolvable;
    set mergeRequestsEvents(value: boolean | cdktf.IResolvable);
    resetMergeRequestsEvents(): void;
    get mergeRequestsEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _noteEvents?;
    get noteEvents(): boolean | cdktf.IResolvable;
    set noteEvents(value: boolean | cdktf.IResolvable);
    resetNoteEvents(): void;
    get noteEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _pipelineEvents?;
    get pipelineEvents(): boolean | cdktf.IResolvable;
    set pipelineEvents(value: boolean | cdktf.IResolvable);
    resetPipelineEvents(): void;
    get pipelineEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectId(): number;
    private _pushEvents?;
    get pushEvents(): boolean | cdktf.IResolvable;
    set pushEvents(value: boolean | cdktf.IResolvable);
    resetPushEvents(): void;
    get pushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _pushEventsBranchFilter?;
    get pushEventsBranchFilter(): string;
    set pushEventsBranchFilter(value: string);
    resetPushEventsBranchFilter(): void;
    get pushEventsBranchFilterInput(): string | undefined;
    private _releasesEvents?;
    get releasesEvents(): boolean | cdktf.IResolvable;
    set releasesEvents(value: boolean | cdktf.IResolvable);
    resetReleasesEvents(): void;
    get releasesEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _resourceAccessTokenEvents?;
    get resourceAccessTokenEvents(): boolean | cdktf.IResolvable;
    set resourceAccessTokenEvents(value: boolean | cdktf.IResolvable);
    resetResourceAccessTokenEvents(): void;
    get resourceAccessTokenEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _tagPushEvents?;
    get tagPushEvents(): boolean | cdktf.IResolvable;
    set tagPushEvents(value: boolean | cdktf.IResolvable);
    resetTagPushEvents(): void;
    get tagPushEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _wikiPageEvents?;
    get wikiPageEvents(): boolean | cdktf.IResolvable;
    set wikiPageEvents(value: boolean | cdktf.IResolvable);
    resetWikiPageEvents(): void;
    get wikiPageEventsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
