/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectProtectedEnvironmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Array of approval rules to deploy, with each described by a hash. Elements in the `approval_rules` should be one of `user_id`, `group_id` or `access_level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#approval_rules ProjectProtectedEnvironment#approval_rules}
    */
    readonly approvalRules?: ProjectProtectedEnvironmentApprovalRules[] | cdktf.IResolvable;
    /**
    * Array of access levels allowed to deploy, with each described by a hash.  Elements in the `deploy_access_levels` should be one of `user_id`, `group_id` or `access_level`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#deploy_access_levels_attribute ProjectProtectedEnvironment#deploy_access_levels_attribute}
    */
    readonly deployAccessLevelsAttribute?: ProjectProtectedEnvironmentDeployAccessLevelsAttribute[] | cdktf.IResolvable;
    /**
    * The name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#environment ProjectProtectedEnvironment#environment}
    */
    readonly environment: string;
    /**
    * The ID or full path of the project which the protected environment is created against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#project ProjectProtectedEnvironment#project}
    */
    readonly project: string;
    /**
    * deploy_access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#deploy_access_levels ProjectProtectedEnvironment#deploy_access_levels}
    */
    readonly deployAccessLevels?: ProjectProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable;
}
export interface ProjectProtectedEnvironmentApprovalRules {
    /**
    * Levels of access allowed to approve a deployment to this protected environment. Mutually exclusive with `user_id` and `group_id`. Valid values are `developer`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#access_level ProjectProtectedEnvironment#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of the group allowed to approve a deployment to this protected environment. The project must be shared with the group. Mutually exclusive with `access_level` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_id ProjectProtectedEnvironment#group_id}
    */
    readonly groupId?: number;
    /**
    * Group inheritance allows deploy access levels to take inherited group membership into account. Valid values are `0`, `1`. `0` => Direct group membership only, `1` => All inherited groups. Default: `0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_inheritance_type ProjectProtectedEnvironment#group_inheritance_type}
    */
    readonly groupInheritanceType?: number;
    /**
    * The number of approval required to allow deployment to this protected environment. This is mutually exclusive with user_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#required_approvals ProjectProtectedEnvironment#required_approvals}
    */
    readonly requiredApprovals?: number;
    /**
    * The ID of the user allowed to approve a deployment to this protected environment. The user must be a member of the project. Mutually exclusive with `access_level` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#user_id ProjectProtectedEnvironment#user_id}
    */
    readonly userId?: number;
}
export declare function projectProtectedEnvironmentApprovalRulesToTerraform(struct?: ProjectProtectedEnvironmentApprovalRules | cdktf.IResolvable): any;
export declare function projectProtectedEnvironmentApprovalRulesToHclTerraform(struct?: ProjectProtectedEnvironmentApprovalRules | cdktf.IResolvable): any;
export declare class ProjectProtectedEnvironmentApprovalRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectProtectedEnvironmentApprovalRules | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectProtectedEnvironmentApprovalRules | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _groupInheritanceType?;
    get groupInheritanceType(): number;
    set groupInheritanceType(value: number);
    resetGroupInheritanceType(): void;
    get groupInheritanceTypeInput(): number | undefined;
    get id(): number;
    private _requiredApprovals?;
    get requiredApprovals(): number;
    set requiredApprovals(value: number);
    resetRequiredApprovals(): void;
    get requiredApprovalsInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class ProjectProtectedEnvironmentApprovalRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ProjectProtectedEnvironmentApprovalRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectProtectedEnvironmentApprovalRulesOutputReference;
}
export interface ProjectProtectedEnvironmentDeployAccessLevelsAttribute {
    /**
    * Levels of access required to deploy to this protected environment. Mutually exclusive with `user_id` and `group_id`. Valid values are `developer`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#access_level ProjectProtectedEnvironment#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of the group allowed to deploy to this protected environment. The project must be shared with the group. Mutually exclusive with `access_level` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_id ProjectProtectedEnvironment#group_id}
    */
    readonly groupId?: number;
    /**
    * Group inheritance allows deploy access levels to take inherited group membership into account. Valid values are `0`, `1`. `0` => Direct group membership only, `1` => All inherited groups. Default: `0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_inheritance_type ProjectProtectedEnvironment#group_inheritance_type}
    */
    readonly groupInheritanceType?: number;
    /**
    * The ID of the user allowed to deploy to this protected environment. The user must be a member of the project. Mutually exclusive with `access_level` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#user_id ProjectProtectedEnvironment#user_id}
    */
    readonly userId?: number;
}
export declare function projectProtectedEnvironmentDeployAccessLevelsAttributeToTerraform(struct?: ProjectProtectedEnvironmentDeployAccessLevelsAttribute | cdktf.IResolvable): any;
export declare function projectProtectedEnvironmentDeployAccessLevelsAttributeToHclTerraform(struct?: ProjectProtectedEnvironmentDeployAccessLevelsAttribute | cdktf.IResolvable): any;
export declare class ProjectProtectedEnvironmentDeployAccessLevelsAttributeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectProtectedEnvironmentDeployAccessLevelsAttribute | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectProtectedEnvironmentDeployAccessLevelsAttribute | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _groupInheritanceType?;
    get groupInheritanceType(): number;
    set groupInheritanceType(value: number);
    resetGroupInheritanceType(): void;
    get groupInheritanceTypeInput(): number | undefined;
    get id(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class ProjectProtectedEnvironmentDeployAccessLevelsAttributeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ProjectProtectedEnvironmentDeployAccessLevelsAttribute[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectProtectedEnvironmentDeployAccessLevelsAttributeOutputReference;
}
export interface ProjectProtectedEnvironmentDeployAccessLevels {
    /**
    * Levels of access required to deploy to this protected environment. Mutually exclusive with `user_id` and `group_id`. Valid values are `developer`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#access_level ProjectProtectedEnvironment#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of the group allowed to deploy to this protected environment. The project must be shared with the group. Mutually exclusive with `access_level` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_id ProjectProtectedEnvironment#group_id}
    */
    readonly groupId?: number;
    /**
    * Group inheritance allows deploy access levels to take inherited group membership into account. Valid values are `0`, `1`. `0` => Direct group membership only, `1` => All inherited groups. Default: `0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#group_inheritance_type ProjectProtectedEnvironment#group_inheritance_type}
    */
    readonly groupInheritanceType?: number;
    /**
    * The ID of the user allowed to deploy to this protected environment. The user must be a member of the project. Mutually exclusive with `access_level` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#user_id ProjectProtectedEnvironment#user_id}
    */
    readonly userId?: number;
}
export declare function projectProtectedEnvironmentDeployAccessLevelsToTerraform(struct?: ProjectProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable): any;
export declare function projectProtectedEnvironmentDeployAccessLevelsToHclTerraform(struct?: ProjectProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable): any;
export declare class ProjectProtectedEnvironmentDeployAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: ProjectProtectedEnvironmentDeployAccessLevels | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _groupInheritanceType?;
    get groupInheritanceType(): number;
    set groupInheritanceType(value: number);
    resetGroupInheritanceType(): void;
    get groupInheritanceTypeInput(): number | undefined;
    get id(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class ProjectProtectedEnvironmentDeployAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ProjectProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectProtectedEnvironmentDeployAccessLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment gitlab_project_protected_environment}
*/
export declare class ProjectProtectedEnvironment extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_protected_environment";
    /**
    * Generates CDKTF code for importing a ProjectProtectedEnvironment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectProtectedEnvironment to import
    * @param importFromId The id of the existing ProjectProtectedEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectProtectedEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_protected_environment gitlab_project_protected_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectProtectedEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: ProjectProtectedEnvironmentConfig);
    private _approvalRules;
    get approvalRules(): ProjectProtectedEnvironmentApprovalRulesList;
    putApprovalRules(value: ProjectProtectedEnvironmentApprovalRules[] | cdktf.IResolvable): void;
    resetApprovalRules(): void;
    get approvalRulesInput(): cdktf.IResolvable | ProjectProtectedEnvironmentApprovalRules[] | undefined;
    private _deployAccessLevelsAttribute;
    get deployAccessLevelsAttribute(): ProjectProtectedEnvironmentDeployAccessLevelsAttributeList;
    putDeployAccessLevelsAttribute(value: ProjectProtectedEnvironmentDeployAccessLevelsAttribute[] | cdktf.IResolvable): void;
    resetDeployAccessLevelsAttribute(): void;
    get deployAccessLevelsAttributeInput(): cdktf.IResolvable | ProjectProtectedEnvironmentDeployAccessLevelsAttribute[] | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _deployAccessLevels;
    get deployAccessLevels(): ProjectProtectedEnvironmentDeployAccessLevelsList;
    putDeployAccessLevels(value: ProjectProtectedEnvironmentDeployAccessLevels[] | cdktf.IResolvable): void;
    resetDeployAccessLevels(): void;
    get deployAccessLevelsInput(): cdktf.IResolvable | ProjectProtectedEnvironmentDeployAccessLevels[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
