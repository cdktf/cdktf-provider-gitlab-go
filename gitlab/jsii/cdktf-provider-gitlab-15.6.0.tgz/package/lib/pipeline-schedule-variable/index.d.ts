/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PipelineScheduleVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#id PipelineScheduleVariable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#key PipelineScheduleVariable#key}
    */
    readonly key: string;
    /**
    * The id of the pipeline schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#pipeline_schedule_id PipelineScheduleVariable#pipeline_schedule_id}
    */
    readonly pipelineScheduleId: number;
    /**
    * The id of the project to add the schedule to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#project PipelineScheduleVariable#project}
    */
    readonly project: string;
    /**
    * Value of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#value PipelineScheduleVariable#value}
    */
    readonly value: string;
    /**
    * The type of a variable. Available types are: `env_var`, `file`. Default is `env_var`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#variable_type PipelineScheduleVariable#variable_type}
    */
    readonly variableType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable gitlab_pipeline_schedule_variable}
*/
export declare class PipelineScheduleVariable extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_pipeline_schedule_variable";
    /**
    * Generates CDKTF code for importing a PipelineScheduleVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PipelineScheduleVariable to import
    * @param importFromId The id of the existing PipelineScheduleVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PipelineScheduleVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule_variable gitlab_pipeline_schedule_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PipelineScheduleVariableConfig
    */
    constructor(scope: Construct, id: string, config: PipelineScheduleVariableConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _pipelineScheduleId?;
    get pipelineScheduleId(): number;
    set pipelineScheduleId(value: number);
    get pipelineScheduleIdInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    resetVariableType(): void;
    get variableTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
