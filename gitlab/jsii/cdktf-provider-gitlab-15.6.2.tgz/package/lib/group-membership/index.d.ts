/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupMembershipConfig extends cdktf.TerraformMetaArguments {
    /**
    * Access level for the member. Valid values are: `no one`, `minimal`, `guest`, `planner`, `reporter`, `developer`, `maintainer`, `owner`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#access_level GroupMembership#access_level}
    */
    readonly accessLevel: string;
    /**
    * Expiration date for the group membership. Format: `YYYY-MM-DD`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#expires_at GroupMembership#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#group_id GroupMembership#group_id}
    */
    readonly groupId: number;
    /**
    * The ID of a custom member role. Not including the member role ID will cause the role to update the membership to the base role if the custom role is current set. Only available for Ultimate instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#member_role_id GroupMembership#member_role_id}
    */
    readonly memberRoleId?: number;
    /**
    * Whether the deletion of direct memberships of the removed member in subgroups and projects should be skipped. Only used during a destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#skip_subresources_on_destroy GroupMembership#skip_subresources_on_destroy}
    */
    readonly skipSubresourcesOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * Whether the removed member should be unassigned from any issues or merge requests inside a given group or project. Only used during a destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#unassign_issuables_on_destroy GroupMembership#unassign_issuables_on_destroy}
    */
    readonly unassignIssuablesOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * The ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#user_id GroupMembership#user_id}
    */
    readonly userId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership gitlab_group_membership}
*/
export declare class GroupMembership extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_membership";
    /**
    * Generates CDKTF code for importing a GroupMembership resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupMembership to import
    * @param importFromId The id of the existing GroupMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_membership gitlab_group_membership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupMembershipConfig
    */
    constructor(scope: Construct, id: string, config: GroupMembershipConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    get accessLevelInput(): string | undefined;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    get id(): string;
    private _memberRoleId?;
    get memberRoleId(): number;
    set memberRoleId(value: number);
    resetMemberRoleId(): void;
    get memberRoleIdInput(): number | undefined;
    private _skipSubresourcesOnDestroy?;
    get skipSubresourcesOnDestroy(): boolean | cdktf.IResolvable;
    set skipSubresourcesOnDestroy(value: boolean | cdktf.IResolvable);
    resetSkipSubresourcesOnDestroy(): void;
    get skipSubresourcesOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _unassignIssuablesOnDestroy?;
    get unassignIssuablesOnDestroy(): boolean | cdktf.IResolvable;
    set unassignIssuablesOnDestroy(value: boolean | cdktf.IResolvable);
    resetUnassignIssuablesOnDestroy(): void;
    get unassignIssuablesOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
