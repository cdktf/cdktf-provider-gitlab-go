/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectPagesSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Boolean indicating if the project is set to force https. Requires `external_https` to be configured in the GitLab instance: https://docs.gitlab.com/administration/pages/#custom-domains-with-tls-support.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings#force_https ProjectPagesSettings#force_https}
    */
    readonly forceHttps?: boolean | cdktf.IResolvable;
    /**
    * Boolean indicating if a unique domain is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings#is_unique_domain_enabled ProjectPagesSettings#is_unique_domain_enabled}
    */
    readonly isUniqueDomainEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set to true if the pages settings should not be reset to their pre-terraform defaults on destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings#keep_settings_on_destroy ProjectPagesSettings#keep_settings_on_destroy}
    */
    readonly keepSettingsOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * The project ID or path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings#project ProjectPagesSettings#project}
    */
    readonly project: string;
}
export interface ProjectPagesSettingsDeployments {
}
export declare function projectPagesSettingsDeploymentsToTerraform(struct?: ProjectPagesSettingsDeployments): any;
export declare function projectPagesSettingsDeploymentsToHclTerraform(struct?: ProjectPagesSettingsDeployments): any;
export declare class ProjectPagesSettingsDeploymentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ProjectPagesSettingsDeployments | undefined;
    set internalValue(value: ProjectPagesSettingsDeployments | undefined);
    get createdAt(): string;
    get pathPrefix(): string;
    get rootDirectory(): string;
    get url(): string;
}
export declare class ProjectPagesSettingsDeploymentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ProjectPagesSettingsDeploymentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings gitlab_project_pages_settings}
*/
export declare class ProjectPagesSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_pages_settings";
    /**
    * Generates CDKTF code for importing a ProjectPagesSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectPagesSettings to import
    * @param importFromId The id of the existing ProjectPagesSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectPagesSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_pages_settings gitlab_project_pages_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectPagesSettingsConfig
    */
    constructor(scope: Construct, id: string, config: ProjectPagesSettingsConfig);
    private _deployments;
    get deployments(): ProjectPagesSettingsDeploymentsList;
    private _forceHttps?;
    get forceHttps(): boolean | cdktf.IResolvable;
    set forceHttps(value: boolean | cdktf.IResolvable);
    resetForceHttps(): void;
    get forceHttpsInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _isUniqueDomainEnabled?;
    get isUniqueDomainEnabled(): boolean | cdktf.IResolvable;
    set isUniqueDomainEnabled(value: boolean | cdktf.IResolvable);
    resetIsUniqueDomainEnabled(): void;
    get isUniqueDomainEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _keepSettingsOnDestroy?;
    get keepSettingsOnDestroy(): boolean | cdktf.IResolvable;
    set keepSettingsOnDestroy(value: boolean | cdktf.IResolvable);
    resetKeepSettingsOnDestroy(): void;
    get keepSettingsOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
