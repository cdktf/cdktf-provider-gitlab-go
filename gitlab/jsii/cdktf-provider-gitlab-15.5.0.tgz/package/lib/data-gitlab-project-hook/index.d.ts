/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectHookConfig extends cdktf.TerraformMetaArguments {
    /**
    * The id of the project hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_hook#hook_id DataGitlabProjectHook#hook_id}
    */
    readonly hookId: number;
    /**
    * The name or id of the project to add the hook to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_hook#project DataGitlabProjectHook#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_hook gitlab_project_hook}
*/
export declare class DataGitlabProjectHook extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_hook";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectHook resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectHook to import
    * @param importFromId The id of the existing DataGitlabProjectHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_hook gitlab_project_hook} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectHookConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectHookConfig);
    get confidentialIssuesEvents(): cdktf.IResolvable;
    get confidentialNoteEvents(): cdktf.IResolvable;
    get customWebhookTemplate(): string;
    get deploymentEvents(): cdktf.IResolvable;
    get enableSslVerification(): cdktf.IResolvable;
    private _hookId?;
    get hookId(): number;
    set hookId(value: number);
    get hookIdInput(): number | undefined;
    get id(): string;
    get issuesEvents(): cdktf.IResolvable;
    get jobEvents(): cdktf.IResolvable;
    get mergeRequestsEvents(): cdktf.IResolvable;
    get noteEvents(): cdktf.IResolvable;
    get pipelineEvents(): cdktf.IResolvable;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectId(): number;
    get pushEvents(): cdktf.IResolvable;
    get pushEventsBranchFilter(): string;
    get releasesEvents(): cdktf.IResolvable;
    get tagPushEvents(): cdktf.IResolvable;
    get token(): string;
    get url(): string;
    get wikiPageEvents(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
