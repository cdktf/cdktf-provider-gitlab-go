/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupBillableMemberMembershipsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_billable_member_memberships#group_id DataGitlabGroupBillableMemberMemberships#group_id}
    */
    readonly groupId: string;
    /**
    * The ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_billable_member_memberships#user_id DataGitlabGroupBillableMemberMemberships#user_id}
    */
    readonly userId: number;
}
export interface DataGitlabGroupBillableMemberMembershipsMemberships {
}
export declare function dataGitlabGroupBillableMemberMembershipsMembershipsToTerraform(struct?: DataGitlabGroupBillableMemberMembershipsMemberships): any;
export declare function dataGitlabGroupBillableMemberMembershipsMembershipsToHclTerraform(struct?: DataGitlabGroupBillableMemberMembershipsMemberships): any;
export declare class DataGitlabGroupBillableMemberMembershipsMembershipsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabGroupBillableMemberMembershipsMemberships | undefined;
    set internalValue(value: DataGitlabGroupBillableMemberMembershipsMemberships | undefined);
    get accessLevel(): string;
    get createdAt(): string;
    get expiresAt(): string;
    get id(): number;
    get sourceFullName(): string;
    get sourceId(): number;
    get sourceMembersUrl(): string;
}
export declare class DataGitlabGroupBillableMemberMembershipsMembershipsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabGroupBillableMemberMembershipsMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_billable_member_memberships gitlab_group_billable_member_memberships}
*/
export declare class DataGitlabGroupBillableMemberMemberships extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_billable_member_memberships";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupBillableMemberMemberships resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupBillableMemberMemberships to import
    * @param importFromId The id of the existing DataGitlabGroupBillableMemberMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_billable_member_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupBillableMemberMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_billable_member_memberships gitlab_group_billable_member_memberships} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupBillableMemberMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupBillableMemberMembershipsConfig);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get id(): string;
    private _memberships;
    get memberships(): DataGitlabGroupBillableMemberMembershipsMembershipsList;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
