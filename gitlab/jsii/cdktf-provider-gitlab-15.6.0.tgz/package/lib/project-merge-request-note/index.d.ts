/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectMergeRequestNoteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The body of the merge request note.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#body ProjectMergeRequestNote#body}
    */
    readonly body: string;
    /**
    * The creation date of the merge request note. Using this field requires the token used with the provider to either be an Admin, or hava a Project or Group Owner role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#created_at ProjectMergeRequestNote#created_at}
    */
    readonly createdAt?: string;
    /**
    * Indicates if the merge request note is internal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#internal ProjectMergeRequestNote#internal}
    */
    readonly internal?: boolean | cdktf.IResolvable;
    /**
    * The diff head SHA of the merge request when the note was created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#merge_request_diff_head_sha ProjectMergeRequestNote#merge_request_diff_head_sha}
    */
    readonly mergeRequestDiffHeadSha?: string;
    /**
    * The IID of the merge request to add the note to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#merge_request_iid ProjectMergeRequestNote#merge_request_iid}
    */
    readonly mergeRequestIid: number;
    /**
    * The ID or path of the project to add the note to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#project ProjectMergeRequestNote#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note gitlab_project_merge_request_note}
*/
export declare class ProjectMergeRequestNote extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_merge_request_note";
    /**
    * Generates CDKTF code for importing a ProjectMergeRequestNote resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectMergeRequestNote to import
    * @param importFromId The id of the existing ProjectMergeRequestNote that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectMergeRequestNote to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_merge_request_note gitlab_project_merge_request_note} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectMergeRequestNoteConfig
    */
    constructor(scope: Construct, id: string, config: ProjectMergeRequestNoteConfig);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    get id(): string;
    private _internal?;
    get internal(): boolean | cdktf.IResolvable;
    set internal(value: boolean | cdktf.IResolvable);
    resetInternal(): void;
    get internalInput(): boolean | cdktf.IResolvable | undefined;
    private _mergeRequestDiffHeadSha?;
    get mergeRequestDiffHeadSha(): string;
    set mergeRequestDiffHeadSha(value: string);
    resetMergeRequestDiffHeadSha(): void;
    get mergeRequestDiffHeadShaInput(): string | undefined;
    private _mergeRequestIid?;
    get mergeRequestIid(): number;
    set mergeRequestIid(value: number);
    get mergeRequestIidInput(): number | undefined;
    get noteId(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get resolvable(): cdktf.IResolvable;
    get systemAttribute(): cdktf.IResolvable;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
