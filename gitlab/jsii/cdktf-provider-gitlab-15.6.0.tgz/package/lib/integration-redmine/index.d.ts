/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationRedmineConfig extends cdktf.TerraformMetaArguments {
    /**
    * The URL to the Redmine project issue to link to this GitLab project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#issues_url IntegrationRedmine#issues_url}
    */
    readonly issuesUrl: string;
    /**
    * The URL to use to create a new issue in the Redmine project linked to this GitLab project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#new_issue_url IntegrationRedmine#new_issue_url}
    */
    readonly newIssueUrl: string;
    /**
    * ID of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#project IntegrationRedmine#project}
    */
    readonly project: string;
    /**
    * The URL to the Redmine project to link to this GitLab project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#project_url IntegrationRedmine#project_url}
    */
    readonly projectUrl: string;
    /**
    * Indicates whether or not to inherit default settings. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#use_inherited_settings IntegrationRedmine#use_inherited_settings}
    */
    readonly useInheritedSettings?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine gitlab_integration_redmine}
*/
export declare class IntegrationRedmine extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_integration_redmine";
    /**
    * Generates CDKTF code for importing a IntegrationRedmine resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationRedmine to import
    * @param importFromId The id of the existing IntegrationRedmine that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationRedmine to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_redmine gitlab_integration_redmine} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationRedmineConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationRedmineConfig);
    get id(): string;
    private _issuesUrl?;
    get issuesUrl(): string;
    set issuesUrl(value: string);
    get issuesUrlInput(): string | undefined;
    private _newIssueUrl?;
    get newIssueUrl(): string;
    set newIssueUrl(value: string);
    get newIssueUrlInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectUrl?;
    get projectUrl(): string;
    set projectUrl(value: string);
    get projectUrlInput(): string | undefined;
    private _useInheritedSettings?;
    get useInheritedSettings(): boolean | cdktf.IResolvable;
    set useInheritedSettings(value: boolean | cdktf.IResolvable);
    resetUseInheritedSettings(): void;
    get useInheritedSettingsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
