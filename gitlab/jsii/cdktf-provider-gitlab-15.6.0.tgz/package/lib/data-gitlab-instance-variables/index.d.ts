/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabInstanceVariablesConfig extends cdktf.TerraformMetaArguments {
}
export interface DataGitlabInstanceVariablesVariables {
}
export declare function dataGitlabInstanceVariablesVariablesToTerraform(struct?: DataGitlabInstanceVariablesVariables): any;
export declare function dataGitlabInstanceVariablesVariablesToHclTerraform(struct?: DataGitlabInstanceVariablesVariables): any;
export declare class DataGitlabInstanceVariablesVariablesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabInstanceVariablesVariables | undefined;
    set internalValue(value: DataGitlabInstanceVariablesVariables | undefined);
    get description(): string;
    get key(): string;
    get masked(): cdktf.IResolvable;
    get protected(): cdktf.IResolvable;
    get raw(): cdktf.IResolvable;
    get value(): string;
    get variableType(): string;
}
export declare class DataGitlabInstanceVariablesVariablesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabInstanceVariablesVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variables gitlab_instance_variables}
*/
export declare class DataGitlabInstanceVariables extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_instance_variables";
    /**
    * Generates CDKTF code for importing a DataGitlabInstanceVariables resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabInstanceVariables to import
    * @param importFromId The id of the existing DataGitlabInstanceVariables that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabInstanceVariables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variables gitlab_instance_variables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabInstanceVariablesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabInstanceVariablesConfig);
    get id(): string;
    private _variables;
    get variables(): DataGitlabInstanceVariablesVariablesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
