/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationGithubConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#id IntegrationGithub#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the project you want to activate the integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#project IntegrationGithub#project}
    */
    readonly project: string;
    /**
    * The URL of the GitHub repo to integrate with. For example, https://github.com/gitlabhq/terraform-provider-gitlab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#repository_url IntegrationGithub#repository_url}
    */
    readonly repositoryUrl: string;
    /**
    * Append the instance name instead of the branch to the status. Must enable to set a GitLab status check as _required_ in GitHub. See [Static / dynamic status check names] to learn more.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#static_context IntegrationGithub#static_context}
    */
    readonly staticContext?: boolean | cdktf.IResolvable;
    /**
    * A GitHub personal access token with at least the `repo:status` scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#token IntegrationGithub#token}
    */
    readonly token: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github gitlab_integration_github}
*/
export declare class IntegrationGithub extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_integration_github";
    /**
    * Generates CDKTF code for importing a IntegrationGithub resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationGithub to import
    * @param importFromId The id of the existing IntegrationGithub that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationGithub to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_github gitlab_integration_github} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationGithubConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationGithubConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _repositoryUrl?;
    get repositoryUrl(): string;
    set repositoryUrl(value: string);
    get repositoryUrlInput(): string | undefined;
    private _staticContext?;
    get staticContext(): boolean | cdktf.IResolvable;
    set staticContext(value: boolean | cdktf.IResolvable);
    resetStaticContext(): void;
    get staticContextInput(): boolean | cdktf.IResolvable | undefined;
    get title(): string;
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
