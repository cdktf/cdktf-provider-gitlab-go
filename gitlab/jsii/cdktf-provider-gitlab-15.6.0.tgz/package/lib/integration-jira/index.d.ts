/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationJiraConfig extends cdktf.TerraformMetaArguments {
    /**
    * The base URL to the Jira instance API. Web URL value is used if not set. For example, https://jira-api.example.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#api_url IntegrationJira#api_url}
    */
    readonly apiUrl?: string;
    /**
    * Enable comments inside Jira issues on each GitLab event (commit / merge request)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#comment_on_event_enabled IntegrationJira#comment_on_event_enabled}
    */
    readonly commentOnEventEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable notifications for commit events
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#commit_events IntegrationJira#commit_events}
    */
    readonly commitEvents?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#id IntegrationJira#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Enable viewing Jira issues in GitLab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#issues_enabled IntegrationJira#issues_enabled}
    */
    readonly issuesEnabled?: boolean | cdktf.IResolvable;
    /**
    * The authentication method to be used with Jira. 0 means Basic Authentication. 1 means Jira personal access token. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#jira_auth_type IntegrationJira#jira_auth_type}
    */
    readonly jiraAuthType?: number;
    /**
    * Prefix to match Jira issue keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#jira_issue_prefix IntegrationJira#jira_issue_prefix}
    */
    readonly jiraIssuePrefix?: string;
    /**
    * Regular expression to match Jira issue keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#jira_issue_regex IntegrationJira#jira_issue_regex}
    */
    readonly jiraIssueRegex?: string;
    /**
    * Enable automatic issue transitions. Takes precedence over jira_issue_transition_id if enabled. Defaults to false. This value cannot be imported, and will not perform drift detection if changed outside Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#jira_issue_transition_automatic IntegrationJira#jira_issue_transition_automatic}
    */
    readonly jiraIssueTransitionAutomatic?: boolean | cdktf.IResolvable;
    /**
    * The ID of a transition that moves issues to a closed state. You can find this number under the JIRA workflow administration (Administration > Issues > Workflows) by selecting View under Operations of the desired workflow of your project. By default, this ID is set to 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#jira_issue_transition_id IntegrationJira#jira_issue_transition_id}
    */
    readonly jiraIssueTransitionId?: string;
    /**
    * Enable notifications for merge request events
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#merge_requests_events IntegrationJira#merge_requests_events}
    */
    readonly mergeRequestsEvents?: boolean | cdktf.IResolvable;
    /**
    * The Jira API token, password, or personal access token to be used with Jira. When your authentication method is basic (jira_auth_type is 0), use an API token for Jira Cloud or a password for Jira Data Center or Jira Server. When your authentication method is a Jira personal access token (jira_auth_type is 1), use the personal access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#password IntegrationJira#password}
    */
    readonly password: string;
    /**
    * ID of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#project IntegrationJira#project}
    */
    readonly project: string;
    /**
    * Keys of Jira projects. When issues_enabled is true, this setting specifies which Jira projects to view issues from in GitLab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#project_keys IntegrationJira#project_keys}
    */
    readonly projectKeys?: string[];
    /**
    * The URL to the JIRA project which is being linked to this GitLab project. For example, https://jira.example.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#url IntegrationJira#url}
    */
    readonly url: string;
    /**
    * Indicates whether or not to inherit default settings. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#use_inherited_settings IntegrationJira#use_inherited_settings}
    */
    readonly useInheritedSettings?: boolean | cdktf.IResolvable;
    /**
    * The email or username to be used with Jira. For Jira Cloud use an email, for Jira Data Center and Jira Server use a username. Required when using Basic authentication (jira_auth_type is 0).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#username IntegrationJira#username}
    */
    readonly username?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira gitlab_integration_jira}
*/
export declare class IntegrationJira extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_integration_jira";
    /**
    * Generates CDKTF code for importing a IntegrationJira resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationJira to import
    * @param importFromId The id of the existing IntegrationJira that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationJira to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/integration_jira gitlab_integration_jira} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationJiraConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationJiraConfig);
    get active(): cdktf.IResolvable;
    private _apiUrl?;
    get apiUrl(): string;
    set apiUrl(value: string);
    resetApiUrl(): void;
    get apiUrlInput(): string | undefined;
    private _commentOnEventEnabled?;
    get commentOnEventEnabled(): boolean | cdktf.IResolvable;
    set commentOnEventEnabled(value: boolean | cdktf.IResolvable);
    resetCommentOnEventEnabled(): void;
    get commentOnEventEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _commitEvents?;
    get commitEvents(): boolean | cdktf.IResolvable;
    set commitEvents(value: boolean | cdktf.IResolvable);
    resetCommitEvents(): void;
    get commitEventsInput(): boolean | cdktf.IResolvable | undefined;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuesEnabled?;
    get issuesEnabled(): boolean | cdktf.IResolvable;
    set issuesEnabled(value: boolean | cdktf.IResolvable);
    resetIssuesEnabled(): void;
    get issuesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _jiraAuthType?;
    get jiraAuthType(): number;
    set jiraAuthType(value: number);
    resetJiraAuthType(): void;
    get jiraAuthTypeInput(): number | undefined;
    private _jiraIssuePrefix?;
    get jiraIssuePrefix(): string;
    set jiraIssuePrefix(value: string);
    resetJiraIssuePrefix(): void;
    get jiraIssuePrefixInput(): string | undefined;
    private _jiraIssueRegex?;
    get jiraIssueRegex(): string;
    set jiraIssueRegex(value: string);
    resetJiraIssueRegex(): void;
    get jiraIssueRegexInput(): string | undefined;
    private _jiraIssueTransitionAutomatic?;
    get jiraIssueTransitionAutomatic(): boolean | cdktf.IResolvable;
    set jiraIssueTransitionAutomatic(value: boolean | cdktf.IResolvable);
    resetJiraIssueTransitionAutomatic(): void;
    get jiraIssueTransitionAutomaticInput(): boolean | cdktf.IResolvable | undefined;
    private _jiraIssueTransitionId?;
    get jiraIssueTransitionId(): string;
    set jiraIssueTransitionId(value: string);
    resetJiraIssueTransitionId(): void;
    get jiraIssueTransitionIdInput(): string | undefined;
    private _mergeRequestsEvents?;
    get mergeRequestsEvents(): boolean | cdktf.IResolvable;
    set mergeRequestsEvents(value: boolean | cdktf.IResolvable);
    resetMergeRequestsEvents(): void;
    get mergeRequestsEventsInput(): boolean | cdktf.IResolvable | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectKeys?;
    get projectKeys(): string[];
    set projectKeys(value: string[]);
    resetProjectKeys(): void;
    get projectKeysInput(): string[] | undefined;
    get title(): string;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _useInheritedSettings?;
    get useInheritedSettings(): boolean | cdktf.IResolvable;
    set useInheritedSettings(value: boolean | cdktf.IResolvable);
    resetUseInheritedSettings(): void;
    get useInheritedSettingsInput(): boolean | cdktf.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
