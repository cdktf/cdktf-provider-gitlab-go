/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectPushRulesAConfig extends cdktf.TerraformMetaArguments {
    /**
    * All commit author emails must match this regex, e.g. `@my-company.com$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#author_email_regex ProjectPushRulesA#author_email_regex}
    */
    readonly authorEmailRegex?: string;
    /**
    * All branch names must match this regex, e.g. `(feature|hotfix)\/*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#branch_name_regex ProjectPushRulesA#branch_name_regex}
    */
    readonly branchNameRegex?: string;
    /**
    * Users can only push commits to this repository that were committed with one of their own verified emails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#commit_committer_check ProjectPushRulesA#commit_committer_check}
    */
    readonly commitCommitterCheck?: boolean | cdktf.IResolvable;
    /**
    * Users can only push commits to this repository if the commit author name is consistent with their GitLab account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#commit_committer_name_check ProjectPushRulesA#commit_committer_name_check}
    */
    readonly commitCommitterNameCheck?: boolean | cdktf.IResolvable;
    /**
    * No commit message is allowed to match this regex, e.g. `ssh\:\/\/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#commit_message_negative_regex ProjectPushRulesA#commit_message_negative_regex}
    */
    readonly commitMessageNegativeRegex?: string;
    /**
    * All commit messages must match this regex, e.g. `Fixed \d+\..*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#commit_message_regex ProjectPushRulesA#commit_message_regex}
    */
    readonly commitMessageRegex?: string;
    /**
    * Deny deleting a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#deny_delete_tag ProjectPushRulesA#deny_delete_tag}
    */
    readonly denyDeleteTag?: boolean | cdktf.IResolvable;
    /**
    * All committed filenames must not match this regex, e.g. `(jar|exe)$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#file_name_regex ProjectPushRulesA#file_name_regex}
    */
    readonly fileNameRegex?: string;
    /**
    * Maximum file size (MB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#max_file_size ProjectPushRulesA#max_file_size}
    */
    readonly maxFileSize?: number;
    /**
    * Restrict commits by author (email) to existing GitLab users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#member_check ProjectPushRulesA#member_check}
    */
    readonly memberCheck?: boolean | cdktf.IResolvable;
    /**
    * GitLab will reject any files that are likely to contain secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#prevent_secrets ProjectPushRulesA#prevent_secrets}
    */
    readonly preventSecrets?: boolean | cdktf.IResolvable;
    /**
    * The ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#project ProjectPushRulesA#project}
    */
    readonly project: string;
    /**
    * Reject commit when it’s not DCO certified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#reject_non_dco_commits ProjectPushRulesA#reject_non_dco_commits}
    */
    readonly rejectNonDcoCommits?: boolean | cdktf.IResolvable;
    /**
    * Reject commit when it’s not signed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#reject_unsigned_commits ProjectPushRulesA#reject_unsigned_commits}
    */
    readonly rejectUnsignedCommits?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules gitlab_project_push_rules}
*/
export declare class ProjectPushRulesA extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_push_rules";
    /**
    * Generates CDKTF code for importing a ProjectPushRulesA resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectPushRulesA to import
    * @param importFromId The id of the existing ProjectPushRulesA that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectPushRulesA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_push_rules gitlab_project_push_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectPushRulesAConfig
    */
    constructor(scope: Construct, id: string, config: ProjectPushRulesAConfig);
    private _authorEmailRegex?;
    get authorEmailRegex(): string;
    set authorEmailRegex(value: string);
    resetAuthorEmailRegex(): void;
    get authorEmailRegexInput(): string | undefined;
    private _branchNameRegex?;
    get branchNameRegex(): string;
    set branchNameRegex(value: string);
    resetBranchNameRegex(): void;
    get branchNameRegexInput(): string | undefined;
    private _commitCommitterCheck?;
    get commitCommitterCheck(): boolean | cdktf.IResolvable;
    set commitCommitterCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterCheck(): void;
    get commitCommitterCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitCommitterNameCheck?;
    get commitCommitterNameCheck(): boolean | cdktf.IResolvable;
    set commitCommitterNameCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterNameCheck(): void;
    get commitCommitterNameCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitMessageNegativeRegex?;
    get commitMessageNegativeRegex(): string;
    set commitMessageNegativeRegex(value: string);
    resetCommitMessageNegativeRegex(): void;
    get commitMessageNegativeRegexInput(): string | undefined;
    private _commitMessageRegex?;
    get commitMessageRegex(): string;
    set commitMessageRegex(value: string);
    resetCommitMessageRegex(): void;
    get commitMessageRegexInput(): string | undefined;
    private _denyDeleteTag?;
    get denyDeleteTag(): boolean | cdktf.IResolvable;
    set denyDeleteTag(value: boolean | cdktf.IResolvable);
    resetDenyDeleteTag(): void;
    get denyDeleteTagInput(): boolean | cdktf.IResolvable | undefined;
    private _fileNameRegex?;
    get fileNameRegex(): string;
    set fileNameRegex(value: string);
    resetFileNameRegex(): void;
    get fileNameRegexInput(): string | undefined;
    get id(): string;
    private _maxFileSize?;
    get maxFileSize(): number;
    set maxFileSize(value: number);
    resetMaxFileSize(): void;
    get maxFileSizeInput(): number | undefined;
    private _memberCheck?;
    get memberCheck(): boolean | cdktf.IResolvable;
    set memberCheck(value: boolean | cdktf.IResolvable);
    resetMemberCheck(): void;
    get memberCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _preventSecrets?;
    get preventSecrets(): boolean | cdktf.IResolvable;
    set preventSecrets(value: boolean | cdktf.IResolvable);
    resetPreventSecrets(): void;
    get preventSecretsInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _rejectNonDcoCommits?;
    get rejectNonDcoCommits(): boolean | cdktf.IResolvable;
    set rejectNonDcoCommits(value: boolean | cdktf.IResolvable);
    resetRejectNonDcoCommits(): void;
    get rejectNonDcoCommitsInput(): boolean | cdktf.IResolvable | undefined;
    private _rejectUnsignedCommits?;
    get rejectUnsignedCommits(): boolean | cdktf.IResolvable;
    set rejectUnsignedCommits(value: boolean | cdktf.IResolvable);
    resetRejectUnsignedCommits(): void;
    get rejectUnsignedCommitsInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
