/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupBadgeConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or URL-encoded path of the group to add the badge to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge#group GroupBadge#group}
    */
    readonly group: string;
    /**
    * The image url which will be presented on group overview.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge#image_url GroupBadge#image_url}
    */
    readonly imageUrl: string;
    /**
    * The url linked with the badge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge#link_url GroupBadge#link_url}
    */
    readonly linkUrl: string;
    /**
    * The name of the badge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge#name GroupBadge#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge gitlab_group_badge}
*/
export declare class GroupBadge extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_badge";
    /**
    * Generates CDKTF code for importing a GroupBadge resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupBadge to import
    * @param importFromId The id of the existing GroupBadge that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupBadge to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_badge gitlab_group_badge} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupBadgeConfig
    */
    constructor(scope: Construct, id: string, config: GroupBadgeConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get id(): string;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    get imageUrlInput(): string | undefined;
    private _linkUrl?;
    get linkUrl(): string;
    set linkUrl(value: string);
    get linkUrlInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get renderedImageUrl(): string;
    get renderedLinkUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
