/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PipelineScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The activation of pipeline schedule. If false is set, the pipeline schedule will deactivated initially.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#active PipelineSchedule#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * The cron (e.g. `0 1 * * *`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#cron PipelineSchedule#cron}
    */
    readonly cron: string;
    /**
    * The timezone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#cron_timezone PipelineSchedule#cron_timezone}
    */
    readonly cronTimezone?: string;
    /**
    * The description of the pipeline schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#description PipelineSchedule#description}
    */
    readonly description: string;
    /**
    * The name or id of the project to add the schedule to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#project PipelineSchedule#project}
    */
    readonly project: string;
    /**
    * The branch/tag name to be triggered. This must be the full branch reference, for example: `refs/heads/main`, not `main`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#ref PipelineSchedule#ref}
    */
    readonly ref: string;
    /**
    * When set to `true`, the user represented by the token running Terraform will take ownership of the scheduled pipeline prior to editing it. This can help when managing scheduled pipeline drift when other users are making changes outside Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#take_ownership PipelineSchedule#take_ownership}
    */
    readonly takeOwnership?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule gitlab_pipeline_schedule}
*/
export declare class PipelineSchedule extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_pipeline_schedule";
    /**
    * Generates CDKTF code for importing a PipelineSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PipelineSchedule to import
    * @param importFromId The id of the existing PipelineSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PipelineSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/pipeline_schedule gitlab_pipeline_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PipelineScheduleConfig
    */
    constructor(scope: Construct, id: string, config: PipelineScheduleConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _cron?;
    get cron(): string;
    set cron(value: string);
    get cronInput(): string | undefined;
    private _cronTimezone?;
    get cronTimezone(): string;
    set cronTimezone(value: string);
    resetCronTimezone(): void;
    get cronTimezoneInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    get owner(): number;
    get pipelineScheduleId(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    get refInput(): string | undefined;
    private _takeOwnership?;
    get takeOwnership(): boolean | cdktf.IResolvable;
    set takeOwnership(value: boolean | cdktf.IResolvable);
    resetTakeOwnership(): void;
    get takeOwnershipInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
