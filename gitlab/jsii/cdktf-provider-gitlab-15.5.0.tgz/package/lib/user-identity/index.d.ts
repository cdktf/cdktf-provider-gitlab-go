/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserIdentityConfig extends cdktf.TerraformMetaArguments {
    /**
    * The external provider name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity#external_provider UserIdentity#external_provider}
    */
    readonly externalProvider: string;
    /**
    * A specific external authentication provider UID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity#external_uid UserIdentity#external_uid}
    */
    readonly externalUid: string;
    /**
    * The GitLab ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity#user_id UserIdentity#user_id}
    */
    readonly userId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity gitlab_user_identity}
*/
export declare class UserIdentity extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_user_identity";
    /**
    * Generates CDKTF code for importing a UserIdentity resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserIdentity to import
    * @param importFromId The id of the existing UserIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/user_identity gitlab_user_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserIdentityConfig
    */
    constructor(scope: Construct, id: string, config: UserIdentityConfig);
    private _externalProvider?;
    get externalProvider(): string;
    set externalProvider(value: string);
    get externalProviderInput(): string | undefined;
    private _externalUid?;
    get externalUid(): string;
    set externalUid(value: string);
    get externalUidInput(): string | undefined;
    get id(): string;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
