/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectComplianceFrameworksConfig extends cdktf.TerraformMetaArguments {
    /**
    * Globally unique IDs of the compliance frameworks to assign to the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_compliance_frameworks#compliance_framework_ids ProjectComplianceFrameworks#compliance_framework_ids}
    */
    readonly complianceFrameworkIds: string[];
    /**
    * The ID or full path of the project to change the compliance frameworks of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_compliance_frameworks#project ProjectComplianceFrameworks#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_compliance_frameworks gitlab_project_compliance_frameworks}
*/
export declare class ProjectComplianceFrameworks extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_compliance_frameworks";
    /**
    * Generates CDKTF code for importing a ProjectComplianceFrameworks resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectComplianceFrameworks to import
    * @param importFromId The id of the existing ProjectComplianceFrameworks that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_compliance_frameworks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectComplianceFrameworks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_compliance_frameworks gitlab_project_compliance_frameworks} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectComplianceFrameworksConfig
    */
    constructor(scope: Construct, id: string, config: ProjectComplianceFrameworksConfig);
    private _complianceFrameworkIds?;
    get complianceFrameworkIds(): string[];
    set complianceFrameworkIds(value: string[]);
    get complianceFrameworkIdsInput(): string[] | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
