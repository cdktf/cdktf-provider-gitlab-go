/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectIntegrationHarborConfig extends cdktf.TerraformMetaArguments {
    /**
    * Password for authentication with the Harbor server, if authentication is required by the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#password ProjectIntegrationHarbor#password}
    */
    readonly password: string;
    /**
    * ID of the GitLab project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#project ProjectIntegrationHarbor#project}
    */
    readonly project: string;
    /**
    * The URL-friendly Harbor project name. This project needs to already exist in Harbor. Example: `my_project_name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#project_name ProjectIntegrationHarbor#project_name}
    */
    readonly projectName: string;
    /**
    * Harbor URL. Example: `http://harbor.example.com`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#url ProjectIntegrationHarbor#url}
    */
    readonly url: string;
    /**
    * Indicates whether or not to inherit default settings. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#use_inherited_settings ProjectIntegrationHarbor#use_inherited_settings}
    */
    readonly useInheritedSettings?: boolean | cdktf.IResolvable;
    /**
    * Username for authentication with the Harbor server, if authentication is required by the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#username ProjectIntegrationHarbor#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor gitlab_project_integration_harbor}
*/
export declare class ProjectIntegrationHarbor extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_integration_harbor";
    /**
    * Generates CDKTF code for importing a ProjectIntegrationHarbor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectIntegrationHarbor to import
    * @param importFromId The id of the existing ProjectIntegrationHarbor that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectIntegrationHarbor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_harbor gitlab_project_integration_harbor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectIntegrationHarborConfig
    */
    constructor(scope: Construct, id: string, config: ProjectIntegrationHarborConfig);
    get active(): cdktf.IResolvable;
    get id(): string;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _useInheritedSettings?;
    get useInheritedSettings(): boolean | cdktf.IResolvable;
    set useInheritedSettings(value: boolean | cdktf.IResolvable);
    resetUseInheritedSettings(): void;
    get useInheritedSettingsInput(): boolean | cdktf.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
