/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectLabelConfig extends cdktf.TerraformMetaArguments {
    /**
    * The color of the label given in 6-digit hex notation with leading '#' sign (e.g. #FFAABB) or one of the [CSS color names](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value#Color_keywords).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label#color ProjectLabel#color}
    */
    readonly color: string;
    /**
    * The description of the label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label#description ProjectLabel#description}
    */
    readonly description?: string;
    /**
    * The name of the label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label#name ProjectLabel#name}
    */
    readonly name: string;
    /**
    * The name or id of the project to add the label to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label#project ProjectLabel#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label gitlab_project_label}
*/
export declare class ProjectLabel extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_label";
    /**
    * Generates CDKTF code for importing a ProjectLabel resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectLabel to import
    * @param importFromId The id of the existing ProjectLabel that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectLabel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_label gitlab_project_label} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectLabelConfig
    */
    constructor(scope: Construct, id: string, config: ProjectLabelConfig);
    private _color?;
    get color(): string;
    set color(value: string);
    get colorInput(): string | undefined;
    get colorHex(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get labelId(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
