/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectMergeRequestsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Return merge requests created by the given user ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#author_id DataGitlabProjectMergeRequests#author_id}
    */
    readonly authorId?: number;
    /**
    * Return merge requests created by the given username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#author_username DataGitlabProjectMergeRequests#author_username}
    */
    readonly authorUsername?: string;
    /**
    * Return merge requests created after the given time. Expected in RFC3339 format (2006-01-02T15:04:05Z).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#created_after DataGitlabProjectMergeRequests#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Return merge requests created before the given time. Expected in RFC3339 format (2006-01-02T15:04:05Z).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#created_before DataGitlabProjectMergeRequests#created_before}
    */
    readonly createdBefore?: string;
    /**
    * The unique internal IDs of the merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#iids DataGitlabProjectMergeRequests#iids}
    */
    readonly iids?: number[];
    /**
    * Return only merge requests for a specific milestone. `None` returns merge requests with no milestone. `Any` returns merge requests that have an assigned milestone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#milestone DataGitlabProjectMergeRequests#milestone}
    */
    readonly milestone?: string;
    /**
    * Return merge requests reacted to by the authenticated user with the given emoji. `None` returns issues not given a reaction. `Any` returns issues given at least one reaction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#my_reaction_emoji DataGitlabProjectMergeRequests#my_reaction_emoji}
    */
    readonly myReactionEmoji?: string;
    /**
    * Return requests ordered by `created_at`, `title` or `updated_at`. Default is `created_at`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#order_by DataGitlabProjectMergeRequests#order_by}
    */
    readonly orderBy?: string;
    /**
    * The ID or path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#project DataGitlabProjectMergeRequests#project}
    */
    readonly project: string;
    /**
    * Return merge requests reviewed by the given username. `None` returns merge requests with no reviews. `Any` returns merge requests with any reviewer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#reviewer_username DataGitlabProjectMergeRequests#reviewer_username}
    */
    readonly reviewerUsername?: string;
    /**
    * Return merge requests for the given scope: `created_by_me`, `assigned_to_me`, or `all`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#scope DataGitlabProjectMergeRequests#scope}
    */
    readonly scope?: string;
    /**
    * Search merge requests against their `title` or `description`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#search DataGitlabProjectMergeRequests#search}
    */
    readonly search?: string;
    /**
    * Return requests sorted in `asc` or `desc` order. Default is `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#sort DataGitlabProjectMergeRequests#sort}
    */
    readonly sort?: string;
    /**
    * Return merge requests with the given source branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#source_branch DataGitlabProjectMergeRequests#source_branch}
    */
    readonly sourceBranch?: string;
    /**
    * Return all merge requests (all) or just those that are opened, closed, locked, or merged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#state DataGitlabProjectMergeRequests#state}
    */
    readonly state?: string;
    /**
    * Return merge requests with the given target branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#target_branch DataGitlabProjectMergeRequests#target_branch}
    */
    readonly targetBranch?: string;
    /**
    * Return merge requests updated after the given time. Expected in RFC3339 format (2006-01-02T15:04:05Z).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#updated_after DataGitlabProjectMergeRequests#updated_after}
    */
    readonly updatedAfter?: string;
    /**
    * Return merge requests updated before the given time. Expected in RFC3339 format (2006-01-02T15:04:05Z).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#updated_before DataGitlabProjectMergeRequests#updated_before}
    */
    readonly updatedBefore?: string;
    /**
    * Filter merge requests against their wip status. `yes` to return only draft merge requests, `no` to return non-draft merge requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#wip DataGitlabProjectMergeRequests#wip}
    */
    readonly wip?: string;
}
export interface DataGitlabProjectMergeRequestsMergeRequestsAssignee {
}
export declare function dataGitlabProjectMergeRequestsMergeRequestsAssigneeToTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAssignee): any;
export declare function dataGitlabProjectMergeRequestsMergeRequestsAssigneeToHclTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAssignee): any;
export declare class DataGitlabProjectMergeRequestsMergeRequestsAssigneeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestsMergeRequestsAssignee | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestsMergeRequestsAssignee | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabProjectMergeRequestsMergeRequestsAssignees {
}
export declare function dataGitlabProjectMergeRequestsMergeRequestsAssigneesToTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAssignees): any;
export declare function dataGitlabProjectMergeRequestsMergeRequestsAssigneesToHclTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAssignees): any;
export declare class DataGitlabProjectMergeRequestsMergeRequestsAssigneesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectMergeRequestsMergeRequestsAssignees | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestsMergeRequestsAssignees | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export declare class DataGitlabProjectMergeRequestsMergeRequestsAssigneesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectMergeRequestsMergeRequestsAssigneesOutputReference;
}
export interface DataGitlabProjectMergeRequestsMergeRequestsAuthor {
}
export declare function dataGitlabProjectMergeRequestsMergeRequestsAuthorToTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAuthor): any;
export declare function dataGitlabProjectMergeRequestsMergeRequestsAuthorToHclTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsAuthor): any;
export declare class DataGitlabProjectMergeRequestsMergeRequestsAuthorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestsMergeRequestsAuthor | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestsMergeRequestsAuthor | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabProjectMergeRequestsMergeRequestsClosedBy {
}
export declare function dataGitlabProjectMergeRequestsMergeRequestsClosedByToTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsClosedBy): any;
export declare function dataGitlabProjectMergeRequestsMergeRequestsClosedByToHclTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequestsClosedBy): any;
export declare class DataGitlabProjectMergeRequestsMergeRequestsClosedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestsMergeRequestsClosedBy | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestsMergeRequestsClosedBy | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabProjectMergeRequestsMergeRequests {
}
export declare function dataGitlabProjectMergeRequestsMergeRequestsToTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequests): any;
export declare function dataGitlabProjectMergeRequestsMergeRequestsToHclTerraform(struct?: DataGitlabProjectMergeRequestsMergeRequests): any;
export declare class DataGitlabProjectMergeRequestsMergeRequestsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectMergeRequestsMergeRequests | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestsMergeRequests | undefined);
    private _assignee;
    get assignee(): DataGitlabProjectMergeRequestsMergeRequestsAssigneeOutputReference;
    private _assignees;
    get assignees(): DataGitlabProjectMergeRequestsMergeRequestsAssigneesList;
    private _author;
    get author(): DataGitlabProjectMergeRequestsMergeRequestsAuthorOutputReference;
    get blockingDiscussionsResolved(): cdktf.IResolvable;
    get closedAt(): string;
    private _closedBy;
    get closedBy(): DataGitlabProjectMergeRequestsMergeRequestsClosedByOutputReference;
    get createdAt(): string;
    get id(): number;
    get iid(): number;
}
export declare class DataGitlabProjectMergeRequestsMergeRequestsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectMergeRequestsMergeRequestsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests gitlab_project_merge_requests}
*/
export declare class DataGitlabProjectMergeRequests extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_merge_requests";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectMergeRequests resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectMergeRequests to import
    * @param importFromId The id of the existing DataGitlabProjectMergeRequests that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectMergeRequests to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_requests gitlab_project_merge_requests} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectMergeRequestsConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectMergeRequestsConfig);
    private _authorId?;
    get authorId(): number;
    set authorId(value: number);
    resetAuthorId(): void;
    get authorIdInput(): number | undefined;
    private _authorUsername?;
    get authorUsername(): string;
    set authorUsername(value: string);
    resetAuthorUsername(): void;
    get authorUsernameInput(): string | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _iids?;
    get iids(): number[];
    set iids(value: number[]);
    resetIids(): void;
    get iidsInput(): number[] | undefined;
    private _mergeRequests;
    get mergeRequests(): DataGitlabProjectMergeRequestsMergeRequestsList;
    private _milestone?;
    get milestone(): string;
    set milestone(value: string);
    resetMilestone(): void;
    get milestoneInput(): string | undefined;
    private _myReactionEmoji?;
    get myReactionEmoji(): string;
    set myReactionEmoji(value: string);
    resetMyReactionEmoji(): void;
    get myReactionEmojiInput(): string | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _reviewerUsername?;
    get reviewerUsername(): string;
    set reviewerUsername(value: string);
    resetReviewerUsername(): void;
    get reviewerUsernameInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _sourceBranch?;
    get sourceBranch(): string;
    set sourceBranch(value: string);
    resetSourceBranch(): void;
    get sourceBranchInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _targetBranch?;
    get targetBranch(): string;
    set targetBranch(value: string);
    resetTargetBranch(): void;
    get targetBranchInput(): string | undefined;
    private _updatedAfter?;
    get updatedAfter(): string;
    set updatedAfter(value: string);
    resetUpdatedAfter(): void;
    get updatedAfterInput(): string | undefined;
    private _updatedBefore?;
    get updatedBefore(): string;
    set updatedBefore(value: string);
    resetUpdatedBefore(): void;
    get updatedBeforeInput(): string | undefined;
    private _wip?;
    get wip(): string;
    set wip(value: string);
    resetWip(): void;
    get wipInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
