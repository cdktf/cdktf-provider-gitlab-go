/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupShareGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Share expiration date. Format: `YYYY-MM-DD`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#expires_at GroupShareGroup#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The access level to grant the group. Valid values are: `no one`, `minimal`, `guest`, `planner`, `reporter`, `developer`, `maintainer`, `owner`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#group_access GroupShareGroup#group_access}
    */
    readonly groupAccess: string;
    /**
    * The id of the main group to be shared.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#group_id GroupShareGroup#group_id}
    */
    readonly groupId: string;
    /**
    * The ID of a custom member role. Only available for Ultimate instances and requires a feature flag enabling, see [this feature issue](https://gitlab.com/gitlab-org/gitlab/-/issues/443369) for details. If `member_role_id` is removed from the config, the group share will revert to a base role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#member_role_id GroupShareGroup#member_role_id}
    */
    readonly memberRoleId?: number;
    /**
    * The id of the additional group with which the main group will be shared.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#share_group_id GroupShareGroup#share_group_id}
    */
    readonly shareGroupId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group gitlab_group_share_group}
*/
export declare class GroupShareGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_share_group";
    /**
    * Generates CDKTF code for importing a GroupShareGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupShareGroup to import
    * @param importFromId The id of the existing GroupShareGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupShareGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/group_share_group gitlab_group_share_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupShareGroupConfig
    */
    constructor(scope: Construct, id: string, config: GroupShareGroupConfig);
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    private _groupAccess?;
    get groupAccess(): string;
    set groupAccess(value: string);
    get groupAccessInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get id(): string;
    private _memberRoleId?;
    get memberRoleId(): number;
    set memberRoleId(value: number);
    resetMemberRoleId(): void;
    get memberRoleIdInput(): number | undefined;
    private _shareGroupId?;
    get shareGroupId(): number;
    set shareGroupId(value: number);
    get shareGroupIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
