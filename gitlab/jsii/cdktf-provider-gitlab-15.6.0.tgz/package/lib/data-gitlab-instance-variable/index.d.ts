/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabInstanceVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variable#key DataGitlabInstanceVariable#key}
    */
    readonly key: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variable gitlab_instance_variable}
*/
export declare class DataGitlabInstanceVariable extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_instance_variable";
    /**
    * Generates CDKTF code for importing a DataGitlabInstanceVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabInstanceVariable to import
    * @param importFromId The id of the existing DataGitlabInstanceVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabInstanceVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/instance_variable gitlab_instance_variable} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabInstanceVariableConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabInstanceVariableConfig);
    get description(): string;
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    get masked(): cdktf.IResolvable;
    get protected(): cdktf.IResolvable;
    get raw(): cdktf.IResolvable;
    get value(): string;
    get variableType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
