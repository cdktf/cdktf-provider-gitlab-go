/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectIntegrationPipelinesEmailConfig extends cdktf.TerraformMetaArguments {
    /**
    * Branches to send notifications for. Valid options are `all`, `default`, `protected`, and `default_and_protected`. Default is `default`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#branches_to_be_notified ProjectIntegrationPipelinesEmail#branches_to_be_notified}
    */
    readonly branchesToBeNotified?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#id ProjectIntegrationPipelinesEmail#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Notify only broken pipelines. Default is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#notify_only_broken_pipelines ProjectIntegrationPipelinesEmail#notify_only_broken_pipelines}
    */
    readonly notifyOnlyBrokenPipelines?: boolean | cdktf.IResolvable;
    /**
    * ID of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#project ProjectIntegrationPipelinesEmail#project}
    */
    readonly project: string;
    /**
    * ) email addresses where notifications are sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#recipients ProjectIntegrationPipelinesEmail#recipients}
    */
    readonly recipients: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email gitlab_project_integration_pipelines_email}
*/
export declare class ProjectIntegrationPipelinesEmail extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_integration_pipelines_email";
    /**
    * Generates CDKTF code for importing a ProjectIntegrationPipelinesEmail resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectIntegrationPipelinesEmail to import
    * @param importFromId The id of the existing ProjectIntegrationPipelinesEmail that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectIntegrationPipelinesEmail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_integration_pipelines_email gitlab_project_integration_pipelines_email} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectIntegrationPipelinesEmailConfig
    */
    constructor(scope: Construct, id: string, config: ProjectIntegrationPipelinesEmailConfig);
    private _branchesToBeNotified?;
    get branchesToBeNotified(): string;
    set branchesToBeNotified(value: string);
    resetBranchesToBeNotified(): void;
    get branchesToBeNotifiedInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notifyOnlyBrokenPipelines?;
    get notifyOnlyBrokenPipelines(): boolean | cdktf.IResolvable;
    set notifyOnlyBrokenPipelines(value: boolean | cdktf.IResolvable);
    resetNotifyOnlyBrokenPipelines(): void;
    get notifyOnlyBrokenPipelinesInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    get recipientsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
