/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectEnvironmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The auto stop setting for the environment. Allowed values are `always`, `with_action`. If this is set to `with_action` and `stop_before_destroy` is `true`, the environment will be force-stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#auto_stop_setting ProjectEnvironment#auto_stop_setting}
    */
    readonly autoStopSetting?: string;
    /**
    * The cluster agent to associate with this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#cluster_agent_id ProjectEnvironment#cluster_agent_id}
    */
    readonly clusterAgentId?: number;
    /**
    * The description of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#description ProjectEnvironment#description}
    */
    readonly description?: string;
    /**
    * Place to link to for this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#external_url ProjectEnvironment#external_url}
    */
    readonly externalUrl?: string;
    /**
    * The Flux resource path to associate with this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#flux_resource_path ProjectEnvironment#flux_resource_path}
    */
    readonly fluxResourcePath?: string;
    /**
    * The Kubernetes namespace to associate with this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#kubernetes_namespace ProjectEnvironment#kubernetes_namespace}
    */
    readonly kubernetesNamespace?: string;
    /**
    * The name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#name ProjectEnvironment#name}
    */
    readonly name: string;
    /**
    * The ID or full path of the project to environment is created for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#project ProjectEnvironment#project}
    */
    readonly project: string;
    /**
    * Determines whether the environment is attempted to be stopped before the environment is deleted. If `auto_stop_setting` is set to `with_action`, this will perform a force stop.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#stop_before_destroy ProjectEnvironment#stop_before_destroy}
    */
    readonly stopBeforeDestroy?: boolean | cdktf.IResolvable;
    /**
    * The tier of the new environment. Valid values are `production`, `staging`, `testing`, `development`, `other`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#tier ProjectEnvironment#tier}
    */
    readonly tier?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment gitlab_project_environment}
*/
export declare class ProjectEnvironment extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_environment";
    /**
    * Generates CDKTF code for importing a ProjectEnvironment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectEnvironment to import
    * @param importFromId The id of the existing ProjectEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_environment gitlab_project_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: ProjectEnvironmentConfig);
    get autoStopAt(): string;
    private _autoStopSetting?;
    get autoStopSetting(): string;
    set autoStopSetting(value: string);
    resetAutoStopSetting(): void;
    get autoStopSettingInput(): string | undefined;
    private _clusterAgentId?;
    get clusterAgentId(): number;
    set clusterAgentId(value: number);
    resetClusterAgentId(): void;
    get clusterAgentIdInput(): number | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _externalUrl?;
    get externalUrl(): string;
    set externalUrl(value: string);
    resetExternalUrl(): void;
    get externalUrlInput(): string | undefined;
    private _fluxResourcePath?;
    get fluxResourcePath(): string;
    set fluxResourcePath(value: string);
    resetFluxResourcePath(): void;
    get fluxResourcePathInput(): string | undefined;
    get id(): string;
    private _kubernetesNamespace?;
    get kubernetesNamespace(): string;
    set kubernetesNamespace(value: string);
    resetKubernetesNamespace(): void;
    get kubernetesNamespaceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get slug(): string;
    get state(): string;
    private _stopBeforeDestroy?;
    get stopBeforeDestroy(): boolean | cdktf.IResolvable;
    set stopBeforeDestroy(value: boolean | cdktf.IResolvable);
    resetStopBeforeDestroy(): void;
    get stopBeforeDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
