/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ClusterAgentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Name of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent#name ClusterAgent#name}
    */
    readonly name: string;
    /**
    * ID or full path of the project maintained by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent#project ClusterAgent#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent gitlab_cluster_agent}
*/
export declare class ClusterAgent extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_cluster_agent";
    /**
    * Generates CDKTF code for importing a ClusterAgent resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClusterAgent to import
    * @param importFromId The id of the existing ClusterAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClusterAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent gitlab_cluster_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterAgentConfig
    */
    constructor(scope: Construct, id: string, config: ClusterAgentConfig);
    get agentId(): number;
    get createdAt(): string;
    get createdByUserId(): number;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
