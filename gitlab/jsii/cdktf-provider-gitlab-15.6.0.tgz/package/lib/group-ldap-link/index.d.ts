/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupLdapLinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * The CN of the LDAP group to link with. Required if `filter` is not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#cn GroupLdapLink#cn}
    */
    readonly cn?: string;
    /**
    * The LDAP filter for the group. Required if `cn` is not provided. Requires GitLab Premium or above.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#filter GroupLdapLink#filter}
    */
    readonly filter?: string;
    /**
    * If true, then delete and replace an existing LDAP link if one exists. Will also remove an LDAP link if the parent group is not found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#force GroupLdapLink#force}
    */
    readonly force?: boolean | cdktf.IResolvable;
    /**
    * The ID or URL-encoded path of the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#group GroupLdapLink#group}
    */
    readonly group: string;
    /**
    * Minimum access level for members of the LDAP group. Valid values are: `no one`, `minimal`, `guest`, `planner`, `reporter`, `developer`, `maintainer`, `owner`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#group_access GroupLdapLink#group_access}
    */
    readonly groupAccess: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#id GroupLdapLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the LDAP provider as stored in the GitLab database. Note that this is NOT the value of the `label` attribute as shown in the web UI. In most cases this will be `ldapmain` but you may use the [LDAP check rake task](https://docs.gitlab.com/administration/raketasks/ldap/#check) for receiving the LDAP server name: `LDAP: ... Server: ldapmain`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#ldap_provider GroupLdapLink#ldap_provider}
    */
    readonly ldapProvider: string;
    /**
    * The ID of a custom member role. Only available for Ultimate instances. When using a custom role, the `group_access` must match the base role used to create the custom role. To remove a custom role and revert to a base role, set this value to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#member_role_id GroupLdapLink#member_role_id}
    */
    readonly memberRoleId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link gitlab_group_ldap_link}
*/
export declare class GroupLdapLink extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group_ldap_link";
    /**
    * Generates CDKTF code for importing a GroupLdapLink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupLdapLink to import
    * @param importFromId The id of the existing GroupLdapLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupLdapLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group_ldap_link gitlab_group_ldap_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupLdapLinkConfig
    */
    constructor(scope: Construct, id: string, config: GroupLdapLinkConfig);
    private _cn?;
    get cn(): string;
    set cn(value: string);
    resetCn(): void;
    get cnInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktf.IResolvable;
    set force(value: boolean | cdktf.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktf.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _groupAccess?;
    get groupAccess(): string;
    set groupAccess(value: string);
    get groupAccessInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ldapProvider?;
    get ldapProvider(): string;
    set ldapProvider(value: string);
    get ldapProviderInput(): string | undefined;
    private _memberRoleId?;
    get memberRoleId(): number;
    set memberRoleId(value: number);
    resetMemberRoleId(): void;
    get memberRoleIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
