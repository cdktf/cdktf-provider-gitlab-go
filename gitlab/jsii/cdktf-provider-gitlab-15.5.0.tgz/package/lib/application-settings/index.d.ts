/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApplicationSettingsConfig extends cdktf.TerraformMetaArguments {
    /**
    * If set, abuse reports are sent to this address. Abuse reports are always available in the Admin Area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#abuse_notification_email ApplicationSettings#abuse_notification_email}
    */
    readonly abuseNotificationEmail?: string;
    /**
    * Require administrators to enable Admin Mode by re-authenticating for administrative tasks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#admin_mode ApplicationSettings#admin_mode}
    */
    readonly adminMode?: boolean | cdktf.IResolvable;
    /**
    * Where to redirect users after logout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#after_sign_out_path ApplicationSettings#after_sign_out_path}
    */
    readonly afterSignOutPath?: string;
    /**
    * Text shown to the user after signing up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#after_sign_up_text ApplicationSettings#after_sign_up_text}
    */
    readonly afterSignUpText?: string;
    /**
    * API key for Akismet spam protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#akismet_api_key ApplicationSettings#akismet_api_key}
    */
    readonly akismetApiKey?: string;
    /**
    * (If enabled, requires: akismet_api_key) Enable or disable Akismet spam protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#akismet_enabled ApplicationSettings#akismet_enabled}
    */
    readonly akismetEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set to true to allow users to delete their accounts. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_account_deletion ApplicationSettings#allow_account_deletion}
    */
    readonly allowAccountDeletion?: boolean | cdktf.IResolvable;
    /**
    * Set to true to allow group owners to manage LDAP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_group_owners_to_manage_ldap ApplicationSettings#allow_group_owners_to_manage_ldap}
    */
    readonly allowGroupOwnersToManageLdap?: boolean | cdktf.IResolvable;
    /**
    * Allow requests to the local network from system hooks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_local_requests_from_system_hooks ApplicationSettings#allow_local_requests_from_system_hooks}
    */
    readonly allowLocalRequestsFromSystemHooks?: boolean | cdktf.IResolvable;
    /**
    * Allow requests to the local network from web hooks and services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_local_requests_from_web_hooks_and_services ApplicationSettings#allow_local_requests_from_web_hooks_and_services}
    */
    readonly allowLocalRequestsFromWebHooksAndServices?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether users assigned up to the Guest role can create groups and personal projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_project_creation_for_guest_and_below ApplicationSettings#allow_project_creation_for_guest_and_below}
    */
    readonly allowProjectCreationForGuestAndBelow?: boolean | cdktf.IResolvable;
    /**
    * Allow using a registration token to create a runner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_runner_registration_token ApplicationSettings#allow_runner_registration_token}
    */
    readonly allowRunnerRegistrationToken?: boolean | cdktf.IResolvable;
    /**
    * Set the duration for which the jobs are considered as old and expired. After that time passes, the jobs are archived and no longer able to be retried. Make it empty to never expire jobs. It has to be no less than 1 day, for example: 15 days, 1 month, 2 years.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#archive_builds_in_human_readable ApplicationSettings#archive_builds_in_human_readable}
    */
    readonly archiveBuildsInHumanReadable?: string;
    /**
    * Maximum limit of AsciiDoc include directives being processed in any one document. Maximum: 64.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#asciidoc_max_includes ApplicationSettings#asciidoc_max_includes}
    */
    readonly asciidocMaxIncludes?: number;
    /**
    * Assets that match these domains are not proxied. Wildcards allowed. Your GitLab installation URL is automatically allowlisted. GitLab restart is required to apply changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#asset_proxy_allowlist ApplicationSettings#asset_proxy_allowlist}
    */
    readonly assetProxyAllowlist?: string[];
    /**
    * (If enabled, requires: asset_proxy_url) Enable proxying of assets. GitLab restart is required to apply changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#asset_proxy_enabled ApplicationSettings#asset_proxy_enabled}
    */
    readonly assetProxyEnabled?: boolean | cdktf.IResolvable;
    /**
    * Shared secret with the asset proxy server. GitLab restart is required to apply changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#asset_proxy_secret_key ApplicationSettings#asset_proxy_secret_key}
    */
    readonly assetProxySecretKey?: string;
    /**
    * URL of the asset proxy server. GitLab restart is required to apply changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#asset_proxy_url ApplicationSettings#asset_proxy_url}
    */
    readonly assetProxyUrl?: string;
    /**
    * By default, we write to the authorized_keys file to support Git over SSH without additional configuration. GitLab can be optimized to authenticate SSH keys via the database file. Only disable this if you have configured your OpenSSH server to use the AuthorizedKeysCommand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#authorized_keys_enabled ApplicationSettings#authorized_keys_enabled}
    */
    readonly authorizedKeysEnabled?: boolean | cdktf.IResolvable;
    /**
    * When enabled, users will get automatically banned from the application when they download more than the maximum number of unique projects in the time period specified by max_number_of_repository_downloads and max_number_of_repository_downloads_within_time_period respectively. Self-managed, Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#auto_ban_user_on_excessive_projects_download ApplicationSettings#auto_ban_user_on_excessive_projects_download}
    */
    readonly autoBanUserOnExcessiveProjectsDownload?: boolean | cdktf.IResolvable;
    /**
    * Specify a domain to use by default for every project’s Auto Review Apps and Auto Deploy stages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#auto_devops_domain ApplicationSettings#auto_devops_domain}
    */
    readonly autoDevopsDomain?: string;
    /**
    * Enable Auto DevOps for projects by default. It automatically builds, tests, and deploys applications based on a predefined CI/CD configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#auto_devops_enabled ApplicationSettings#auto_devops_enabled}
    */
    readonly autoDevopsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enabling this permits automatic allocation of purchased storage in a namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#automatic_purchased_storage_allocation ApplicationSettings#automatic_purchased_storage_allocation}
    */
    readonly automaticPurchasedStorageAllocation?: boolean | cdktf.IResolvable;
    /**
    * Maximum simultaneous Direct Transfer batches to process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#bulk_import_concurrent_pipeline_batch_limit ApplicationSettings#bulk_import_concurrent_pipeline_batch_limit}
    */
    readonly bulkImportConcurrentPipelineBatchLimit?: number;
    /**
    * Enable migrating GitLab groups by direct transfer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#bulk_import_enabled ApplicationSettings#bulk_import_enabled}
    */
    readonly bulkImportEnabled?: boolean | cdktf.IResolvable;
    /**
    * Maximum download file size when importing from source GitLab instances by direct transfer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#bulk_import_max_download_file_size ApplicationSettings#bulk_import_max_download_file_size}
    */
    readonly bulkImportMaxDownloadFileSize?: number;
    /**
    * Indicates whether users can create top-level groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#can_create_group ApplicationSettings#can_create_group}
    */
    readonly canCreateGroup?: boolean | cdktf.IResolvable;
    /**
    * Enabling this makes only licensed EE features available to projects if the project namespace’s plan includes the feature or if the project is public.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#check_namespace_plan ApplicationSettings#check_namespace_plan}
    */
    readonly checkNamespacePlan?: boolean | cdktf.IResolvable;
    /**
    * The maximum number of includes per pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ci_max_includes ApplicationSettings#ci_max_includes}
    */
    readonly ciMaxIncludes?: number;
    /**
    * The maximum amount of memory, in bytes, that can be allocated for the pipeline configuration, with all included YAML configuration files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ci_max_total_yaml_size_bytes ApplicationSettings#ci_max_total_yaml_size_bytes}
    */
    readonly ciMaxTotalYamlSizeBytes?: number;
    /**
    * Custom hostname (for private commit emails).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#commit_email_hostname ApplicationSettings#commit_email_hostname}
    */
    readonly commitEmailHostname?: string;
    /**
    * Maximum number of simultaneous import jobs for the Bitbucket Cloud importer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#concurrent_bitbucket_import_jobs_limit ApplicationSettings#concurrent_bitbucket_import_jobs_limit}
    */
    readonly concurrentBitbucketImportJobsLimit?: number;
    /**
    * Maximum number of simultaneous import jobs for the Bitbucket Server importer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#concurrent_bitbucket_server_import_jobs_limit ApplicationSettings#concurrent_bitbucket_server_import_jobs_limit}
    */
    readonly concurrentBitbucketServerImportJobsLimit?: number;
    /**
    * Maximum number of simultaneous import jobs for the GitHub importer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#concurrent_github_import_jobs_limit ApplicationSettings#concurrent_github_import_jobs_limit}
    */
    readonly concurrentGithubImportJobsLimit?: number;
    /**
    * Enable cleanup policies for all projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_expiration_policies_enable_historic_entries ApplicationSettings#container_expiration_policies_enable_historic_entries}
    */
    readonly containerExpirationPoliciesEnableHistoricEntries?: boolean | cdktf.IResolvable;
    /**
    * The maximum number of tags that can be deleted in a single execution of cleanup policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_registry_cleanup_tags_service_max_list_size ApplicationSettings#container_registry_cleanup_tags_service_max_list_size}
    */
    readonly containerRegistryCleanupTagsServiceMaxListSize?: number;
    /**
    * The maximum time, in seconds, that the cleanup process can take to delete a batch of tags for cleanup policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_registry_delete_tags_service_timeout ApplicationSettings#container_registry_delete_tags_service_timeout}
    */
    readonly containerRegistryDeleteTagsServiceTimeout?: number;
    /**
    * Caching during the execution of cleanup policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_registry_expiration_policies_caching ApplicationSettings#container_registry_expiration_policies_caching}
    */
    readonly containerRegistryExpirationPoliciesCaching?: boolean | cdktf.IResolvable;
    /**
    * Number of workers for cleanup policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_registry_expiration_policies_worker_capacity ApplicationSettings#container_registry_expiration_policies_worker_capacity}
    */
    readonly containerRegistryExpirationPoliciesWorkerCapacity?: number;
    /**
    * Container Registry token duration in minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#container_registry_token_expire_delay ApplicationSettings#container_registry_token_expire_delay}
    */
    readonly containerRegistryTokenExpireDelay?: number;
    /**
    * Enable automatic deactivation of dormant users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#deactivate_dormant_users ApplicationSettings#deactivate_dormant_users}
    */
    readonly deactivateDormantUsers?: boolean | cdktf.IResolvable;
    /**
    * Length of time (in days) after which a user is considered dormant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#deactivate_dormant_users_period ApplicationSettings#deactivate_dormant_users_period}
    */
    readonly deactivateDormantUsersPeriod?: number;
    /**
    * Default timeout for decompressing archived files, in seconds. Set to 0 to disable timeouts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#decompress_archive_file_timeout ApplicationSettings#decompress_archive_file_timeout}
    */
    readonly decompressArchiveFileTimeout?: number;
    /**
    * Set the default expiration time for each job’s artifacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_artifacts_expire_in ApplicationSettings#default_artifacts_expire_in}
    */
    readonly defaultArtifactsExpireIn?: string;
    /**
    * Instance-level custom initial branch name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_branch_name ApplicationSettings#default_branch_name}
    */
    readonly defaultBranchName?: string;
    /**
    * Determine if developers can push to the default branch. Can take: 0 (not protected, both users with the Developer role or Maintainer role can push new commits and force push), 1 (partially protected, users with the Developer role or Maintainer role can push new commits, but cannot force push) or 2 (fully protected, users with the Developer or Maintainer role cannot push new commits, but users with the Developer or Maintainer role can; no one can force push) as a parameter. Default is 2. Use `default_branch_protection_defaults` instead. To be removed in 19.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_branch_protection ApplicationSettings#default_branch_protection}
    */
    readonly defaultBranchProtection?: number;
    /**
    * Default CI/CD configuration file and path for new projects (.gitlab-ci.yml if not set).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_ci_config_path ApplicationSettings#default_ci_config_path}
    */
    readonly defaultCiConfigPath?: string;
    /**
    * What visibility level new groups receive. Can take private, internal and public as a parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_group_visibility ApplicationSettings#default_group_visibility}
    */
    readonly defaultGroupVisibility?: string;
    /**
    * Default preferred language for users who are not logged in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_preferred_language ApplicationSettings#default_preferred_language}
    */
    readonly defaultPreferredLanguage?: string;
    /**
    * Default project creation protection. Can take: 0 (No one), 1 (Maintainers) or 2 (Developers + Maintainers).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_project_creation ApplicationSettings#default_project_creation}
    */
    readonly defaultProjectCreation?: number;
    /**
    * What visibility level new projects receive. Can take private, internal and public as a parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_project_visibility ApplicationSettings#default_project_visibility}
    */
    readonly defaultProjectVisibility?: string;
    /**
    * Project limit per user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_projects_limit ApplicationSettings#default_projects_limit}
    */
    readonly defaultProjectsLimit?: number;
    /**
    * What visibility level new snippets receive. Can take private, internal and public as a parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_snippet_visibility ApplicationSettings#default_snippet_visibility}
    */
    readonly defaultSnippetVisibility?: string;
    /**
    * Default syntax highlighting theme for users who are new or not signed in. See IDs of available themes (https://gitlab.com/gitlab-org/gitlab/blob/master/lib/gitlab/themes.rb#L16)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_syntax_highlighting_theme ApplicationSettings#default_syntax_highlighting_theme}
    */
    readonly defaultSyntaxHighlightingTheme?: number;
    /**
    * Enable inactive project deletion feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#delete_inactive_projects ApplicationSettings#delete_inactive_projects}
    */
    readonly deleteInactiveProjects?: boolean | cdktf.IResolvable;
    /**
    * Specifies whether users who have not confirmed their email should be deleted. When set to true, unconfirmed users are deleted after unconfirmed_users_delete_after_days days. Self-managed, Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#delete_unconfirmed_users ApplicationSettings#delete_unconfirmed_users}
    */
    readonly deleteUnconfirmedUsers?: boolean | cdktf.IResolvable;
    /**
    * The number of days to wait before deleting a project or group that is marked for deletion. Value must be between 1 and 90.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#deletion_adjourned_period ApplicationSettings#deletion_adjourned_period}
    */
    readonly deletionAdjournedPeriod?: number;
    /**
    * (If enabled, requires diagramsnet_url) Enable Diagrams.net integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#diagramsnet_enabled ApplicationSettings#diagramsnet_enabled}
    */
    readonly diagramsnetEnabled?: boolean | cdktf.IResolvable;
    /**
    * The Diagrams.net instance URL for integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#diagramsnet_url ApplicationSettings#diagramsnet_url}
    */
    readonly diagramsnetUrl?: string;
    /**
    * Maximum files in a diff.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#diff_max_files ApplicationSettings#diff_max_files}
    */
    readonly diffMaxFiles?: number;
    /**
    * Maximum lines in a diff.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#diff_max_lines ApplicationSettings#diff_max_lines}
    */
    readonly diffMaxLines?: number;
    /**
    * Maximum diff patch size, in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#diff_max_patch_bytes ApplicationSettings#diff_max_patch_bytes}
    */
    readonly diffMaxPatchBytes?: number;
    /**
    * Stops administrators from connecting their GitLab accounts to non-trusted OAuth 2.0 applications that have the api, read_api, read_repository, write_repository, read_registry, write_registry, or sudo scopes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#disable_admin_oauth_scopes ApplicationSettings#disable_admin_oauth_scopes}
    */
    readonly disableAdminOauthScopes?: boolean | cdktf.IResolvable;
    /**
    * Disable display of RSS/Atom and calendar feed tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#disable_feed_token ApplicationSettings#disable_feed_token}
    */
    readonly disableFeedToken?: boolean | cdktf.IResolvable;
    /**
    * Disable personal access tokens. Self-managed, Premium and Ultimate only. There is no method available to enable a personal access token that’s been disabled through the API. This is a known issue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#disable_personal_access_tokens ApplicationSettings#disable_personal_access_tokens}
    */
    readonly disablePersonalAccessTokens?: boolean | cdktf.IResolvable;
    /**
    * Disabled OAuth sign-in sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#disabled_oauth_sign_in_sources ApplicationSettings#disabled_oauth_sign_in_sources}
    */
    readonly disabledOauthSignInSources?: string[];
    /**
    * Enforce DNS rebinding attack protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#dns_rebinding_protection_enabled ApplicationSettings#dns_rebinding_protection_enabled}
    */
    readonly dnsRebindingProtectionEnabled?: boolean | cdktf.IResolvable;
    /**
    * Force people to use only corporate emails for sign-up. Null means there is no restriction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#domain_allowlist ApplicationSettings#domain_allowlist}
    */
    readonly domainAllowlist?: string[];
    /**
    * Users with email addresses that match these domains cannot sign up. Wildcards allowed. Use separate lines for multiple entries. Ex: domain.com, *.domain.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#domain_denylist ApplicationSettings#domain_denylist}
    */
    readonly domainDenylist?: string[];
    /**
    * (If enabled, requires: domain_denylist) Allows blocking sign-ups from emails from specific domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#domain_denylist_enabled ApplicationSettings#domain_denylist_enabled}
    */
    readonly domainDenylistEnabled?: boolean | cdktf.IResolvable;
    /**
    * Maximum downstream pipeline trigger rate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#downstream_pipeline_trigger_limit_per_project_user_sha ApplicationSettings#downstream_pipeline_trigger_limit_per_project_user_sha}
    */
    readonly downstreamPipelineTriggerLimitPerProjectUserSha?: number;
    /**
    * The minimum allowed bit length of an uploaded DSA key. 0 means no restriction. -1 disables DSA keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#dsa_key_restriction ApplicationSettings#dsa_key_restriction}
    */
    readonly dsaKeyRestriction?: number;
    /**
    * Indicates whether GitLab Duo features are enabled for this instance. Self-managed, Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#duo_features_enabled ApplicationSettings#duo_features_enabled}
    */
    readonly duoFeaturesEnabled?: boolean | cdktf.IResolvable;
    /**
    * The minimum allowed curve size (in bits) of an uploaded ECDSA key. 0 means no restriction. -1 disables ECDSA keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ecdsa_key_restriction ApplicationSettings#ecdsa_key_restriction}
    */
    readonly ecdsaKeyRestriction?: number;
    /**
    * The minimum allowed curve size (in bits) of an uploaded ECDSA_SK key. 0 means no restriction. -1 disables ECDSA_SK keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ecdsa_sk_key_restriction ApplicationSettings#ecdsa_sk_key_restriction}
    */
    readonly ecdsaSkKeyRestriction?: number;
    /**
    * The minimum allowed curve size (in bits) of an uploaded ED25519 key. 0 means no restriction. -1 disables ED25519 keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ed25519_key_restriction ApplicationSettings#ed25519_key_restriction}
    */
    readonly ed25519KeyRestriction?: number;
    /**
    * The minimum allowed curve size (in bits) of an uploaded ED25519_SK key. 0 means no restriction. -1 disables ED25519_SK keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#ed25519_sk_key_restriction ApplicationSettings#ed25519_sk_key_restriction}
    */
    readonly ed25519SkKeyRestriction?: number;
    /**
    * AWS IAM access key ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#eks_access_key_id ApplicationSettings#eks_access_key_id}
    */
    readonly eksAccessKeyId?: string;
    /**
    * Amazon account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#eks_account_id ApplicationSettings#eks_account_id}
    */
    readonly eksAccountId?: string;
    /**
    * Enable integration with Amazon EKS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#eks_integration_enabled ApplicationSettings#eks_integration_enabled}
    */
    readonly eksIntegrationEnabled?: boolean | cdktf.IResolvable;
    /**
    * AWS IAM secret access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#eks_secret_access_key ApplicationSettings#eks_secret_access_key}
    */
    readonly eksSecretAccessKey?: string;
    /**
    * Enable the use of AWS hosted Elasticsearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_aws ApplicationSettings#elasticsearch_aws}
    */
    readonly elasticsearchAws?: boolean | cdktf.IResolvable;
    /**
    * AWS IAM access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_aws_access_key ApplicationSettings#elasticsearch_aws_access_key}
    */
    readonly elasticsearchAwsAccessKey?: string;
    /**
    * The AWS region the Elasticsearch domain is configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_aws_region ApplicationSettings#elasticsearch_aws_region}
    */
    readonly elasticsearchAwsRegion?: string;
    /**
    * AWS IAM secret access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_aws_secret_access_key ApplicationSettings#elasticsearch_aws_secret_access_key}
    */
    readonly elasticsearchAwsSecretAccessKey?: string;
    /**
    * Maximum size of text fields to index by Elasticsearch. 0 value means no limit. This does not apply to repository and wiki indexing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_indexed_field_length_limit ApplicationSettings#elasticsearch_indexed_field_length_limit}
    */
    readonly elasticsearchIndexedFieldLengthLimit?: number;
    /**
    * Maximum size of repository and wiki files that are indexed by Elasticsearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_indexed_file_size_limit_kb ApplicationSettings#elasticsearch_indexed_file_size_limit_kb}
    */
    readonly elasticsearchIndexedFileSizeLimitKb?: number;
    /**
    * Enable Elasticsearch indexing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_indexing ApplicationSettings#elasticsearch_indexing}
    */
    readonly elasticsearchIndexing?: boolean | cdktf.IResolvable;
    /**
    * Limit Elasticsearch to index certain namespaces and projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_limit_indexing ApplicationSettings#elasticsearch_limit_indexing}
    */
    readonly elasticsearchLimitIndexing?: boolean | cdktf.IResolvable;
    /**
    * Maximum concurrency of Elasticsearch bulk requests per indexing operation. This only applies to repository indexing operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_max_bulk_concurrency ApplicationSettings#elasticsearch_max_bulk_concurrency}
    */
    readonly elasticsearchMaxBulkConcurrency?: number;
    /**
    * Maximum size of Elasticsearch bulk indexing requests in MB. This only applies to repository indexing operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_max_bulk_size_mb ApplicationSettings#elasticsearch_max_bulk_size_mb}
    */
    readonly elasticsearchMaxBulkSizeMb?: number;
    /**
    * Maximum concurrency of Elasticsearch code indexing background jobs. This only applies to repository indexing operations. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_max_code_indexing_concurrency ApplicationSettings#elasticsearch_max_code_indexing_concurrency}
    */
    readonly elasticsearchMaxCodeIndexingConcurrency?: number;
    /**
    * The namespaces to index via Elasticsearch if elasticsearch_limit_indexing is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_namespace_ids ApplicationSettings#elasticsearch_namespace_ids}
    */
    readonly elasticsearchNamespaceIds?: number[];
    /**
    * The password of your Elasticsearch instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_password ApplicationSettings#elasticsearch_password}
    */
    readonly elasticsearchPassword?: string;
    /**
    * The projects to index via Elasticsearch if elasticsearch_limit_indexing is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_project_ids ApplicationSettings#elasticsearch_project_ids}
    */
    readonly elasticsearchProjectIds?: number[];
    /**
    * Enable automatic requeuing of indexing workers. This improves non-code indexing throughput by enqueuing Sidekiq jobs until all documents are processed. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_requeue_workers ApplicationSettings#elasticsearch_requeue_workers}
    */
    readonly elasticsearchRequeueWorkers?: boolean | cdktf.IResolvable;
    /**
    * Enable Elasticsearch search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_search ApplicationSettings#elasticsearch_search}
    */
    readonly elasticsearchSearch?: boolean | cdktf.IResolvable;
    /**
    * The URL to use for connecting to Elasticsearch. Use a comma-separated list to support cluster (for example, http://localhost:9200, http://localhost:9201).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_url ApplicationSettings#elasticsearch_url}
    */
    readonly elasticsearchUrl?: string[];
    /**
    * The username of your Elasticsearch instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_username ApplicationSettings#elasticsearch_username}
    */
    readonly elasticsearchUsername?: string;
    /**
    * Number of indexing worker shards. This improves non-code indexing throughput by enqueuing more parallel Sidekiq jobs. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#elasticsearch_worker_number_of_shards ApplicationSettings#elasticsearch_worker_number_of_shards}
    */
    readonly elasticsearchWorkerNumberOfShards?: number;
    /**
    * Additional text added to the bottom of every email for legal/auditing/compliance reasons.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#email_additional_text ApplicationSettings#email_additional_text}
    */
    readonly emailAdditionalText?: string;
    /**
    * Some email servers do not support overriding the email sender name. Enable this option to include the name of the author of the issue, merge request or comment in the email body instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#email_author_in_body ApplicationSettings#email_author_in_body}
    */
    readonly emailAuthorInBody?: boolean | cdktf.IResolvable;
    /**
    * Specifies whether users must confirm their email before sign in. Possible values are off, soft, and hard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#email_confirmation_setting ApplicationSettings#email_confirmation_setting}
    */
    readonly emailConfirmationSetting?: string;
    /**
    * Show the external redirect page that warns you about user-generated content in GitLab Pages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#enable_artifact_external_redirect_warning_page ApplicationSettings#enable_artifact_external_redirect_warning_page}
    */
    readonly enableArtifactExternalRedirectWarningPage?: boolean | cdktf.IResolvable;
    /**
    * Enabled protocols for Git access. Allowed values are: ssh, http, and nil to allow both protocols.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#enabled_git_access_protocol ApplicationSettings#enabled_git_access_protocol}
    */
    readonly enabledGitAccessProtocol?: string;
    /**
    * Enabling this permits enforcement of namespace storage limits.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#enforce_namespace_storage_limit ApplicationSettings#enforce_namespace_storage_limit}
    */
    readonly enforceNamespaceStorageLimit?: boolean | cdktf.IResolvable;
    /**
    * (If enabled, requires: terms) Enforce application ToS to all users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#enforce_terms ApplicationSettings#enforce_terms}
    */
    readonly enforceTerms?: boolean | cdktf.IResolvable;
    /**
    * (If enabled, requires: external_auth_client_key) The certificate to use to authenticate with the external authorization service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_auth_client_cert ApplicationSettings#external_auth_client_cert}
    */
    readonly externalAuthClientCert?: string;
    /**
    * Private key for the certificate when authentication is required for the external authorization service, this is encrypted when stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_auth_client_key ApplicationSettings#external_auth_client_key}
    */
    readonly externalAuthClientKey?: string;
    /**
    * Passphrase to use for the private key when authenticating with the external service this is encrypted when stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_auth_client_key_pass ApplicationSettings#external_auth_client_key_pass}
    */
    readonly externalAuthClientKeyPass?: string;
    /**
    * The default classification label to use when requesting authorization and no classification label has been specified on the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_authorization_service_default_label ApplicationSettings#external_authorization_service_default_label}
    */
    readonly externalAuthorizationServiceDefaultLabel?: string;
    /**
    * (If enabled, requires: external_authorization_service_default_label, external_authorization_service_timeout and external_authorization_service_url) Enable using an external authorization service for accessing projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_authorization_service_enabled ApplicationSettings#external_authorization_service_enabled}
    */
    readonly externalAuthorizationServiceEnabled?: boolean | cdktf.IResolvable;
    /**
    * The timeout after which an authorization request is aborted, in seconds. When a request times out, access is denied to the user. (min: 0.001, max: 10, step: 0.001).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_authorization_service_timeout ApplicationSettings#external_authorization_service_timeout}
    */
    readonly externalAuthorizationServiceTimeout?: number;
    /**
    * URL to which authorization requests are directed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_authorization_service_url ApplicationSettings#external_authorization_service_url}
    */
    readonly externalAuthorizationServiceUrl?: string;
    /**
    * How long to wait for a response from the pipeline validation service. Assumes OK if it times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_pipeline_validation_service_timeout ApplicationSettings#external_pipeline_validation_service_timeout}
    */
    readonly externalPipelineValidationServiceTimeout?: number;
    /**
    * Optional. Token to include as the X-Gitlab-Token header in requests to the URL in external_pipeline_validation_service_url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_pipeline_validation_service_token ApplicationSettings#external_pipeline_validation_service_token}
    */
    readonly externalPipelineValidationServiceToken?: string;
    /**
    * URL to use for pipeline validation requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#external_pipeline_validation_service_url ApplicationSettings#external_pipeline_validation_service_url}
    */
    readonly externalPipelineValidationServiceUrl?: string;
    /**
    * Time period in minutes after which the user is unlocked when maximum number of failed sign-in attempts reached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#failed_login_attempts_unlock_period_in_minutes ApplicationSettings#failed_login_attempts_unlock_period_in_minutes}
    */
    readonly failedLoginAttemptsUnlockPeriodInMinutes?: number;
    /**
    * The ID of a project to load custom file templates from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#file_template_project_id ApplicationSettings#file_template_project_id}
    */
    readonly fileTemplateProjectId?: number;
    /**
    * Start day of the week for calendar views and date pickers. Valid values are 0 for Sunday, 1 for Monday, and 6 for Saturday.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#first_day_of_week ApplicationSettings#first_day_of_week}
    */
    readonly firstDayOfWeek?: number;
    /**
    * Comma-separated list of IPs and CIDRs of allowed secondary nodes. For example, 1.1.1.1, 2.2.2.0/24.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#geo_node_allowed_ips ApplicationSettings#geo_node_allowed_ips}
    */
    readonly geoNodeAllowedIps?: string;
    /**
    * The amount of seconds after which a request to get a secondary node status times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#geo_status_timeout ApplicationSettings#geo_status_timeout}
    */
    readonly geoStatusTimeout?: number;
    /**
    * List of user IDs that are emailed when the Git abuse rate limit is exceeded. Maximum: 100 user IDs. Self-managed, Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#git_rate_limit_users_alertlist ApplicationSettings#git_rate_limit_users_alertlist}
    */
    readonly gitRateLimitUsersAlertlist?: number[];
    /**
    * List of usernames excluded from Git anti-abuse rate limits. Maximum: 100 usernames. Self-managed, Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#git_rate_limit_users_allowlist ApplicationSettings#git_rate_limit_users_allowlist}
    */
    readonly gitRateLimitUsersAllowlist?: string[];
    /**
    * Maximum duration (in minutes) of a session for Git operations when 2FA is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#git_two_factor_session_expiry ApplicationSettings#git_two_factor_session_expiry}
    */
    readonly gitTwoFactorSessionExpiry?: number;
    /**
    * Default Gitaly timeout, in seconds. This timeout is not enforced for Git fetch/push operations or Sidekiq jobs. Set to 0 to disable timeouts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitaly_timeout_default ApplicationSettings#gitaly_timeout_default}
    */
    readonly gitalyTimeoutDefault?: number;
    /**
    * Gitaly fast operation timeout, in seconds. Some Gitaly operations are expected to be fast. If they exceed this threshold, there may be a problem with a storage shard and ‘failing fast’ can help maintain the stability of the GitLab instance. Set to 0 to disable timeouts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitaly_timeout_fast ApplicationSettings#gitaly_timeout_fast}
    */
    readonly gitalyTimeoutFast?: number;
    /**
    * Medium Gitaly timeout, in seconds. This should be a value between the Fast and the Default timeout. Set to 0 to disable timeouts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitaly_timeout_medium ApplicationSettings#gitaly_timeout_medium}
    */
    readonly gitalyTimeoutMedium?: number;
    /**
    * Maximum number of Git operations per minute a user can perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitlab_shell_operation_limit ApplicationSettings#gitlab_shell_operation_limit}
    */
    readonly gitlabShellOperationLimit?: number;
    /**
    * Enable Gitpod integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitpod_enabled ApplicationSettings#gitpod_enabled}
    */
    readonly gitpodEnabled?: boolean | cdktf.IResolvable;
    /**
    * The Gitpod instance URL for integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gitpod_url ApplicationSettings#gitpod_url}
    */
    readonly gitpodUrl?: string;
    /**
    * Comma-separated list of IP addresses and CIDRs always allowed for inbound traffic. For example, 1.1.1.1, 2.2.2.0/24.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#globally_allowed_ips ApplicationSettings#globally_allowed_ips}
    */
    readonly globallyAllowedIps?: string;
    /**
    * Enable Grafana.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#grafana_enabled ApplicationSettings#grafana_enabled}
    */
    readonly grafanaEnabled?: boolean | cdktf.IResolvable;
    /**
    * Grafana URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#grafana_url ApplicationSettings#grafana_url}
    */
    readonly grafanaUrl?: string;
    /**
    * Enable Gravatar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#gravatar_enabled ApplicationSettings#gravatar_enabled}
    */
    readonly gravatarEnabled?: boolean | cdktf.IResolvable;
    /**
    * Prevent overrides of default branch protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#group_owners_can_manage_default_branch_protection ApplicationSettings#group_owners_can_manage_default_branch_protection}
    */
    readonly groupOwnersCanManageDefaultBranchProtection?: boolean | cdktf.IResolvable;
    /**
    * Hide marketing-related entries from help.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#help_page_hide_commercial_content ApplicationSettings#help_page_hide_commercial_content}
    */
    readonly helpPageHideCommercialContent?: boolean | cdktf.IResolvable;
    /**
    * Alternate support URL for help page and help dropdown.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#help_page_support_url ApplicationSettings#help_page_support_url}
    */
    readonly helpPageSupportUrl?: string;
    /**
    * Custom text displayed on the help page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#help_page_text ApplicationSettings#help_page_text}
    */
    readonly helpPageText?: string;
    /**
    * GitLab server administrator information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#help_text ApplicationSettings#help_text}
    */
    readonly helpText?: string;
    /**
    * Do not display offers from third parties in GitLab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#hide_third_party_offers ApplicationSettings#hide_third_party_offers}
    */
    readonly hideThirdPartyOffers?: boolean | cdktf.IResolvable;
    /**
    * Redirect to this URL when not logged in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#home_page_url ApplicationSettings#home_page_url}
    */
    readonly homePageUrl?: string;
    /**
    * Enable or disable Git housekeeping. If enabled, requires housekeeping_optimize_repository_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#housekeeping_enabled ApplicationSettings#housekeeping_enabled}
    */
    readonly housekeepingEnabled?: boolean | cdktf.IResolvable;
    /**
    * Number of Git pushes after which an incremental git-repack is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#housekeeping_optimize_repository_period ApplicationSettings#housekeeping_optimize_repository_period}
    */
    readonly housekeepingOptimizeRepositoryPeriod?: number;
    /**
    * Enable HTML emails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#html_emails_enabled ApplicationSettings#html_emails_enabled}
    */
    readonly htmlEmailsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#id ApplicationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Sources to allow project import from. Valid values are: `github`, `bitbucket`, `bitbucket_server`, `fogbugz`, `git`, `gitlab_project`, `gitea`, `manifest`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#import_sources ApplicationSettings#import_sources}
    */
    readonly importSources?: string[];
    /**
    * Enable in-product marketing emails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#in_product_marketing_emails_enabled ApplicationSettings#in_product_marketing_emails_enabled}
    */
    readonly inProductMarketingEmailsEnabled?: boolean | cdktf.IResolvable;
    /**
    * If delete_inactive_projects is true, the time (in months) to wait before deleting inactive projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#inactive_projects_delete_after_months ApplicationSettings#inactive_projects_delete_after_months}
    */
    readonly inactiveProjectsDeleteAfterMonths?: number;
    /**
    * If delete_inactive_projects is true, the minimum repository size for projects to be checked for inactivity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#inactive_projects_min_size_mb ApplicationSettings#inactive_projects_min_size_mb}
    */
    readonly inactiveProjectsMinSizeMb?: number;
    /**
    * If delete_inactive_projects is true, sets the time (in months) to wait before emailing maintainers that the project is scheduled be deleted because it is inactive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#inactive_projects_send_warning_email_after_months ApplicationSettings#inactive_projects_send_warning_email_after_months}
    */
    readonly inactiveProjectsSendWarningEmailAfterMonths?: number;
    /**
    * Whether or not optional metrics are enabled in Service Ping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#include_optional_metrics_in_service_ping ApplicationSettings#include_optional_metrics_in_service_ping}
    */
    readonly includeOptionalMetricsInServicePing?: boolean | cdktf.IResolvable;
    /**
    * Enable Invisible CAPTCHA spam detection during sign-up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#invisible_captcha_enabled ApplicationSettings#invisible_captcha_enabled}
    */
    readonly invisibleCaptchaEnabled?: boolean | cdktf.IResolvable;
    /**
    * Max number of issue creation requests per minute per user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#issues_create_limit ApplicationSettings#issues_create_limit}
    */
    readonly issuesCreateLimit?: number;
    /**
    * ID of the OAuth application used to authenticate with the GitLab for Jira Cloud app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#jira_connect_application_key ApplicationSettings#jira_connect_application_key}
    */
    readonly jiraConnectApplicationKey?: string;
    /**
    * URL of the GitLab instance used as a proxy for the GitLab for Jira Cloud app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#jira_connect_proxy_url ApplicationSettings#jira_connect_proxy_url}
    */
    readonly jiraConnectProxyUrl?: string;
    /**
    * Enable public key storage for the GitLab for Jira Cloud app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#jira_connect_public_key_storage_enabled ApplicationSettings#jira_connect_public_key_storage_enabled}
    */
    readonly jiraConnectPublicKeyStorageEnabled?: boolean | cdktf.IResolvable;
    /**
    * Prevent the deletion of the artifacts from the most recent successful jobs, regardless of the expiry time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#keep_latest_artifact ApplicationSettings#keep_latest_artifact}
    */
    readonly keepLatestArtifact?: boolean | cdktf.IResolvable;
    /**
    * Increase this value when any cached Markdown should be invalidated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#local_markdown_version ApplicationSettings#local_markdown_version}
    */
    readonly localMarkdownVersion?: number;
    /**
    * Indicates whether the GitLab Duo features enabled setting is enforced for all subgroups. Self-managed, Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#lock_duo_features_enabled ApplicationSettings#lock_duo_features_enabled}
    */
    readonly lockDuoFeaturesEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set to true to lock all memberships to LDAP. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#lock_memberships_to_ldap ApplicationSettings#lock_memberships_to_ldap}
    */
    readonly lockMembershipsToLdap?: boolean | cdktf.IResolvable;
    /**
    * Enable Mailgun event receiver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mailgun_events_enabled ApplicationSettings#mailgun_events_enabled}
    */
    readonly mailgunEventsEnabled?: boolean | cdktf.IResolvable;
    /**
    * The Mailgun HTTP webhook signing key for receiving events from webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mailgun_signing_key ApplicationSettings#mailgun_signing_key}
    */
    readonly mailgunSigningKey?: string;
    /**
    * When instance is in maintenance mode, non-administrative users can sign in with read-only access and make read-only API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#maintenance_mode ApplicationSettings#maintenance_mode}
    */
    readonly maintenanceMode?: boolean | cdktf.IResolvable;
    /**
    * Message displayed when instance is in maintenance mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#maintenance_mode_message ApplicationSettings#maintenance_mode_message}
    */
    readonly maintenanceModeMessage?: string;
    /**
    * Use repo.maven.apache.org as a default remote repository when the package is not found in the GitLab Package Registry for Maven. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#maven_package_requests_forwarding ApplicationSettings#maven_package_requests_forwarding}
    */
    readonly mavenPackageRequestsForwarding?: boolean | cdktf.IResolvable;
    /**
    * Maximum artifacts size in MB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_artifacts_size ApplicationSettings#max_artifacts_size}
    */
    readonly maxArtifactsSize?: number;
    /**
    * Limit attachment size in MB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_attachment_size ApplicationSettings#max_attachment_size}
    */
    readonly maxAttachmentSize?: number;
    /**
    * Maximum decompressed archive size in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_decompressed_archive_size ApplicationSettings#max_decompressed_archive_size}
    */
    readonly maxDecompressedArchiveSize?: number;
    /**
    * Maximum export size in MB. 0 for unlimited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_export_size ApplicationSettings#max_export_size}
    */
    readonly maxExportSize?: number;
    /**
    * Maximum remote file size for imports from external object storages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_import_remote_file_size ApplicationSettings#max_import_remote_file_size}
    */
    readonly maxImportRemoteFileSize?: number;
    /**
    * Maximum import size in MB. 0 for unlimited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_import_size ApplicationSettings#max_import_size}
    */
    readonly maxImportSize?: number;
    /**
    * Maximum number of sign-in attempts before locking out the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_login_attempts ApplicationSettings#max_login_attempts}
    */
    readonly maxLoginAttempts?: number;
    /**
    * Maximum number of unique repositories a user can download in the specified time period before they are banned. Maximum: 10,000 repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_number_of_repository_downloads ApplicationSettings#max_number_of_repository_downloads}
    */
    readonly maxNumberOfRepositoryDownloads?: number;
    /**
    * Reporting time period (in seconds). Maximum: 864000 seconds (10 days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_number_of_repository_downloads_within_time_period ApplicationSettings#max_number_of_repository_downloads_within_time_period}
    */
    readonly maxNumberOfRepositoryDownloadsWithinTimePeriod?: number;
    /**
    * Maximum size of pages repositories in MB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_pages_size ApplicationSettings#max_pages_size}
    */
    readonly maxPagesSize?: number;
    /**
    * Maximum allowable lifetime for access tokens in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_personal_access_token_lifetime ApplicationSettings#max_personal_access_token_lifetime}
    */
    readonly maxPersonalAccessTokenLifetime?: number;
    /**
    * Maximum allowable lifetime for SSH keys in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_ssh_key_lifetime ApplicationSettings#max_ssh_key_lifetime}
    */
    readonly maxSshKeyLifetime?: number;
    /**
    * Maximum size in bytes of the Terraform state files. Set this to 0 for unlimited file size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#max_terraform_state_size_bytes ApplicationSettings#max_terraform_state_size_bytes}
    */
    readonly maxTerraformStateSizeBytes?: number;
    /**
    * A method call is only tracked when it takes longer than the given amount of milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#metrics_method_call_threshold ApplicationSettings#metrics_method_call_threshold}
    */
    readonly metricsMethodCallThreshold?: number;
    /**
    * Indicates whether passwords require a minimum length. Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#minimum_password_length ApplicationSettings#minimum_password_length}
    */
    readonly minimumPasswordLength?: number;
    /**
    * Allow repository mirroring to configured by project Maintainers. If disabled, only Administrators can configure repository mirroring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mirror_available ApplicationSettings#mirror_available}
    */
    readonly mirrorAvailable?: boolean | cdktf.IResolvable;
    /**
    * Minimum capacity to be available before scheduling more mirrors preemptively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mirror_capacity_threshold ApplicationSettings#mirror_capacity_threshold}
    */
    readonly mirrorCapacityThreshold?: number;
    /**
    * Maximum number of mirrors that can be synchronizing at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mirror_max_capacity ApplicationSettings#mirror_max_capacity}
    */
    readonly mirrorMaxCapacity?: number;
    /**
    * Maximum time (in minutes) between updates that a mirror can have when scheduled to synchronize.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#mirror_max_delay ApplicationSettings#mirror_max_delay}
    */
    readonly mirrorMaxDelay?: number;
    /**
    * Use npmjs.org as a default remote repository when the package is not found in the GitLab Package Registry for npm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#npm_package_requests_forwarding ApplicationSettings#npm_package_requests_forwarding}
    */
    readonly npmPackageRequestsForwarding?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether to skip metadata URL validation for the NuGet package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#nuget_skip_metadata_url_validation ApplicationSettings#nuget_skip_metadata_url_validation}
    */
    readonly nugetSkipMetadataUrlValidation?: boolean | cdktf.IResolvable;
    /**
    * Define a list of trusted domains or IP addresses to which local requests are allowed when local requests for hooks and services are disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#outbound_local_requests_whitelist ApplicationSettings#outbound_local_requests_whitelist}
    */
    readonly outboundLocalRequestsWhitelist?: string[];
    /**
    * List of package registry metadata to sync. See the list of the available values (https://gitlab.com/gitlab-org/gitlab/-/blob/ace16c20d5da7c4928dd03fb139692638b557fe3/app/models/concerns/enums/package_metadata.rb#L5). Self-managed, Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#package_metadata_purl_types ApplicationSettings#package_metadata_purl_types}
    */
    readonly packageMetadataPurlTypes?: number[];
    /**
    * Enable to allow anyone to pull from Package Registry visible and changeable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#package_registry_allow_anyone_to_pull_option ApplicationSettings#package_registry_allow_anyone_to_pull_option}
    */
    readonly packageRegistryAllowAnyoneToPullOption?: boolean | cdktf.IResolvable;
    /**
    * Number of workers assigned to the packages cleanup policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#package_registry_cleanup_policies_worker_capacity ApplicationSettings#package_registry_cleanup_policies_worker_capacity}
    */
    readonly packageRegistryCleanupPoliciesWorkerCapacity?: number;
    /**
    * Require users to prove ownership of custom domains. Domain verification is an essential security measure for public GitLab sites. Users are required to demonstrate they control a domain before it is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#pages_domain_verification_enabled ApplicationSettings#pages_domain_verification_enabled}
    */
    readonly pagesDomainVerificationEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable authentication for Git over HTTP(S) via a GitLab account password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_authentication_enabled_for_git ApplicationSettings#password_authentication_enabled_for_git}
    */
    readonly passwordAuthenticationEnabledForGit?: boolean | cdktf.IResolvable;
    /**
    * Enable authentication for the web interface via a GitLab account password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_authentication_enabled_for_web ApplicationSettings#password_authentication_enabled_for_web}
    */
    readonly passwordAuthenticationEnabledForWeb?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether passwords require at least one lowercase letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_lowercase_required ApplicationSettings#password_lowercase_required}
    */
    readonly passwordLowercaseRequired?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether passwords require at least one number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_number_required ApplicationSettings#password_number_required}
    */
    readonly passwordNumberRequired?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether passwords require at least one symbol character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_symbol_required ApplicationSettings#password_symbol_required}
    */
    readonly passwordSymbolRequired?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether passwords require at least one uppercase letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#password_uppercase_required ApplicationSettings#password_uppercase_required}
    */
    readonly passwordUppercaseRequired?: boolean | cdktf.IResolvable;
    /**
    * Path of the group that is allowed to toggle the performance bar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#performance_bar_allowed_group_path ApplicationSettings#performance_bar_allowed_group_path}
    */
    readonly performanceBarAllowedGroupPath?: string;
    /**
    * Prefix for all generated personal access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#personal_access_token_prefix ApplicationSettings#personal_access_token_prefix}
    */
    readonly personalAccessTokenPrefix?: string;
    /**
    * Maximum number of pipeline creation requests per minute per user and commit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#pipeline_limit_per_project_user_sha ApplicationSettings#pipeline_limit_per_project_user_sha}
    */
    readonly pipelineLimitPerProjectUserSha?: number;
    /**
    * (If enabled, requires: plantuml_url) Enable PlantUML integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#plantuml_enabled ApplicationSettings#plantuml_enabled}
    */
    readonly plantumlEnabled?: boolean | cdktf.IResolvable;
    /**
    * The PlantUML instance URL for integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#plantuml_url ApplicationSettings#plantuml_url}
    */
    readonly plantumlUrl?: string;
    /**
    * Interval multiplier used by endpoints that perform polling. Set to 0 to disable polling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#polling_interval_multiplier ApplicationSettings#polling_interval_multiplier}
    */
    readonly pollingIntervalMultiplier?: number;
    /**
    * Enable project export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#project_export_enabled ApplicationSettings#project_export_enabled}
    */
    readonly projectExportEnabled?: boolean | cdktf.IResolvable;
    /**
    * Maximum authenticated requests to /project/:id/jobs per minute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#project_jobs_api_rate_limit ApplicationSettings#project_jobs_api_rate_limit}
    */
    readonly projectJobsApiRateLimit?: number;
    /**
    * Max number of requests per 10 minutes per IP address for unauthenticated requests to the list all projects API. To disable throttling set to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#projects_api_rate_limit_unauthenticated ApplicationSettings#projects_api_rate_limit_unauthenticated}
    */
    readonly projectsApiRateLimitUnauthenticated?: number;
    /**
    * Enable Prometheus metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#prometheus_metrics_enabled ApplicationSettings#prometheus_metrics_enabled}
    */
    readonly prometheusMetricsEnabled?: boolean | cdktf.IResolvable;
    /**
    * CI/CD variables are protected by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#protected_ci_variables ApplicationSettings#protected_ci_variables}
    */
    readonly protectedCiVariables?: boolean | cdktf.IResolvable;
    /**
    * Number of changes (branches or tags) in a single push to determine whether individual push events or bulk push events are created. Bulk push events are created if it surpasses that value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#push_event_activities_limit ApplicationSettings#push_event_activities_limit}
    */
    readonly pushEventActivitiesLimit?: number;
    /**
    * Number of changes (branches or tags) in a single push to determine whether webhooks and services fire or not. Webhooks and services aren’t submitted if it surpasses that value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#push_event_hooks_limit ApplicationSettings#push_event_hooks_limit}
    */
    readonly pushEventHooksLimit?: number;
    /**
    * Use pypi.org as a default remote repository when the package is not found in the GitLab Package Registry for PyPI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#pypi_package_requests_forwarding ApplicationSettings#pypi_package_requests_forwarding}
    */
    readonly pypiPackageRequestsForwarding?: boolean | cdktf.IResolvable;
    /**
    * When rate limiting is enabled via the throttle_* settings, send this plain text response when a rate limit is exceeded. ‘Retry later’ is sent if this is blank.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#rate_limiting_response_text ApplicationSettings#rate_limiting_response_text}
    */
    readonly rateLimitingResponseText?: string;
    /**
    * Max number of requests per minute for each raw path. To disable throttling set to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#raw_blob_request_limit ApplicationSettings#raw_blob_request_limit}
    */
    readonly rawBlobRequestLimit?: number;
    /**
    * (If enabled, requires: recaptcha_private_key and recaptcha_site_key) Enable reCAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#recaptcha_enabled ApplicationSettings#recaptcha_enabled}
    */
    readonly recaptchaEnabled?: boolean | cdktf.IResolvable;
    /**
    * Private key for reCAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#recaptcha_private_key ApplicationSettings#recaptcha_private_key}
    */
    readonly recaptchaPrivateKey?: string;
    /**
    * Site key for reCAPTCHA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#recaptcha_site_key ApplicationSettings#recaptcha_site_key}
    */
    readonly recaptchaSiteKey?: string;
    /**
    * Maximum push size (MB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#receive_max_input_size ApplicationSettings#receive_max_input_size}
    */
    readonly receiveMaxInputSize?: number;
    /**
    * Enable receptive mode for GitLab Agents for Kubernetes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#receptive_cluster_agents_enabled ApplicationSettings#receptive_cluster_agents_enabled}
    */
    readonly receptiveClusterAgentsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable Remember me setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#remember_me_enabled ApplicationSettings#remember_me_enabled}
    */
    readonly rememberMeEnabled?: boolean | cdktf.IResolvable;
    /**
    * GitLab periodically runs git fsck in all project and wiki repositories to look for silent disk corruption issues.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#repository_checks_enabled ApplicationSettings#repository_checks_enabled}
    */
    readonly repositoryChecksEnabled?: boolean | cdktf.IResolvable;
    /**
    * Size limit per repository (MB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#repository_size_limit ApplicationSettings#repository_size_limit}
    */
    readonly repositorySizeLimit?: number;
    /**
    * Hash of names taken from gitlab.yml to weights. New projects are created in one of these stores, chosen by a weighted random selection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#repository_storages_weighted ApplicationSettings#repository_storages_weighted}
    */
    readonly repositoryStoragesWeighted?: {
        [key: string]: number;
    };
    /**
    * When enabled, any user that signs up for an account using the registration form is placed under a Pending approval state and has to be explicitly approved by an administrator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#require_admin_approval_after_user_signup ApplicationSettings#require_admin_approval_after_user_signup}
    */
    readonly requireAdminApprovalAfterUserSignup?: boolean | cdktf.IResolvable;
    /**
    * Allow administrators to require 2FA for all administrators on the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#require_admin_two_factor_authentication ApplicationSettings#require_admin_two_factor_authentication}
    */
    readonly requireAdminTwoFactorAuthentication?: boolean | cdktf.IResolvable;
    /**
    * When enabled, users must set an expiration date when creating a group or project access token, or a personal access token owned by a non-service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#require_personal_access_token_expiry ApplicationSettings#require_personal_access_token_expiry}
    */
    readonly requirePersonalAccessTokenExpiry?: boolean | cdktf.IResolvable;
    /**
    * (If enabled, requires: two_factor_grace_period) Require all users to set up Two-factor authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#require_two_factor_authentication ApplicationSettings#require_two_factor_authentication}
    */
    readonly requireTwoFactorAuthentication?: boolean | cdktf.IResolvable;
    /**
    * Selected levels cannot be used by non-Administrator users for groups, projects or snippets. Can take private, internal and public as a parameter. Null means there is no restriction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#restricted_visibility_levels ApplicationSettings#restricted_visibility_levels}
    */
    readonly restrictedVisibilityLevels?: string[];
    /**
    * The minimum allowed bit length of an uploaded RSA key. 0 means no restriction. -1 disables RSA keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#rsa_key_restriction ApplicationSettings#rsa_key_restriction}
    */
    readonly rsaKeyRestriction?: number;
    /**
    * Max number of requests per minute for performing a search while authenticated. To disable throttling set to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#search_rate_limit ApplicationSettings#search_rate_limit}
    */
    readonly searchRateLimit?: number;
    /**
    * Max number of requests per minute for performing a search while unauthenticated. To disable throttling set to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#search_rate_limit_unauthenticated ApplicationSettings#search_rate_limit_unauthenticated}
    */
    readonly searchRateLimitUnauthenticated?: number;
    /**
    * Maximum number of active merge request approval policies per security policy project. Maximum: 20
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#security_approval_policies_limit ApplicationSettings#security_approval_policies_limit}
    */
    readonly securityApprovalPoliciesLimit?: number;
    /**
    * Whether to look up merge request approval policy approval groups globally or within project hierarchies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#security_policy_global_group_approvers_enabled ApplicationSettings#security_policy_global_group_approvers_enabled}
    */
    readonly securityPolicyGlobalGroupApproversEnabled?: boolean | cdktf.IResolvable;
    /**
    * Public security contact information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#security_txt_content ApplicationSettings#security_txt_content}
    */
    readonly securityTxtContent?: string;
    /**
    * Send confirmation email on sign-up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#send_user_confirmation_email ApplicationSettings#send_user_confirmation_email}
    */
    readonly sendUserConfirmationEmail?: boolean | cdktf.IResolvable;
    /**
    * Flag to indicate if token expiry date can be optional for service account users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#service_access_tokens_expiration_enforced ApplicationSettings#service_access_tokens_expiration_enforced}
    */
    readonly serviceAccessTokensExpirationEnforced?: boolean | cdktf.IResolvable;
    /**
    * Session duration in minutes. GitLab restart is required to apply changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#session_expire_delay ApplicationSettings#session_expire_delay}
    */
    readonly sessionExpireDelay?: number;
    /**
    * (If enabled, requires: shared_runners_text and shared_runners_minutes) Enable shared runners for new projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#shared_runners_enabled ApplicationSettings#shared_runners_enabled}
    */
    readonly sharedRunnersEnabled?: boolean | cdktf.IResolvable;
    /**
    * Set the maximum number of CI/CD minutes that a group can use on shared runners per month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#shared_runners_minutes ApplicationSettings#shared_runners_minutes}
    */
    readonly sharedRunnersMinutes?: number;
    /**
    * Shared runners text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#shared_runners_text ApplicationSettings#shared_runners_text}
    */
    readonly sharedRunnersText?: string;
    /**
    * The threshold in bytes at which Sidekiq jobs are compressed before being stored in Redis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sidekiq_job_limiter_compression_threshold_bytes ApplicationSettings#sidekiq_job_limiter_compression_threshold_bytes}
    */
    readonly sidekiqJobLimiterCompressionThresholdBytes?: number;
    /**
    * The threshold in bytes at which Sidekiq jobs are rejected. 0 means do not reject any job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sidekiq_job_limiter_limit_bytes ApplicationSettings#sidekiq_job_limiter_limit_bytes}
    */
    readonly sidekiqJobLimiterLimitBytes?: number;
    /**
    * track or compress. Sets the behavior for Sidekiq job size limits.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sidekiq_job_limiter_mode ApplicationSettings#sidekiq_job_limiter_mode}
    */
    readonly sidekiqJobLimiterMode?: string;
    /**
    * Text on the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sign_in_text ApplicationSettings#sign_in_text}
    */
    readonly signInText?: string;
    /**
    * Enable registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#signup_enabled ApplicationSettings#signup_enabled}
    */
    readonly signupEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable Silent admin exports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#silent_admin_exports_enabled ApplicationSettings#silent_admin_exports_enabled}
    */
    readonly silentAdminExportsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enable Silent mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#silent_mode_enabled ApplicationSettings#silent_mode_enabled}
    */
    readonly silentModeEnabled?: boolean | cdktf.IResolvable;
    /**
    * (If enabled, requires: slack_app_id, slack_app_secret and slack_app_secret) Enable Slack app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#slack_app_enabled ApplicationSettings#slack_app_enabled}
    */
    readonly slackAppEnabled?: boolean | cdktf.IResolvable;
    /**
    * The app ID of the Slack-app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#slack_app_id ApplicationSettings#slack_app_id}
    */
    readonly slackAppId?: string;
    /**
    * The app secret of the Slack-app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#slack_app_secret ApplicationSettings#slack_app_secret}
    */
    readonly slackAppSecret?: string;
    /**
    * The signing secret of the Slack-app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#slack_app_signing_secret ApplicationSettings#slack_app_signing_secret}
    */
    readonly slackAppSigningSecret?: string;
    /**
    * The verification token of the Slack-app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#slack_app_verification_token ApplicationSettings#slack_app_verification_token}
    */
    readonly slackAppVerificationToken?: string;
    /**
    * Max snippet content size in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snippet_size_limit ApplicationSettings#snippet_size_limit}
    */
    readonly snippetSizeLimit?: number;
    /**
    * The Snowplow site name / application ID. (for example, gitlab)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snowplow_app_id ApplicationSettings#snowplow_app_id}
    */
    readonly snowplowAppId?: string;
    /**
    * The Snowplow collector hostname. (for example, snowplow.trx.gitlab.net)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snowplow_collector_hostname ApplicationSettings#snowplow_collector_hostname}
    */
    readonly snowplowCollectorHostname?: string;
    /**
    * The Snowplow cookie domain. (for example, .gitlab.com)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snowplow_cookie_domain ApplicationSettings#snowplow_cookie_domain}
    */
    readonly snowplowCookieDomain?: string;
    /**
    * The Snowplow collector for database events hostname. (for example, db-snowplow.trx.gitlab.net)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snowplow_database_collector_hostname ApplicationSettings#snowplow_database_collector_hostname}
    */
    readonly snowplowDatabaseCollectorHostname?: string;
    /**
    * Enable snowplow tracking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#snowplow_enabled ApplicationSettings#snowplow_enabled}
    */
    readonly snowplowEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enables Sourcegraph integration. If enabled, requires sourcegraph_url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sourcegraph_enabled ApplicationSettings#sourcegraph_enabled}
    */
    readonly sourcegraphEnabled?: boolean | cdktf.IResolvable;
    /**
    * Blocks Sourcegraph from being loaded on private and internal projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sourcegraph_public_only ApplicationSettings#sourcegraph_public_only}
    */
    readonly sourcegraphPublicOnly?: boolean | cdktf.IResolvable;
    /**
    * The Sourcegraph instance URL for integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#sourcegraph_url ApplicationSettings#sourcegraph_url}
    */
    readonly sourcegraphUrl?: string;
    /**
    * API key used by GitLab for accessing the Spam Check service endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#spam_check_api_key ApplicationSettings#spam_check_api_key}
    */
    readonly spamCheckApiKey?: string;
    /**
    * Enables spam checking using external Spam Check API endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#spam_check_endpoint_enabled ApplicationSettings#spam_check_endpoint_enabled}
    */
    readonly spamCheckEndpointEnabled?: boolean | cdktf.IResolvable;
    /**
    * URL of the external Spamcheck service endpoint. Valid URI schemes are grpc or tls. Specifying tls forces communication to be encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#spam_check_endpoint_url ApplicationSettings#spam_check_endpoint_url}
    */
    readonly spamCheckEndpointUrl?: string;
    /**
    * Authentication token for the external storage linked in static_objects_external_storage_url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#static_objects_external_storage_auth_token ApplicationSettings#static_objects_external_storage_auth_token}
    */
    readonly staticObjectsExternalStorageAuthToken?: string;
    /**
    * URL to an external storage for repository static objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#static_objects_external_storage_url ApplicationSettings#static_objects_external_storage_url}
    */
    readonly staticObjectsExternalStorageUrl?: string;
    /**
    * Enable pipeline suggestion banner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#suggest_pipeline_enabled ApplicationSettings#suggest_pipeline_enabled}
    */
    readonly suggestPipelineEnabled?: boolean | cdktf.IResolvable;
    /**
    * Maximum time for web terminal websocket connection (in seconds). Set to 0 for unlimited time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#terminal_max_session_time ApplicationSettings#terminal_max_session_time}
    */
    readonly terminalMaxSessionTime?: number;
    /**
    * (Required by: enforce_terms) Markdown content for the ToS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#terms ApplicationSettings#terms}
    */
    readonly terms?: string;
    /**
    * (If enabled, requires: throttle_authenticated_api_period_in_seconds and throttle_authenticated_api_requests_per_period) Enable authenticated API request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_api_enabled ApplicationSettings#throttle_authenticated_api_enabled}
    */
    readonly throttleAuthenticatedApiEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period (in seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_api_period_in_seconds ApplicationSettings#throttle_authenticated_api_period_in_seconds}
    */
    readonly throttleAuthenticatedApiPeriodInSeconds?: number;
    /**
    * Maximum requests per period per user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_api_requests_per_period ApplicationSettings#throttle_authenticated_api_requests_per_period}
    */
    readonly throttleAuthenticatedApiRequestsPerPeriod?: number;
    /**
    * (If enabled, requires: throttle_authenticated_packages_api_period_in_seconds and throttle_authenticated_packages_api_requests_per_period) Enable authenticated API request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots). View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_packages_api_enabled ApplicationSettings#throttle_authenticated_packages_api_enabled}
    */
    readonly throttleAuthenticatedPackagesApiEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period (in seconds). View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_packages_api_period_in_seconds ApplicationSettings#throttle_authenticated_packages_api_period_in_seconds}
    */
    readonly throttleAuthenticatedPackagesApiPeriodInSeconds?: number;
    /**
    * Maximum requests per period per user. View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_packages_api_requests_per_period ApplicationSettings#throttle_authenticated_packages_api_requests_per_period}
    */
    readonly throttleAuthenticatedPackagesApiRequestsPerPeriod?: number;
    /**
    * (If enabled, requires: throttle_authenticated_web_period_in_seconds and throttle_authenticated_web_requests_per_period) Enable authenticated web request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_web_enabled ApplicationSettings#throttle_authenticated_web_enabled}
    */
    readonly throttleAuthenticatedWebEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period (in seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_web_period_in_seconds ApplicationSettings#throttle_authenticated_web_period_in_seconds}
    */
    readonly throttleAuthenticatedWebPeriodInSeconds?: number;
    /**
    * Maximum requests per period per user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_authenticated_web_requests_per_period ApplicationSettings#throttle_authenticated_web_requests_per_period}
    */
    readonly throttleAuthenticatedWebRequestsPerPeriod?: number;
    /**
    * (If enabled, requires: throttle_unauthenticated_api_period_in_seconds and throttle_unauthenticated_api_requests_per_period) Enable unauthenticated API request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_api_enabled ApplicationSettings#throttle_unauthenticated_api_enabled}
    */
    readonly throttleUnauthenticatedApiEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_api_period_in_seconds ApplicationSettings#throttle_unauthenticated_api_period_in_seconds}
    */
    readonly throttleUnauthenticatedApiPeriodInSeconds?: number;
    /**
    * Max requests per period per IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_api_requests_per_period ApplicationSettings#throttle_unauthenticated_api_requests_per_period}
    */
    readonly throttleUnauthenticatedApiRequestsPerPeriod?: number;
    /**
    * (If enabled, requires: throttle_unauthenticated_packages_api_period_in_seconds and throttle_unauthenticated_packages_api_requests_per_period) Enable authenticated API request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots). View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_packages_api_enabled ApplicationSettings#throttle_unauthenticated_packages_api_enabled}
    */
    readonly throttleUnauthenticatedPackagesApiEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period (in seconds). View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_packages_api_period_in_seconds ApplicationSettings#throttle_unauthenticated_packages_api_period_in_seconds}
    */
    readonly throttleUnauthenticatedPackagesApiPeriodInSeconds?: number;
    /**
    * Maximum requests per period per user. View Package Registry rate limits for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_packages_api_requests_per_period ApplicationSettings#throttle_unauthenticated_packages_api_requests_per_period}
    */
    readonly throttleUnauthenticatedPackagesApiRequestsPerPeriod?: number;
    /**
    * (If enabled, requires: throttle_unauthenticated_web_period_in_seconds and throttle_unauthenticated_web_requests_per_period) Enable unauthenticated web request rate limit. Helps reduce request volume (for example, from crawlers or abusive bots).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_web_enabled ApplicationSettings#throttle_unauthenticated_web_enabled}
    */
    readonly throttleUnauthenticatedWebEnabled?: boolean | cdktf.IResolvable;
    /**
    * Rate limit period in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_web_period_in_seconds ApplicationSettings#throttle_unauthenticated_web_period_in_seconds}
    */
    readonly throttleUnauthenticatedWebPeriodInSeconds?: number;
    /**
    * Max requests per period per IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#throttle_unauthenticated_web_requests_per_period ApplicationSettings#throttle_unauthenticated_web_requests_per_period}
    */
    readonly throttleUnauthenticatedWebRequestsPerPeriod?: number;
    /**
    * Limit display of time tracking units to hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#time_tracking_limit_to_hours ApplicationSettings#time_tracking_limit_to_hours}
    */
    readonly timeTrackingLimitToHours?: boolean | cdktf.IResolvable;
    /**
    * Amount of time (in hours) that users are allowed to skip forced configuration of two-factor authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#two_factor_grace_period ApplicationSettings#two_factor_grace_period}
    */
    readonly twoFactorGracePeriod?: number;
    /**
    * Specifies how many days after sign-up to delete users who have not confirmed their email. Only applicable if delete_unconfirmed_users is set to true. Must be 1 or greater. Self-managed, Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#unconfirmed_users_delete_after_days ApplicationSettings#unconfirmed_users_delete_after_days}
    */
    readonly unconfirmedUsersDeleteAfterDays?: number;
    /**
    * (If enabled, requires: unique_ips_limit_per_user and unique_ips_limit_time_window) Limit sign in from multiple IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#unique_ips_limit_enabled ApplicationSettings#unique_ips_limit_enabled}
    */
    readonly uniqueIpsLimitEnabled?: boolean | cdktf.IResolvable;
    /**
    * Maximum number of IPs per user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#unique_ips_limit_per_user ApplicationSettings#unique_ips_limit_per_user}
    */
    readonly uniqueIpsLimitPerUser?: number;
    /**
    * How many seconds an IP is counted towards the limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#unique_ips_limit_time_window ApplicationSettings#unique_ips_limit_time_window}
    */
    readonly uniqueIpsLimitTimeWindow?: number;
    /**
    * Fetch GitLab Runner release version data from GitLab.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#update_runner_versions_enabled ApplicationSettings#update_runner_versions_enabled}
    */
    readonly updateRunnerVersionsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Every week GitLab reports license usage back to GitLab, Inc.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#usage_ping_enabled ApplicationSettings#usage_ping_enabled}
    */
    readonly usagePingEnabled?: boolean | cdktf.IResolvable;
    /**
    * Enables ClickHouse as a data source for analytics reports. ClickHouse must be configured for this setting to take effect. Available on Premium and Ultimate only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#use_clickhouse_for_analytics ApplicationSettings#use_clickhouse_for_analytics}
    */
    readonly useClickhouseForAnalytics?: boolean | cdktf.IResolvable;
    /**
    * Send an email to users upon account deactivation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_deactivation_emails_enabled ApplicationSettings#user_deactivation_emails_enabled}
    */
    readonly userDeactivationEmailsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Newly registered users are external by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_default_external ApplicationSettings#user_default_external}
    */
    readonly userDefaultExternal?: boolean | cdktf.IResolvable;
    /**
    * Specify an email address regex pattern to identify default internal users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_default_internal_regex ApplicationSettings#user_default_internal_regex}
    */
    readonly userDefaultInternalRegex?: string;
    /**
    * Newly created users have private profile by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_defaults_to_private_profile ApplicationSettings#user_defaults_to_private_profile}
    */
    readonly userDefaultsToPrivateProfile?: boolean | cdktf.IResolvable;
    /**
    * Allow users to register any application to use GitLab as an OAuth provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_oauth_applications ApplicationSettings#user_oauth_applications}
    */
    readonly userOauthApplications?: boolean | cdktf.IResolvable;
    /**
    * When set to false disable the You won't be able to pull or push project code via SSH warning shown to users with no uploaded SSH key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#user_show_add_ssh_key_message ApplicationSettings#user_show_add_ssh_key_message}
    */
    readonly userShowAddSshKeyMessage?: boolean | cdktf.IResolvable;
    /**
    * List of types which are allowed to register a GitLab Runner. Can be [], ['group'], ['project'] or ['group', 'project'].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#valid_runner_registrars ApplicationSettings#valid_runner_registrars}
    */
    readonly validRunnerRegistrars?: string[];
    /**
    * Let GitLab inform you when an update is available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#version_check_enabled ApplicationSettings#version_check_enabled}
    */
    readonly versionCheckEnabled?: boolean | cdktf.IResolvable;
    /**
    * Live Preview (allow live previews of JavaScript projects in the Web IDE using CodeSandbox Live Preview).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#web_ide_clientside_preview_enabled ApplicationSettings#web_ide_clientside_preview_enabled}
    */
    readonly webIdeClientsidePreviewEnabled?: boolean | cdktf.IResolvable;
    /**
    * What's new variant, possible values: all_tiers, current_tier, and disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#whats_new_variant ApplicationSettings#whats_new_variant}
    */
    readonly whatsNewVariant?: string;
    /**
    * Maximum wiki page content size in bytes. The minimum value is 1024 bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#wiki_page_max_content_bytes ApplicationSettings#wiki_page_max_content_bytes}
    */
    readonly wikiPageMaxContentBytes?: number;
    /**
    * default_branch_protection_defaults block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#default_branch_protection_defaults ApplicationSettings#default_branch_protection_defaults}
    */
    readonly defaultBranchProtectionDefaults?: ApplicationSettingsDefaultBranchProtectionDefaults;
}
export interface ApplicationSettingsDefaultBranchProtectionDefaults {
    /**
    * Allow force push for all users with push access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allow_force_push ApplicationSettings#allow_force_push}
    */
    readonly allowForcePush?: boolean | cdktf.IResolvable;
    /**
    * An array of access levels allowed to merge. Supports Developer (30) or Maintainer (40).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allowed_to_merge ApplicationSettings#allowed_to_merge}
    */
    readonly allowedToMerge?: number[];
    /**
    * An array of access levels allowed to push. Supports Developer (30) or Maintainer (40).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#allowed_to_push ApplicationSettings#allowed_to_push}
    */
    readonly allowedToPush?: number[];
    /**
    * Allow developers to initial push.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#developer_can_initial_push ApplicationSettings#developer_can_initial_push}
    */
    readonly developerCanInitialPush?: boolean | cdktf.IResolvable;
}
export declare function applicationSettingsDefaultBranchProtectionDefaultsToTerraform(struct?: ApplicationSettingsDefaultBranchProtectionDefaultsOutputReference | ApplicationSettingsDefaultBranchProtectionDefaults): any;
export declare function applicationSettingsDefaultBranchProtectionDefaultsToHclTerraform(struct?: ApplicationSettingsDefaultBranchProtectionDefaultsOutputReference | ApplicationSettingsDefaultBranchProtectionDefaults): any;
export declare class ApplicationSettingsDefaultBranchProtectionDefaultsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationSettingsDefaultBranchProtectionDefaults | undefined;
    set internalValue(value: ApplicationSettingsDefaultBranchProtectionDefaults | undefined);
    private _allowForcePush?;
    get allowForcePush(): boolean | cdktf.IResolvable;
    set allowForcePush(value: boolean | cdktf.IResolvable);
    resetAllowForcePush(): void;
    get allowForcePushInput(): boolean | cdktf.IResolvable | undefined;
    private _allowedToMerge?;
    get allowedToMerge(): number[];
    set allowedToMerge(value: number[]);
    resetAllowedToMerge(): void;
    get allowedToMergeInput(): number[] | undefined;
    private _allowedToPush?;
    get allowedToPush(): number[];
    set allowedToPush(value: number[]);
    resetAllowedToPush(): void;
    get allowedToPushInput(): number[] | undefined;
    private _developerCanInitialPush?;
    get developerCanInitialPush(): boolean | cdktf.IResolvable;
    set developerCanInitialPush(value: boolean | cdktf.IResolvable);
    resetDeveloperCanInitialPush(): void;
    get developerCanInitialPushInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings gitlab_application_settings}
*/
export declare class ApplicationSettings extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_application_settings";
    /**
    * Generates CDKTF code for importing a ApplicationSettings resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationSettings to import
    * @param importFromId The id of the existing ApplicationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/application_settings gitlab_application_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApplicationSettingsConfig);
    private _abuseNotificationEmail?;
    get abuseNotificationEmail(): string;
    set abuseNotificationEmail(value: string);
    resetAbuseNotificationEmail(): void;
    get abuseNotificationEmailInput(): string | undefined;
    private _adminMode?;
    get adminMode(): boolean | cdktf.IResolvable;
    set adminMode(value: boolean | cdktf.IResolvable);
    resetAdminMode(): void;
    get adminModeInput(): boolean | cdktf.IResolvable | undefined;
    private _afterSignOutPath?;
    get afterSignOutPath(): string;
    set afterSignOutPath(value: string);
    resetAfterSignOutPath(): void;
    get afterSignOutPathInput(): string | undefined;
    private _afterSignUpText?;
    get afterSignUpText(): string;
    set afterSignUpText(value: string);
    resetAfterSignUpText(): void;
    get afterSignUpTextInput(): string | undefined;
    private _akismetApiKey?;
    get akismetApiKey(): string;
    set akismetApiKey(value: string);
    resetAkismetApiKey(): void;
    get akismetApiKeyInput(): string | undefined;
    private _akismetEnabled?;
    get akismetEnabled(): boolean | cdktf.IResolvable;
    set akismetEnabled(value: boolean | cdktf.IResolvable);
    resetAkismetEnabled(): void;
    get akismetEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _allowAccountDeletion?;
    get allowAccountDeletion(): boolean | cdktf.IResolvable;
    set allowAccountDeletion(value: boolean | cdktf.IResolvable);
    resetAllowAccountDeletion(): void;
    get allowAccountDeletionInput(): boolean | cdktf.IResolvable | undefined;
    private _allowGroupOwnersToManageLdap?;
    get allowGroupOwnersToManageLdap(): boolean | cdktf.IResolvable;
    set allowGroupOwnersToManageLdap(value: boolean | cdktf.IResolvable);
    resetAllowGroupOwnersToManageLdap(): void;
    get allowGroupOwnersToManageLdapInput(): boolean | cdktf.IResolvable | undefined;
    private _allowLocalRequestsFromSystemHooks?;
    get allowLocalRequestsFromSystemHooks(): boolean | cdktf.IResolvable;
    set allowLocalRequestsFromSystemHooks(value: boolean | cdktf.IResolvable);
    resetAllowLocalRequestsFromSystemHooks(): void;
    get allowLocalRequestsFromSystemHooksInput(): boolean | cdktf.IResolvable | undefined;
    private _allowLocalRequestsFromWebHooksAndServices?;
    get allowLocalRequestsFromWebHooksAndServices(): boolean | cdktf.IResolvable;
    set allowLocalRequestsFromWebHooksAndServices(value: boolean | cdktf.IResolvable);
    resetAllowLocalRequestsFromWebHooksAndServices(): void;
    get allowLocalRequestsFromWebHooksAndServicesInput(): boolean | cdktf.IResolvable | undefined;
    private _allowProjectCreationForGuestAndBelow?;
    get allowProjectCreationForGuestAndBelow(): boolean | cdktf.IResolvable;
    set allowProjectCreationForGuestAndBelow(value: boolean | cdktf.IResolvable);
    resetAllowProjectCreationForGuestAndBelow(): void;
    get allowProjectCreationForGuestAndBelowInput(): boolean | cdktf.IResolvable | undefined;
    private _allowRunnerRegistrationToken?;
    get allowRunnerRegistrationToken(): boolean | cdktf.IResolvable;
    set allowRunnerRegistrationToken(value: boolean | cdktf.IResolvable);
    resetAllowRunnerRegistrationToken(): void;
    get allowRunnerRegistrationTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _archiveBuildsInHumanReadable?;
    get archiveBuildsInHumanReadable(): string;
    set archiveBuildsInHumanReadable(value: string);
    resetArchiveBuildsInHumanReadable(): void;
    get archiveBuildsInHumanReadableInput(): string | undefined;
    private _asciidocMaxIncludes?;
    get asciidocMaxIncludes(): number;
    set asciidocMaxIncludes(value: number);
    resetAsciidocMaxIncludes(): void;
    get asciidocMaxIncludesInput(): number | undefined;
    private _assetProxyAllowlist?;
    get assetProxyAllowlist(): string[];
    set assetProxyAllowlist(value: string[]);
    resetAssetProxyAllowlist(): void;
    get assetProxyAllowlistInput(): string[] | undefined;
    private _assetProxyEnabled?;
    get assetProxyEnabled(): boolean | cdktf.IResolvable;
    set assetProxyEnabled(value: boolean | cdktf.IResolvable);
    resetAssetProxyEnabled(): void;
    get assetProxyEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _assetProxySecretKey?;
    get assetProxySecretKey(): string;
    set assetProxySecretKey(value: string);
    resetAssetProxySecretKey(): void;
    get assetProxySecretKeyInput(): string | undefined;
    private _assetProxyUrl?;
    get assetProxyUrl(): string;
    set assetProxyUrl(value: string);
    resetAssetProxyUrl(): void;
    get assetProxyUrlInput(): string | undefined;
    private _authorizedKeysEnabled?;
    get authorizedKeysEnabled(): boolean | cdktf.IResolvable;
    set authorizedKeysEnabled(value: boolean | cdktf.IResolvable);
    resetAuthorizedKeysEnabled(): void;
    get authorizedKeysEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _autoBanUserOnExcessiveProjectsDownload?;
    get autoBanUserOnExcessiveProjectsDownload(): boolean | cdktf.IResolvable;
    set autoBanUserOnExcessiveProjectsDownload(value: boolean | cdktf.IResolvable);
    resetAutoBanUserOnExcessiveProjectsDownload(): void;
    get autoBanUserOnExcessiveProjectsDownloadInput(): boolean | cdktf.IResolvable | undefined;
    private _autoDevopsDomain?;
    get autoDevopsDomain(): string;
    set autoDevopsDomain(value: string);
    resetAutoDevopsDomain(): void;
    get autoDevopsDomainInput(): string | undefined;
    private _autoDevopsEnabled?;
    get autoDevopsEnabled(): boolean | cdktf.IResolvable;
    set autoDevopsEnabled(value: boolean | cdktf.IResolvable);
    resetAutoDevopsEnabled(): void;
    get autoDevopsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _automaticPurchasedStorageAllocation?;
    get automaticPurchasedStorageAllocation(): boolean | cdktf.IResolvable;
    set automaticPurchasedStorageAllocation(value: boolean | cdktf.IResolvable);
    resetAutomaticPurchasedStorageAllocation(): void;
    get automaticPurchasedStorageAllocationInput(): boolean | cdktf.IResolvable | undefined;
    private _bulkImportConcurrentPipelineBatchLimit?;
    get bulkImportConcurrentPipelineBatchLimit(): number;
    set bulkImportConcurrentPipelineBatchLimit(value: number);
    resetBulkImportConcurrentPipelineBatchLimit(): void;
    get bulkImportConcurrentPipelineBatchLimitInput(): number | undefined;
    private _bulkImportEnabled?;
    get bulkImportEnabled(): boolean | cdktf.IResolvable;
    set bulkImportEnabled(value: boolean | cdktf.IResolvable);
    resetBulkImportEnabled(): void;
    get bulkImportEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _bulkImportMaxDownloadFileSize?;
    get bulkImportMaxDownloadFileSize(): number;
    set bulkImportMaxDownloadFileSize(value: number);
    resetBulkImportMaxDownloadFileSize(): void;
    get bulkImportMaxDownloadFileSizeInput(): number | undefined;
    private _canCreateGroup?;
    get canCreateGroup(): boolean | cdktf.IResolvable;
    set canCreateGroup(value: boolean | cdktf.IResolvable);
    resetCanCreateGroup(): void;
    get canCreateGroupInput(): boolean | cdktf.IResolvable | undefined;
    private _checkNamespacePlan?;
    get checkNamespacePlan(): boolean | cdktf.IResolvable;
    set checkNamespacePlan(value: boolean | cdktf.IResolvable);
    resetCheckNamespacePlan(): void;
    get checkNamespacePlanInput(): boolean | cdktf.IResolvable | undefined;
    private _ciMaxIncludes?;
    get ciMaxIncludes(): number;
    set ciMaxIncludes(value: number);
    resetCiMaxIncludes(): void;
    get ciMaxIncludesInput(): number | undefined;
    private _ciMaxTotalYamlSizeBytes?;
    get ciMaxTotalYamlSizeBytes(): number;
    set ciMaxTotalYamlSizeBytes(value: number);
    resetCiMaxTotalYamlSizeBytes(): void;
    get ciMaxTotalYamlSizeBytesInput(): number | undefined;
    private _commitEmailHostname?;
    get commitEmailHostname(): string;
    set commitEmailHostname(value: string);
    resetCommitEmailHostname(): void;
    get commitEmailHostnameInput(): string | undefined;
    private _concurrentBitbucketImportJobsLimit?;
    get concurrentBitbucketImportJobsLimit(): number;
    set concurrentBitbucketImportJobsLimit(value: number);
    resetConcurrentBitbucketImportJobsLimit(): void;
    get concurrentBitbucketImportJobsLimitInput(): number | undefined;
    private _concurrentBitbucketServerImportJobsLimit?;
    get concurrentBitbucketServerImportJobsLimit(): number;
    set concurrentBitbucketServerImportJobsLimit(value: number);
    resetConcurrentBitbucketServerImportJobsLimit(): void;
    get concurrentBitbucketServerImportJobsLimitInput(): number | undefined;
    private _concurrentGithubImportJobsLimit?;
    get concurrentGithubImportJobsLimit(): number;
    set concurrentGithubImportJobsLimit(value: number);
    resetConcurrentGithubImportJobsLimit(): void;
    get concurrentGithubImportJobsLimitInput(): number | undefined;
    private _containerExpirationPoliciesEnableHistoricEntries?;
    get containerExpirationPoliciesEnableHistoricEntries(): boolean | cdktf.IResolvable;
    set containerExpirationPoliciesEnableHistoricEntries(value: boolean | cdktf.IResolvable);
    resetContainerExpirationPoliciesEnableHistoricEntries(): void;
    get containerExpirationPoliciesEnableHistoricEntriesInput(): boolean | cdktf.IResolvable | undefined;
    private _containerRegistryCleanupTagsServiceMaxListSize?;
    get containerRegistryCleanupTagsServiceMaxListSize(): number;
    set containerRegistryCleanupTagsServiceMaxListSize(value: number);
    resetContainerRegistryCleanupTagsServiceMaxListSize(): void;
    get containerRegistryCleanupTagsServiceMaxListSizeInput(): number | undefined;
    private _containerRegistryDeleteTagsServiceTimeout?;
    get containerRegistryDeleteTagsServiceTimeout(): number;
    set containerRegistryDeleteTagsServiceTimeout(value: number);
    resetContainerRegistryDeleteTagsServiceTimeout(): void;
    get containerRegistryDeleteTagsServiceTimeoutInput(): number | undefined;
    private _containerRegistryExpirationPoliciesCaching?;
    get containerRegistryExpirationPoliciesCaching(): boolean | cdktf.IResolvable;
    set containerRegistryExpirationPoliciesCaching(value: boolean | cdktf.IResolvable);
    resetContainerRegistryExpirationPoliciesCaching(): void;
    get containerRegistryExpirationPoliciesCachingInput(): boolean | cdktf.IResolvable | undefined;
    private _containerRegistryExpirationPoliciesWorkerCapacity?;
    get containerRegistryExpirationPoliciesWorkerCapacity(): number;
    set containerRegistryExpirationPoliciesWorkerCapacity(value: number);
    resetContainerRegistryExpirationPoliciesWorkerCapacity(): void;
    get containerRegistryExpirationPoliciesWorkerCapacityInput(): number | undefined;
    private _containerRegistryTokenExpireDelay?;
    get containerRegistryTokenExpireDelay(): number;
    set containerRegistryTokenExpireDelay(value: number);
    resetContainerRegistryTokenExpireDelay(): void;
    get containerRegistryTokenExpireDelayInput(): number | undefined;
    private _deactivateDormantUsers?;
    get deactivateDormantUsers(): boolean | cdktf.IResolvable;
    set deactivateDormantUsers(value: boolean | cdktf.IResolvable);
    resetDeactivateDormantUsers(): void;
    get deactivateDormantUsersInput(): boolean | cdktf.IResolvable | undefined;
    private _deactivateDormantUsersPeriod?;
    get deactivateDormantUsersPeriod(): number;
    set deactivateDormantUsersPeriod(value: number);
    resetDeactivateDormantUsersPeriod(): void;
    get deactivateDormantUsersPeriodInput(): number | undefined;
    private _decompressArchiveFileTimeout?;
    get decompressArchiveFileTimeout(): number;
    set decompressArchiveFileTimeout(value: number);
    resetDecompressArchiveFileTimeout(): void;
    get decompressArchiveFileTimeoutInput(): number | undefined;
    private _defaultArtifactsExpireIn?;
    get defaultArtifactsExpireIn(): string;
    set defaultArtifactsExpireIn(value: string);
    resetDefaultArtifactsExpireIn(): void;
    get defaultArtifactsExpireInInput(): string | undefined;
    private _defaultBranchName?;
    get defaultBranchName(): string;
    set defaultBranchName(value: string);
    resetDefaultBranchName(): void;
    get defaultBranchNameInput(): string | undefined;
    private _defaultBranchProtection?;
    get defaultBranchProtection(): number;
    set defaultBranchProtection(value: number);
    resetDefaultBranchProtection(): void;
    get defaultBranchProtectionInput(): number | undefined;
    private _defaultCiConfigPath?;
    get defaultCiConfigPath(): string;
    set defaultCiConfigPath(value: string);
    resetDefaultCiConfigPath(): void;
    get defaultCiConfigPathInput(): string | undefined;
    private _defaultGroupVisibility?;
    get defaultGroupVisibility(): string;
    set defaultGroupVisibility(value: string);
    resetDefaultGroupVisibility(): void;
    get defaultGroupVisibilityInput(): string | undefined;
    private _defaultPreferredLanguage?;
    get defaultPreferredLanguage(): string;
    set defaultPreferredLanguage(value: string);
    resetDefaultPreferredLanguage(): void;
    get defaultPreferredLanguageInput(): string | undefined;
    private _defaultProjectCreation?;
    get defaultProjectCreation(): number;
    set defaultProjectCreation(value: number);
    resetDefaultProjectCreation(): void;
    get defaultProjectCreationInput(): number | undefined;
    private _defaultProjectVisibility?;
    get defaultProjectVisibility(): string;
    set defaultProjectVisibility(value: string);
    resetDefaultProjectVisibility(): void;
    get defaultProjectVisibilityInput(): string | undefined;
    private _defaultProjectsLimit?;
    get defaultProjectsLimit(): number;
    set defaultProjectsLimit(value: number);
    resetDefaultProjectsLimit(): void;
    get defaultProjectsLimitInput(): number | undefined;
    private _defaultSnippetVisibility?;
    get defaultSnippetVisibility(): string;
    set defaultSnippetVisibility(value: string);
    resetDefaultSnippetVisibility(): void;
    get defaultSnippetVisibilityInput(): string | undefined;
    private _defaultSyntaxHighlightingTheme?;
    get defaultSyntaxHighlightingTheme(): number;
    set defaultSyntaxHighlightingTheme(value: number);
    resetDefaultSyntaxHighlightingTheme(): void;
    get defaultSyntaxHighlightingThemeInput(): number | undefined;
    private _deleteInactiveProjects?;
    get deleteInactiveProjects(): boolean | cdktf.IResolvable;
    set deleteInactiveProjects(value: boolean | cdktf.IResolvable);
    resetDeleteInactiveProjects(): void;
    get deleteInactiveProjectsInput(): boolean | cdktf.IResolvable | undefined;
    private _deleteUnconfirmedUsers?;
    get deleteUnconfirmedUsers(): boolean | cdktf.IResolvable;
    set deleteUnconfirmedUsers(value: boolean | cdktf.IResolvable);
    resetDeleteUnconfirmedUsers(): void;
    get deleteUnconfirmedUsersInput(): boolean | cdktf.IResolvable | undefined;
    private _deletionAdjournedPeriod?;
    get deletionAdjournedPeriod(): number;
    set deletionAdjournedPeriod(value: number);
    resetDeletionAdjournedPeriod(): void;
    get deletionAdjournedPeriodInput(): number | undefined;
    private _diagramsnetEnabled?;
    get diagramsnetEnabled(): boolean | cdktf.IResolvable;
    set diagramsnetEnabled(value: boolean | cdktf.IResolvable);
    resetDiagramsnetEnabled(): void;
    get diagramsnetEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _diagramsnetUrl?;
    get diagramsnetUrl(): string;
    set diagramsnetUrl(value: string);
    resetDiagramsnetUrl(): void;
    get diagramsnetUrlInput(): string | undefined;
    private _diffMaxFiles?;
    get diffMaxFiles(): number;
    set diffMaxFiles(value: number);
    resetDiffMaxFiles(): void;
    get diffMaxFilesInput(): number | undefined;
    private _diffMaxLines?;
    get diffMaxLines(): number;
    set diffMaxLines(value: number);
    resetDiffMaxLines(): void;
    get diffMaxLinesInput(): number | undefined;
    private _diffMaxPatchBytes?;
    get diffMaxPatchBytes(): number;
    set diffMaxPatchBytes(value: number);
    resetDiffMaxPatchBytes(): void;
    get diffMaxPatchBytesInput(): number | undefined;
    private _disableAdminOauthScopes?;
    get disableAdminOauthScopes(): boolean | cdktf.IResolvable;
    set disableAdminOauthScopes(value: boolean | cdktf.IResolvable);
    resetDisableAdminOauthScopes(): void;
    get disableAdminOauthScopesInput(): boolean | cdktf.IResolvable | undefined;
    private _disableFeedToken?;
    get disableFeedToken(): boolean | cdktf.IResolvable;
    set disableFeedToken(value: boolean | cdktf.IResolvable);
    resetDisableFeedToken(): void;
    get disableFeedTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _disablePersonalAccessTokens?;
    get disablePersonalAccessTokens(): boolean | cdktf.IResolvable;
    set disablePersonalAccessTokens(value: boolean | cdktf.IResolvable);
    resetDisablePersonalAccessTokens(): void;
    get disablePersonalAccessTokensInput(): boolean | cdktf.IResolvable | undefined;
    private _disabledOauthSignInSources?;
    get disabledOauthSignInSources(): string[];
    set disabledOauthSignInSources(value: string[]);
    resetDisabledOauthSignInSources(): void;
    get disabledOauthSignInSourcesInput(): string[] | undefined;
    private _dnsRebindingProtectionEnabled?;
    get dnsRebindingProtectionEnabled(): boolean | cdktf.IResolvable;
    set dnsRebindingProtectionEnabled(value: boolean | cdktf.IResolvable);
    resetDnsRebindingProtectionEnabled(): void;
    get dnsRebindingProtectionEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _domainAllowlist?;
    get domainAllowlist(): string[];
    set domainAllowlist(value: string[]);
    resetDomainAllowlist(): void;
    get domainAllowlistInput(): string[] | undefined;
    private _domainDenylist?;
    get domainDenylist(): string[];
    set domainDenylist(value: string[]);
    resetDomainDenylist(): void;
    get domainDenylistInput(): string[] | undefined;
    private _domainDenylistEnabled?;
    get domainDenylistEnabled(): boolean | cdktf.IResolvable;
    set domainDenylistEnabled(value: boolean | cdktf.IResolvable);
    resetDomainDenylistEnabled(): void;
    get domainDenylistEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _downstreamPipelineTriggerLimitPerProjectUserSha?;
    get downstreamPipelineTriggerLimitPerProjectUserSha(): number;
    set downstreamPipelineTriggerLimitPerProjectUserSha(value: number);
    resetDownstreamPipelineTriggerLimitPerProjectUserSha(): void;
    get downstreamPipelineTriggerLimitPerProjectUserShaInput(): number | undefined;
    private _dsaKeyRestriction?;
    get dsaKeyRestriction(): number;
    set dsaKeyRestriction(value: number);
    resetDsaKeyRestriction(): void;
    get dsaKeyRestrictionInput(): number | undefined;
    private _duoFeaturesEnabled?;
    get duoFeaturesEnabled(): boolean | cdktf.IResolvable;
    set duoFeaturesEnabled(value: boolean | cdktf.IResolvable);
    resetDuoFeaturesEnabled(): void;
    get duoFeaturesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _ecdsaKeyRestriction?;
    get ecdsaKeyRestriction(): number;
    set ecdsaKeyRestriction(value: number);
    resetEcdsaKeyRestriction(): void;
    get ecdsaKeyRestrictionInput(): number | undefined;
    private _ecdsaSkKeyRestriction?;
    get ecdsaSkKeyRestriction(): number;
    set ecdsaSkKeyRestriction(value: number);
    resetEcdsaSkKeyRestriction(): void;
    get ecdsaSkKeyRestrictionInput(): number | undefined;
    private _ed25519KeyRestriction?;
    get ed25519KeyRestriction(): number;
    set ed25519KeyRestriction(value: number);
    resetEd25519KeyRestriction(): void;
    get ed25519KeyRestrictionInput(): number | undefined;
    private _ed25519SkKeyRestriction?;
    get ed25519SkKeyRestriction(): number;
    set ed25519SkKeyRestriction(value: number);
    resetEd25519SkKeyRestriction(): void;
    get ed25519SkKeyRestrictionInput(): number | undefined;
    private _eksAccessKeyId?;
    get eksAccessKeyId(): string;
    set eksAccessKeyId(value: string);
    resetEksAccessKeyId(): void;
    get eksAccessKeyIdInput(): string | undefined;
    private _eksAccountId?;
    get eksAccountId(): string;
    set eksAccountId(value: string);
    resetEksAccountId(): void;
    get eksAccountIdInput(): string | undefined;
    private _eksIntegrationEnabled?;
    get eksIntegrationEnabled(): boolean | cdktf.IResolvable;
    set eksIntegrationEnabled(value: boolean | cdktf.IResolvable);
    resetEksIntegrationEnabled(): void;
    get eksIntegrationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _eksSecretAccessKey?;
    get eksSecretAccessKey(): string;
    set eksSecretAccessKey(value: string);
    resetEksSecretAccessKey(): void;
    get eksSecretAccessKeyInput(): string | undefined;
    private _elasticsearchAws?;
    get elasticsearchAws(): boolean | cdktf.IResolvable;
    set elasticsearchAws(value: boolean | cdktf.IResolvable);
    resetElasticsearchAws(): void;
    get elasticsearchAwsInput(): boolean | cdktf.IResolvable | undefined;
    private _elasticsearchAwsAccessKey?;
    get elasticsearchAwsAccessKey(): string;
    set elasticsearchAwsAccessKey(value: string);
    resetElasticsearchAwsAccessKey(): void;
    get elasticsearchAwsAccessKeyInput(): string | undefined;
    private _elasticsearchAwsRegion?;
    get elasticsearchAwsRegion(): string;
    set elasticsearchAwsRegion(value: string);
    resetElasticsearchAwsRegion(): void;
    get elasticsearchAwsRegionInput(): string | undefined;
    private _elasticsearchAwsSecretAccessKey?;
    get elasticsearchAwsSecretAccessKey(): string;
    set elasticsearchAwsSecretAccessKey(value: string);
    resetElasticsearchAwsSecretAccessKey(): void;
    get elasticsearchAwsSecretAccessKeyInput(): string | undefined;
    private _elasticsearchIndexedFieldLengthLimit?;
    get elasticsearchIndexedFieldLengthLimit(): number;
    set elasticsearchIndexedFieldLengthLimit(value: number);
    resetElasticsearchIndexedFieldLengthLimit(): void;
    get elasticsearchIndexedFieldLengthLimitInput(): number | undefined;
    private _elasticsearchIndexedFileSizeLimitKb?;
    get elasticsearchIndexedFileSizeLimitKb(): number;
    set elasticsearchIndexedFileSizeLimitKb(value: number);
    resetElasticsearchIndexedFileSizeLimitKb(): void;
    get elasticsearchIndexedFileSizeLimitKbInput(): number | undefined;
    private _elasticsearchIndexing?;
    get elasticsearchIndexing(): boolean | cdktf.IResolvable;
    set elasticsearchIndexing(value: boolean | cdktf.IResolvable);
    resetElasticsearchIndexing(): void;
    get elasticsearchIndexingInput(): boolean | cdktf.IResolvable | undefined;
    private _elasticsearchLimitIndexing?;
    get elasticsearchLimitIndexing(): boolean | cdktf.IResolvable;
    set elasticsearchLimitIndexing(value: boolean | cdktf.IResolvable);
    resetElasticsearchLimitIndexing(): void;
    get elasticsearchLimitIndexingInput(): boolean | cdktf.IResolvable | undefined;
    private _elasticsearchMaxBulkConcurrency?;
    get elasticsearchMaxBulkConcurrency(): number;
    set elasticsearchMaxBulkConcurrency(value: number);
    resetElasticsearchMaxBulkConcurrency(): void;
    get elasticsearchMaxBulkConcurrencyInput(): number | undefined;
    private _elasticsearchMaxBulkSizeMb?;
    get elasticsearchMaxBulkSizeMb(): number;
    set elasticsearchMaxBulkSizeMb(value: number);
    resetElasticsearchMaxBulkSizeMb(): void;
    get elasticsearchMaxBulkSizeMbInput(): number | undefined;
    private _elasticsearchMaxCodeIndexingConcurrency?;
    get elasticsearchMaxCodeIndexingConcurrency(): number;
    set elasticsearchMaxCodeIndexingConcurrency(value: number);
    resetElasticsearchMaxCodeIndexingConcurrency(): void;
    get elasticsearchMaxCodeIndexingConcurrencyInput(): number | undefined;
    private _elasticsearchNamespaceIds?;
    get elasticsearchNamespaceIds(): number[];
    set elasticsearchNamespaceIds(value: number[]);
    resetElasticsearchNamespaceIds(): void;
    get elasticsearchNamespaceIdsInput(): number[] | undefined;
    private _elasticsearchPassword?;
    get elasticsearchPassword(): string;
    set elasticsearchPassword(value: string);
    resetElasticsearchPassword(): void;
    get elasticsearchPasswordInput(): string | undefined;
    private _elasticsearchProjectIds?;
    get elasticsearchProjectIds(): number[];
    set elasticsearchProjectIds(value: number[]);
    resetElasticsearchProjectIds(): void;
    get elasticsearchProjectIdsInput(): number[] | undefined;
    private _elasticsearchRequeueWorkers?;
    get elasticsearchRequeueWorkers(): boolean | cdktf.IResolvable;
    set elasticsearchRequeueWorkers(value: boolean | cdktf.IResolvable);
    resetElasticsearchRequeueWorkers(): void;
    get elasticsearchRequeueWorkersInput(): boolean | cdktf.IResolvable | undefined;
    private _elasticsearchSearch?;
    get elasticsearchSearch(): boolean | cdktf.IResolvable;
    set elasticsearchSearch(value: boolean | cdktf.IResolvable);
    resetElasticsearchSearch(): void;
    get elasticsearchSearchInput(): boolean | cdktf.IResolvable | undefined;
    private _elasticsearchUrl?;
    get elasticsearchUrl(): string[];
    set elasticsearchUrl(value: string[]);
    resetElasticsearchUrl(): void;
    get elasticsearchUrlInput(): string[] | undefined;
    private _elasticsearchUsername?;
    get elasticsearchUsername(): string;
    set elasticsearchUsername(value: string);
    resetElasticsearchUsername(): void;
    get elasticsearchUsernameInput(): string | undefined;
    private _elasticsearchWorkerNumberOfShards?;
    get elasticsearchWorkerNumberOfShards(): number;
    set elasticsearchWorkerNumberOfShards(value: number);
    resetElasticsearchWorkerNumberOfShards(): void;
    get elasticsearchWorkerNumberOfShardsInput(): number | undefined;
    private _emailAdditionalText?;
    get emailAdditionalText(): string;
    set emailAdditionalText(value: string);
    resetEmailAdditionalText(): void;
    get emailAdditionalTextInput(): string | undefined;
    private _emailAuthorInBody?;
    get emailAuthorInBody(): boolean | cdktf.IResolvable;
    set emailAuthorInBody(value: boolean | cdktf.IResolvable);
    resetEmailAuthorInBody(): void;
    get emailAuthorInBodyInput(): boolean | cdktf.IResolvable | undefined;
    private _emailConfirmationSetting?;
    get emailConfirmationSetting(): string;
    set emailConfirmationSetting(value: string);
    resetEmailConfirmationSetting(): void;
    get emailConfirmationSettingInput(): string | undefined;
    private _enableArtifactExternalRedirectWarningPage?;
    get enableArtifactExternalRedirectWarningPage(): boolean | cdktf.IResolvable;
    set enableArtifactExternalRedirectWarningPage(value: boolean | cdktf.IResolvable);
    resetEnableArtifactExternalRedirectWarningPage(): void;
    get enableArtifactExternalRedirectWarningPageInput(): boolean | cdktf.IResolvable | undefined;
    private _enabledGitAccessProtocol?;
    get enabledGitAccessProtocol(): string;
    set enabledGitAccessProtocol(value: string);
    resetEnabledGitAccessProtocol(): void;
    get enabledGitAccessProtocolInput(): string | undefined;
    private _enforceNamespaceStorageLimit?;
    get enforceNamespaceStorageLimit(): boolean | cdktf.IResolvable;
    set enforceNamespaceStorageLimit(value: boolean | cdktf.IResolvable);
    resetEnforceNamespaceStorageLimit(): void;
    get enforceNamespaceStorageLimitInput(): boolean | cdktf.IResolvable | undefined;
    private _enforceTerms?;
    get enforceTerms(): boolean | cdktf.IResolvable;
    set enforceTerms(value: boolean | cdktf.IResolvable);
    resetEnforceTerms(): void;
    get enforceTermsInput(): boolean | cdktf.IResolvable | undefined;
    private _externalAuthClientCert?;
    get externalAuthClientCert(): string;
    set externalAuthClientCert(value: string);
    resetExternalAuthClientCert(): void;
    get externalAuthClientCertInput(): string | undefined;
    private _externalAuthClientKey?;
    get externalAuthClientKey(): string;
    set externalAuthClientKey(value: string);
    resetExternalAuthClientKey(): void;
    get externalAuthClientKeyInput(): string | undefined;
    private _externalAuthClientKeyPass?;
    get externalAuthClientKeyPass(): string;
    set externalAuthClientKeyPass(value: string);
    resetExternalAuthClientKeyPass(): void;
    get externalAuthClientKeyPassInput(): string | undefined;
    private _externalAuthorizationServiceDefaultLabel?;
    get externalAuthorizationServiceDefaultLabel(): string;
    set externalAuthorizationServiceDefaultLabel(value: string);
    resetExternalAuthorizationServiceDefaultLabel(): void;
    get externalAuthorizationServiceDefaultLabelInput(): string | undefined;
    private _externalAuthorizationServiceEnabled?;
    get externalAuthorizationServiceEnabled(): boolean | cdktf.IResolvable;
    set externalAuthorizationServiceEnabled(value: boolean | cdktf.IResolvable);
    resetExternalAuthorizationServiceEnabled(): void;
    get externalAuthorizationServiceEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _externalAuthorizationServiceTimeout?;
    get externalAuthorizationServiceTimeout(): number;
    set externalAuthorizationServiceTimeout(value: number);
    resetExternalAuthorizationServiceTimeout(): void;
    get externalAuthorizationServiceTimeoutInput(): number | undefined;
    private _externalAuthorizationServiceUrl?;
    get externalAuthorizationServiceUrl(): string;
    set externalAuthorizationServiceUrl(value: string);
    resetExternalAuthorizationServiceUrl(): void;
    get externalAuthorizationServiceUrlInput(): string | undefined;
    private _externalPipelineValidationServiceTimeout?;
    get externalPipelineValidationServiceTimeout(): number;
    set externalPipelineValidationServiceTimeout(value: number);
    resetExternalPipelineValidationServiceTimeout(): void;
    get externalPipelineValidationServiceTimeoutInput(): number | undefined;
    private _externalPipelineValidationServiceToken?;
    get externalPipelineValidationServiceToken(): string;
    set externalPipelineValidationServiceToken(value: string);
    resetExternalPipelineValidationServiceToken(): void;
    get externalPipelineValidationServiceTokenInput(): string | undefined;
    private _externalPipelineValidationServiceUrl?;
    get externalPipelineValidationServiceUrl(): string;
    set externalPipelineValidationServiceUrl(value: string);
    resetExternalPipelineValidationServiceUrl(): void;
    get externalPipelineValidationServiceUrlInput(): string | undefined;
    private _failedLoginAttemptsUnlockPeriodInMinutes?;
    get failedLoginAttemptsUnlockPeriodInMinutes(): number;
    set failedLoginAttemptsUnlockPeriodInMinutes(value: number);
    resetFailedLoginAttemptsUnlockPeriodInMinutes(): void;
    get failedLoginAttemptsUnlockPeriodInMinutesInput(): number | undefined;
    private _fileTemplateProjectId?;
    get fileTemplateProjectId(): number;
    set fileTemplateProjectId(value: number);
    resetFileTemplateProjectId(): void;
    get fileTemplateProjectIdInput(): number | undefined;
    private _firstDayOfWeek?;
    get firstDayOfWeek(): number;
    set firstDayOfWeek(value: number);
    resetFirstDayOfWeek(): void;
    get firstDayOfWeekInput(): number | undefined;
    private _geoNodeAllowedIps?;
    get geoNodeAllowedIps(): string;
    set geoNodeAllowedIps(value: string);
    resetGeoNodeAllowedIps(): void;
    get geoNodeAllowedIpsInput(): string | undefined;
    private _geoStatusTimeout?;
    get geoStatusTimeout(): number;
    set geoStatusTimeout(value: number);
    resetGeoStatusTimeout(): void;
    get geoStatusTimeoutInput(): number | undefined;
    private _gitRateLimitUsersAlertlist?;
    get gitRateLimitUsersAlertlist(): number[];
    set gitRateLimitUsersAlertlist(value: number[]);
    resetGitRateLimitUsersAlertlist(): void;
    get gitRateLimitUsersAlertlistInput(): number[] | undefined;
    private _gitRateLimitUsersAllowlist?;
    get gitRateLimitUsersAllowlist(): string[];
    set gitRateLimitUsersAllowlist(value: string[]);
    resetGitRateLimitUsersAllowlist(): void;
    get gitRateLimitUsersAllowlistInput(): string[] | undefined;
    private _gitTwoFactorSessionExpiry?;
    get gitTwoFactorSessionExpiry(): number;
    set gitTwoFactorSessionExpiry(value: number);
    resetGitTwoFactorSessionExpiry(): void;
    get gitTwoFactorSessionExpiryInput(): number | undefined;
    private _gitalyTimeoutDefault?;
    get gitalyTimeoutDefault(): number;
    set gitalyTimeoutDefault(value: number);
    resetGitalyTimeoutDefault(): void;
    get gitalyTimeoutDefaultInput(): number | undefined;
    private _gitalyTimeoutFast?;
    get gitalyTimeoutFast(): number;
    set gitalyTimeoutFast(value: number);
    resetGitalyTimeoutFast(): void;
    get gitalyTimeoutFastInput(): number | undefined;
    private _gitalyTimeoutMedium?;
    get gitalyTimeoutMedium(): number;
    set gitalyTimeoutMedium(value: number);
    resetGitalyTimeoutMedium(): void;
    get gitalyTimeoutMediumInput(): number | undefined;
    get gitlabDedicatedInstance(): cdktf.IResolvable;
    get gitlabEnvironmentToolkitInstance(): cdktf.IResolvable;
    private _gitlabShellOperationLimit?;
    get gitlabShellOperationLimit(): number;
    set gitlabShellOperationLimit(value: number);
    resetGitlabShellOperationLimit(): void;
    get gitlabShellOperationLimitInput(): number | undefined;
    private _gitpodEnabled?;
    get gitpodEnabled(): boolean | cdktf.IResolvable;
    set gitpodEnabled(value: boolean | cdktf.IResolvable);
    resetGitpodEnabled(): void;
    get gitpodEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _gitpodUrl?;
    get gitpodUrl(): string;
    set gitpodUrl(value: string);
    resetGitpodUrl(): void;
    get gitpodUrlInput(): string | undefined;
    private _globallyAllowedIps?;
    get globallyAllowedIps(): string;
    set globallyAllowedIps(value: string);
    resetGloballyAllowedIps(): void;
    get globallyAllowedIpsInput(): string | undefined;
    private _grafanaEnabled?;
    get grafanaEnabled(): boolean | cdktf.IResolvable;
    set grafanaEnabled(value: boolean | cdktf.IResolvable);
    resetGrafanaEnabled(): void;
    get grafanaEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _grafanaUrl?;
    get grafanaUrl(): string;
    set grafanaUrl(value: string);
    resetGrafanaUrl(): void;
    get grafanaUrlInput(): string | undefined;
    private _gravatarEnabled?;
    get gravatarEnabled(): boolean | cdktf.IResolvable;
    set gravatarEnabled(value: boolean | cdktf.IResolvable);
    resetGravatarEnabled(): void;
    get gravatarEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _groupOwnersCanManageDefaultBranchProtection?;
    get groupOwnersCanManageDefaultBranchProtection(): boolean | cdktf.IResolvable;
    set groupOwnersCanManageDefaultBranchProtection(value: boolean | cdktf.IResolvable);
    resetGroupOwnersCanManageDefaultBranchProtection(): void;
    get groupOwnersCanManageDefaultBranchProtectionInput(): boolean | cdktf.IResolvable | undefined;
    private _helpPageHideCommercialContent?;
    get helpPageHideCommercialContent(): boolean | cdktf.IResolvable;
    set helpPageHideCommercialContent(value: boolean | cdktf.IResolvable);
    resetHelpPageHideCommercialContent(): void;
    get helpPageHideCommercialContentInput(): boolean | cdktf.IResolvable | undefined;
    private _helpPageSupportUrl?;
    get helpPageSupportUrl(): string;
    set helpPageSupportUrl(value: string);
    resetHelpPageSupportUrl(): void;
    get helpPageSupportUrlInput(): string | undefined;
    private _helpPageText?;
    get helpPageText(): string;
    set helpPageText(value: string);
    resetHelpPageText(): void;
    get helpPageTextInput(): string | undefined;
    private _helpText?;
    get helpText(): string;
    set helpText(value: string);
    resetHelpText(): void;
    get helpTextInput(): string | undefined;
    private _hideThirdPartyOffers?;
    get hideThirdPartyOffers(): boolean | cdktf.IResolvable;
    set hideThirdPartyOffers(value: boolean | cdktf.IResolvable);
    resetHideThirdPartyOffers(): void;
    get hideThirdPartyOffersInput(): boolean | cdktf.IResolvable | undefined;
    private _homePageUrl?;
    get homePageUrl(): string;
    set homePageUrl(value: string);
    resetHomePageUrl(): void;
    get homePageUrlInput(): string | undefined;
    private _housekeepingEnabled?;
    get housekeepingEnabled(): boolean | cdktf.IResolvable;
    set housekeepingEnabled(value: boolean | cdktf.IResolvable);
    resetHousekeepingEnabled(): void;
    get housekeepingEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _housekeepingOptimizeRepositoryPeriod?;
    get housekeepingOptimizeRepositoryPeriod(): number;
    set housekeepingOptimizeRepositoryPeriod(value: number);
    resetHousekeepingOptimizeRepositoryPeriod(): void;
    get housekeepingOptimizeRepositoryPeriodInput(): number | undefined;
    private _htmlEmailsEnabled?;
    get htmlEmailsEnabled(): boolean | cdktf.IResolvable;
    set htmlEmailsEnabled(value: boolean | cdktf.IResolvable);
    resetHtmlEmailsEnabled(): void;
    get htmlEmailsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importSources?;
    get importSources(): string[];
    set importSources(value: string[]);
    resetImportSources(): void;
    get importSourcesInput(): string[] | undefined;
    private _inProductMarketingEmailsEnabled?;
    get inProductMarketingEmailsEnabled(): boolean | cdktf.IResolvable;
    set inProductMarketingEmailsEnabled(value: boolean | cdktf.IResolvable);
    resetInProductMarketingEmailsEnabled(): void;
    get inProductMarketingEmailsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _inactiveProjectsDeleteAfterMonths?;
    get inactiveProjectsDeleteAfterMonths(): number;
    set inactiveProjectsDeleteAfterMonths(value: number);
    resetInactiveProjectsDeleteAfterMonths(): void;
    get inactiveProjectsDeleteAfterMonthsInput(): number | undefined;
    private _inactiveProjectsMinSizeMb?;
    get inactiveProjectsMinSizeMb(): number;
    set inactiveProjectsMinSizeMb(value: number);
    resetInactiveProjectsMinSizeMb(): void;
    get inactiveProjectsMinSizeMbInput(): number | undefined;
    private _inactiveProjectsSendWarningEmailAfterMonths?;
    get inactiveProjectsSendWarningEmailAfterMonths(): number;
    set inactiveProjectsSendWarningEmailAfterMonths(value: number);
    resetInactiveProjectsSendWarningEmailAfterMonths(): void;
    get inactiveProjectsSendWarningEmailAfterMonthsInput(): number | undefined;
    private _includeOptionalMetricsInServicePing?;
    get includeOptionalMetricsInServicePing(): boolean | cdktf.IResolvable;
    set includeOptionalMetricsInServicePing(value: boolean | cdktf.IResolvable);
    resetIncludeOptionalMetricsInServicePing(): void;
    get includeOptionalMetricsInServicePingInput(): boolean | cdktf.IResolvable | undefined;
    private _invisibleCaptchaEnabled?;
    get invisibleCaptchaEnabled(): boolean | cdktf.IResolvable;
    set invisibleCaptchaEnabled(value: boolean | cdktf.IResolvable);
    resetInvisibleCaptchaEnabled(): void;
    get invisibleCaptchaEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _issuesCreateLimit?;
    get issuesCreateLimit(): number;
    set issuesCreateLimit(value: number);
    resetIssuesCreateLimit(): void;
    get issuesCreateLimitInput(): number | undefined;
    private _jiraConnectApplicationKey?;
    get jiraConnectApplicationKey(): string;
    set jiraConnectApplicationKey(value: string);
    resetJiraConnectApplicationKey(): void;
    get jiraConnectApplicationKeyInput(): string | undefined;
    private _jiraConnectProxyUrl?;
    get jiraConnectProxyUrl(): string;
    set jiraConnectProxyUrl(value: string);
    resetJiraConnectProxyUrl(): void;
    get jiraConnectProxyUrlInput(): string | undefined;
    private _jiraConnectPublicKeyStorageEnabled?;
    get jiraConnectPublicKeyStorageEnabled(): boolean | cdktf.IResolvable;
    set jiraConnectPublicKeyStorageEnabled(value: boolean | cdktf.IResolvable);
    resetJiraConnectPublicKeyStorageEnabled(): void;
    get jiraConnectPublicKeyStorageEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _keepLatestArtifact?;
    get keepLatestArtifact(): boolean | cdktf.IResolvable;
    set keepLatestArtifact(value: boolean | cdktf.IResolvable);
    resetKeepLatestArtifact(): void;
    get keepLatestArtifactInput(): boolean | cdktf.IResolvable | undefined;
    private _localMarkdownVersion?;
    get localMarkdownVersion(): number;
    set localMarkdownVersion(value: number);
    resetLocalMarkdownVersion(): void;
    get localMarkdownVersionInput(): number | undefined;
    private _lockDuoFeaturesEnabled?;
    get lockDuoFeaturesEnabled(): boolean | cdktf.IResolvable;
    set lockDuoFeaturesEnabled(value: boolean | cdktf.IResolvable);
    resetLockDuoFeaturesEnabled(): void;
    get lockDuoFeaturesEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _lockMembershipsToLdap?;
    get lockMembershipsToLdap(): boolean | cdktf.IResolvable;
    set lockMembershipsToLdap(value: boolean | cdktf.IResolvable);
    resetLockMembershipsToLdap(): void;
    get lockMembershipsToLdapInput(): boolean | cdktf.IResolvable | undefined;
    private _mailgunEventsEnabled?;
    get mailgunEventsEnabled(): boolean | cdktf.IResolvable;
    set mailgunEventsEnabled(value: boolean | cdktf.IResolvable);
    resetMailgunEventsEnabled(): void;
    get mailgunEventsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _mailgunSigningKey?;
    get mailgunSigningKey(): string;
    set mailgunSigningKey(value: string);
    resetMailgunSigningKey(): void;
    get mailgunSigningKeyInput(): string | undefined;
    private _maintenanceMode?;
    get maintenanceMode(): boolean | cdktf.IResolvable;
    set maintenanceMode(value: boolean | cdktf.IResolvable);
    resetMaintenanceMode(): void;
    get maintenanceModeInput(): boolean | cdktf.IResolvable | undefined;
    private _maintenanceModeMessage?;
    get maintenanceModeMessage(): string;
    set maintenanceModeMessage(value: string);
    resetMaintenanceModeMessage(): void;
    get maintenanceModeMessageInput(): string | undefined;
    private _mavenPackageRequestsForwarding?;
    get mavenPackageRequestsForwarding(): boolean | cdktf.IResolvable;
    set mavenPackageRequestsForwarding(value: boolean | cdktf.IResolvable);
    resetMavenPackageRequestsForwarding(): void;
    get mavenPackageRequestsForwardingInput(): boolean | cdktf.IResolvable | undefined;
    private _maxArtifactsSize?;
    get maxArtifactsSize(): number;
    set maxArtifactsSize(value: number);
    resetMaxArtifactsSize(): void;
    get maxArtifactsSizeInput(): number | undefined;
    private _maxAttachmentSize?;
    get maxAttachmentSize(): number;
    set maxAttachmentSize(value: number);
    resetMaxAttachmentSize(): void;
    get maxAttachmentSizeInput(): number | undefined;
    private _maxDecompressedArchiveSize?;
    get maxDecompressedArchiveSize(): number;
    set maxDecompressedArchiveSize(value: number);
    resetMaxDecompressedArchiveSize(): void;
    get maxDecompressedArchiveSizeInput(): number | undefined;
    private _maxExportSize?;
    get maxExportSize(): number;
    set maxExportSize(value: number);
    resetMaxExportSize(): void;
    get maxExportSizeInput(): number | undefined;
    private _maxImportRemoteFileSize?;
    get maxImportRemoteFileSize(): number;
    set maxImportRemoteFileSize(value: number);
    resetMaxImportRemoteFileSize(): void;
    get maxImportRemoteFileSizeInput(): number | undefined;
    private _maxImportSize?;
    get maxImportSize(): number;
    set maxImportSize(value: number);
    resetMaxImportSize(): void;
    get maxImportSizeInput(): number | undefined;
    private _maxLoginAttempts?;
    get maxLoginAttempts(): number;
    set maxLoginAttempts(value: number);
    resetMaxLoginAttempts(): void;
    get maxLoginAttemptsInput(): number | undefined;
    private _maxNumberOfRepositoryDownloads?;
    get maxNumberOfRepositoryDownloads(): number;
    set maxNumberOfRepositoryDownloads(value: number);
    resetMaxNumberOfRepositoryDownloads(): void;
    get maxNumberOfRepositoryDownloadsInput(): number | undefined;
    private _maxNumberOfRepositoryDownloadsWithinTimePeriod?;
    get maxNumberOfRepositoryDownloadsWithinTimePeriod(): number;
    set maxNumberOfRepositoryDownloadsWithinTimePeriod(value: number);
    resetMaxNumberOfRepositoryDownloadsWithinTimePeriod(): void;
    get maxNumberOfRepositoryDownloadsWithinTimePeriodInput(): number | undefined;
    private _maxPagesSize?;
    get maxPagesSize(): number;
    set maxPagesSize(value: number);
    resetMaxPagesSize(): void;
    get maxPagesSizeInput(): number | undefined;
    private _maxPersonalAccessTokenLifetime?;
    get maxPersonalAccessTokenLifetime(): number;
    set maxPersonalAccessTokenLifetime(value: number);
    resetMaxPersonalAccessTokenLifetime(): void;
    get maxPersonalAccessTokenLifetimeInput(): number | undefined;
    private _maxSshKeyLifetime?;
    get maxSshKeyLifetime(): number;
    set maxSshKeyLifetime(value: number);
    resetMaxSshKeyLifetime(): void;
    get maxSshKeyLifetimeInput(): number | undefined;
    private _maxTerraformStateSizeBytes?;
    get maxTerraformStateSizeBytes(): number;
    set maxTerraformStateSizeBytes(value: number);
    resetMaxTerraformStateSizeBytes(): void;
    get maxTerraformStateSizeBytesInput(): number | undefined;
    private _metricsMethodCallThreshold?;
    get metricsMethodCallThreshold(): number;
    set metricsMethodCallThreshold(value: number);
    resetMetricsMethodCallThreshold(): void;
    get metricsMethodCallThresholdInput(): number | undefined;
    private _minimumPasswordLength?;
    get minimumPasswordLength(): number;
    set minimumPasswordLength(value: number);
    resetMinimumPasswordLength(): void;
    get minimumPasswordLengthInput(): number | undefined;
    private _mirrorAvailable?;
    get mirrorAvailable(): boolean | cdktf.IResolvable;
    set mirrorAvailable(value: boolean | cdktf.IResolvable);
    resetMirrorAvailable(): void;
    get mirrorAvailableInput(): boolean | cdktf.IResolvable | undefined;
    private _mirrorCapacityThreshold?;
    get mirrorCapacityThreshold(): number;
    set mirrorCapacityThreshold(value: number);
    resetMirrorCapacityThreshold(): void;
    get mirrorCapacityThresholdInput(): number | undefined;
    private _mirrorMaxCapacity?;
    get mirrorMaxCapacity(): number;
    set mirrorMaxCapacity(value: number);
    resetMirrorMaxCapacity(): void;
    get mirrorMaxCapacityInput(): number | undefined;
    private _mirrorMaxDelay?;
    get mirrorMaxDelay(): number;
    set mirrorMaxDelay(value: number);
    resetMirrorMaxDelay(): void;
    get mirrorMaxDelayInput(): number | undefined;
    private _npmPackageRequestsForwarding?;
    get npmPackageRequestsForwarding(): boolean | cdktf.IResolvable;
    set npmPackageRequestsForwarding(value: boolean | cdktf.IResolvable);
    resetNpmPackageRequestsForwarding(): void;
    get npmPackageRequestsForwardingInput(): boolean | cdktf.IResolvable | undefined;
    private _nugetSkipMetadataUrlValidation?;
    get nugetSkipMetadataUrlValidation(): boolean | cdktf.IResolvable;
    set nugetSkipMetadataUrlValidation(value: boolean | cdktf.IResolvable);
    resetNugetSkipMetadataUrlValidation(): void;
    get nugetSkipMetadataUrlValidationInput(): boolean | cdktf.IResolvable | undefined;
    private _outboundLocalRequestsWhitelist?;
    get outboundLocalRequestsWhitelist(): string[];
    set outboundLocalRequestsWhitelist(value: string[]);
    resetOutboundLocalRequestsWhitelist(): void;
    get outboundLocalRequestsWhitelistInput(): string[] | undefined;
    private _packageMetadataPurlTypes?;
    get packageMetadataPurlTypes(): number[];
    set packageMetadataPurlTypes(value: number[]);
    resetPackageMetadataPurlTypes(): void;
    get packageMetadataPurlTypesInput(): number[] | undefined;
    private _packageRegistryAllowAnyoneToPullOption?;
    get packageRegistryAllowAnyoneToPullOption(): boolean | cdktf.IResolvable;
    set packageRegistryAllowAnyoneToPullOption(value: boolean | cdktf.IResolvable);
    resetPackageRegistryAllowAnyoneToPullOption(): void;
    get packageRegistryAllowAnyoneToPullOptionInput(): boolean | cdktf.IResolvable | undefined;
    private _packageRegistryCleanupPoliciesWorkerCapacity?;
    get packageRegistryCleanupPoliciesWorkerCapacity(): number;
    set packageRegistryCleanupPoliciesWorkerCapacity(value: number);
    resetPackageRegistryCleanupPoliciesWorkerCapacity(): void;
    get packageRegistryCleanupPoliciesWorkerCapacityInput(): number | undefined;
    private _pagesDomainVerificationEnabled?;
    get pagesDomainVerificationEnabled(): boolean | cdktf.IResolvable;
    set pagesDomainVerificationEnabled(value: boolean | cdktf.IResolvable);
    resetPagesDomainVerificationEnabled(): void;
    get pagesDomainVerificationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordAuthenticationEnabledForGit?;
    get passwordAuthenticationEnabledForGit(): boolean | cdktf.IResolvable;
    set passwordAuthenticationEnabledForGit(value: boolean | cdktf.IResolvable);
    resetPasswordAuthenticationEnabledForGit(): void;
    get passwordAuthenticationEnabledForGitInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordAuthenticationEnabledForWeb?;
    get passwordAuthenticationEnabledForWeb(): boolean | cdktf.IResolvable;
    set passwordAuthenticationEnabledForWeb(value: boolean | cdktf.IResolvable);
    resetPasswordAuthenticationEnabledForWeb(): void;
    get passwordAuthenticationEnabledForWebInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordLowercaseRequired?;
    get passwordLowercaseRequired(): boolean | cdktf.IResolvable;
    set passwordLowercaseRequired(value: boolean | cdktf.IResolvable);
    resetPasswordLowercaseRequired(): void;
    get passwordLowercaseRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordNumberRequired?;
    get passwordNumberRequired(): boolean | cdktf.IResolvable;
    set passwordNumberRequired(value: boolean | cdktf.IResolvable);
    resetPasswordNumberRequired(): void;
    get passwordNumberRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordSymbolRequired?;
    get passwordSymbolRequired(): boolean | cdktf.IResolvable;
    set passwordSymbolRequired(value: boolean | cdktf.IResolvable);
    resetPasswordSymbolRequired(): void;
    get passwordSymbolRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _passwordUppercaseRequired?;
    get passwordUppercaseRequired(): boolean | cdktf.IResolvable;
    set passwordUppercaseRequired(value: boolean | cdktf.IResolvable);
    resetPasswordUppercaseRequired(): void;
    get passwordUppercaseRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _performanceBarAllowedGroupPath?;
    get performanceBarAllowedGroupPath(): string;
    set performanceBarAllowedGroupPath(value: string);
    resetPerformanceBarAllowedGroupPath(): void;
    get performanceBarAllowedGroupPathInput(): string | undefined;
    private _personalAccessTokenPrefix?;
    get personalAccessTokenPrefix(): string;
    set personalAccessTokenPrefix(value: string);
    resetPersonalAccessTokenPrefix(): void;
    get personalAccessTokenPrefixInput(): string | undefined;
    private _pipelineLimitPerProjectUserSha?;
    get pipelineLimitPerProjectUserSha(): number;
    set pipelineLimitPerProjectUserSha(value: number);
    resetPipelineLimitPerProjectUserSha(): void;
    get pipelineLimitPerProjectUserShaInput(): number | undefined;
    private _plantumlEnabled?;
    get plantumlEnabled(): boolean | cdktf.IResolvable;
    set plantumlEnabled(value: boolean | cdktf.IResolvable);
    resetPlantumlEnabled(): void;
    get plantumlEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _plantumlUrl?;
    get plantumlUrl(): string;
    set plantumlUrl(value: string);
    resetPlantumlUrl(): void;
    get plantumlUrlInput(): string | undefined;
    private _pollingIntervalMultiplier?;
    get pollingIntervalMultiplier(): number;
    set pollingIntervalMultiplier(value: number);
    resetPollingIntervalMultiplier(): void;
    get pollingIntervalMultiplierInput(): number | undefined;
    private _projectExportEnabled?;
    get projectExportEnabled(): boolean | cdktf.IResolvable;
    set projectExportEnabled(value: boolean | cdktf.IResolvable);
    resetProjectExportEnabled(): void;
    get projectExportEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _projectJobsApiRateLimit?;
    get projectJobsApiRateLimit(): number;
    set projectJobsApiRateLimit(value: number);
    resetProjectJobsApiRateLimit(): void;
    get projectJobsApiRateLimitInput(): number | undefined;
    private _projectsApiRateLimitUnauthenticated?;
    get projectsApiRateLimitUnauthenticated(): number;
    set projectsApiRateLimitUnauthenticated(value: number);
    resetProjectsApiRateLimitUnauthenticated(): void;
    get projectsApiRateLimitUnauthenticatedInput(): number | undefined;
    private _prometheusMetricsEnabled?;
    get prometheusMetricsEnabled(): boolean | cdktf.IResolvable;
    set prometheusMetricsEnabled(value: boolean | cdktf.IResolvable);
    resetPrometheusMetricsEnabled(): void;
    get prometheusMetricsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _protectedCiVariables?;
    get protectedCiVariables(): boolean | cdktf.IResolvable;
    set protectedCiVariables(value: boolean | cdktf.IResolvable);
    resetProtectedCiVariables(): void;
    get protectedCiVariablesInput(): boolean | cdktf.IResolvable | undefined;
    private _pushEventActivitiesLimit?;
    get pushEventActivitiesLimit(): number;
    set pushEventActivitiesLimit(value: number);
    resetPushEventActivitiesLimit(): void;
    get pushEventActivitiesLimitInput(): number | undefined;
    private _pushEventHooksLimit?;
    get pushEventHooksLimit(): number;
    set pushEventHooksLimit(value: number);
    resetPushEventHooksLimit(): void;
    get pushEventHooksLimitInput(): number | undefined;
    private _pypiPackageRequestsForwarding?;
    get pypiPackageRequestsForwarding(): boolean | cdktf.IResolvable;
    set pypiPackageRequestsForwarding(value: boolean | cdktf.IResolvable);
    resetPypiPackageRequestsForwarding(): void;
    get pypiPackageRequestsForwardingInput(): boolean | cdktf.IResolvable | undefined;
    private _rateLimitingResponseText?;
    get rateLimitingResponseText(): string;
    set rateLimitingResponseText(value: string);
    resetRateLimitingResponseText(): void;
    get rateLimitingResponseTextInput(): string | undefined;
    private _rawBlobRequestLimit?;
    get rawBlobRequestLimit(): number;
    set rawBlobRequestLimit(value: number);
    resetRawBlobRequestLimit(): void;
    get rawBlobRequestLimitInput(): number | undefined;
    private _recaptchaEnabled?;
    get recaptchaEnabled(): boolean | cdktf.IResolvable;
    set recaptchaEnabled(value: boolean | cdktf.IResolvable);
    resetRecaptchaEnabled(): void;
    get recaptchaEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _recaptchaPrivateKey?;
    get recaptchaPrivateKey(): string;
    set recaptchaPrivateKey(value: string);
    resetRecaptchaPrivateKey(): void;
    get recaptchaPrivateKeyInput(): string | undefined;
    private _recaptchaSiteKey?;
    get recaptchaSiteKey(): string;
    set recaptchaSiteKey(value: string);
    resetRecaptchaSiteKey(): void;
    get recaptchaSiteKeyInput(): string | undefined;
    private _receiveMaxInputSize?;
    get receiveMaxInputSize(): number;
    set receiveMaxInputSize(value: number);
    resetReceiveMaxInputSize(): void;
    get receiveMaxInputSizeInput(): number | undefined;
    private _receptiveClusterAgentsEnabled?;
    get receptiveClusterAgentsEnabled(): boolean | cdktf.IResolvable;
    set receptiveClusterAgentsEnabled(value: boolean | cdktf.IResolvable);
    resetReceptiveClusterAgentsEnabled(): void;
    get receptiveClusterAgentsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _rememberMeEnabled?;
    get rememberMeEnabled(): boolean | cdktf.IResolvable;
    set rememberMeEnabled(value: boolean | cdktf.IResolvable);
    resetRememberMeEnabled(): void;
    get rememberMeEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _repositoryChecksEnabled?;
    get repositoryChecksEnabled(): boolean | cdktf.IResolvable;
    set repositoryChecksEnabled(value: boolean | cdktf.IResolvable);
    resetRepositoryChecksEnabled(): void;
    get repositoryChecksEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _repositorySizeLimit?;
    get repositorySizeLimit(): number;
    set repositorySizeLimit(value: number);
    resetRepositorySizeLimit(): void;
    get repositorySizeLimitInput(): number | undefined;
    private _repositoryStoragesWeighted?;
    get repositoryStoragesWeighted(): {
        [key: string]: number;
    };
    set repositoryStoragesWeighted(value: {
        [key: string]: number;
    });
    resetRepositoryStoragesWeighted(): void;
    get repositoryStoragesWeightedInput(): {
        [key: string]: number;
    } | undefined;
    private _requireAdminApprovalAfterUserSignup?;
    get requireAdminApprovalAfterUserSignup(): boolean | cdktf.IResolvable;
    set requireAdminApprovalAfterUserSignup(value: boolean | cdktf.IResolvable);
    resetRequireAdminApprovalAfterUserSignup(): void;
    get requireAdminApprovalAfterUserSignupInput(): boolean | cdktf.IResolvable | undefined;
    private _requireAdminTwoFactorAuthentication?;
    get requireAdminTwoFactorAuthentication(): boolean | cdktf.IResolvable;
    set requireAdminTwoFactorAuthentication(value: boolean | cdktf.IResolvable);
    resetRequireAdminTwoFactorAuthentication(): void;
    get requireAdminTwoFactorAuthenticationInput(): boolean | cdktf.IResolvable | undefined;
    private _requirePersonalAccessTokenExpiry?;
    get requirePersonalAccessTokenExpiry(): boolean | cdktf.IResolvable;
    set requirePersonalAccessTokenExpiry(value: boolean | cdktf.IResolvable);
    resetRequirePersonalAccessTokenExpiry(): void;
    get requirePersonalAccessTokenExpiryInput(): boolean | cdktf.IResolvable | undefined;
    private _requireTwoFactorAuthentication?;
    get requireTwoFactorAuthentication(): boolean | cdktf.IResolvable;
    set requireTwoFactorAuthentication(value: boolean | cdktf.IResolvable);
    resetRequireTwoFactorAuthentication(): void;
    get requireTwoFactorAuthenticationInput(): boolean | cdktf.IResolvable | undefined;
    private _restrictedVisibilityLevels?;
    get restrictedVisibilityLevels(): string[];
    set restrictedVisibilityLevels(value: string[]);
    resetRestrictedVisibilityLevels(): void;
    get restrictedVisibilityLevelsInput(): string[] | undefined;
    private _rsaKeyRestriction?;
    get rsaKeyRestriction(): number;
    set rsaKeyRestriction(value: number);
    resetRsaKeyRestriction(): void;
    get rsaKeyRestrictionInput(): number | undefined;
    private _searchRateLimit?;
    get searchRateLimit(): number;
    set searchRateLimit(value: number);
    resetSearchRateLimit(): void;
    get searchRateLimitInput(): number | undefined;
    private _searchRateLimitUnauthenticated?;
    get searchRateLimitUnauthenticated(): number;
    set searchRateLimitUnauthenticated(value: number);
    resetSearchRateLimitUnauthenticated(): void;
    get searchRateLimitUnauthenticatedInput(): number | undefined;
    private _securityApprovalPoliciesLimit?;
    get securityApprovalPoliciesLimit(): number;
    set securityApprovalPoliciesLimit(value: number);
    resetSecurityApprovalPoliciesLimit(): void;
    get securityApprovalPoliciesLimitInput(): number | undefined;
    private _securityPolicyGlobalGroupApproversEnabled?;
    get securityPolicyGlobalGroupApproversEnabled(): boolean | cdktf.IResolvable;
    set securityPolicyGlobalGroupApproversEnabled(value: boolean | cdktf.IResolvable);
    resetSecurityPolicyGlobalGroupApproversEnabled(): void;
    get securityPolicyGlobalGroupApproversEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _securityTxtContent?;
    get securityTxtContent(): string;
    set securityTxtContent(value: string);
    resetSecurityTxtContent(): void;
    get securityTxtContentInput(): string | undefined;
    private _sendUserConfirmationEmail?;
    get sendUserConfirmationEmail(): boolean | cdktf.IResolvable;
    set sendUserConfirmationEmail(value: boolean | cdktf.IResolvable);
    resetSendUserConfirmationEmail(): void;
    get sendUserConfirmationEmailInput(): boolean | cdktf.IResolvable | undefined;
    private _serviceAccessTokensExpirationEnforced?;
    get serviceAccessTokensExpirationEnforced(): boolean | cdktf.IResolvable;
    set serviceAccessTokensExpirationEnforced(value: boolean | cdktf.IResolvable);
    resetServiceAccessTokensExpirationEnforced(): void;
    get serviceAccessTokensExpirationEnforcedInput(): boolean | cdktf.IResolvable | undefined;
    private _sessionExpireDelay?;
    get sessionExpireDelay(): number;
    set sessionExpireDelay(value: number);
    resetSessionExpireDelay(): void;
    get sessionExpireDelayInput(): number | undefined;
    private _sharedRunnersEnabled?;
    get sharedRunnersEnabled(): boolean | cdktf.IResolvable;
    set sharedRunnersEnabled(value: boolean | cdktf.IResolvable);
    resetSharedRunnersEnabled(): void;
    get sharedRunnersEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sharedRunnersMinutes?;
    get sharedRunnersMinutes(): number;
    set sharedRunnersMinutes(value: number);
    resetSharedRunnersMinutes(): void;
    get sharedRunnersMinutesInput(): number | undefined;
    private _sharedRunnersText?;
    get sharedRunnersText(): string;
    set sharedRunnersText(value: string);
    resetSharedRunnersText(): void;
    get sharedRunnersTextInput(): string | undefined;
    private _sidekiqJobLimiterCompressionThresholdBytes?;
    get sidekiqJobLimiterCompressionThresholdBytes(): number;
    set sidekiqJobLimiterCompressionThresholdBytes(value: number);
    resetSidekiqJobLimiterCompressionThresholdBytes(): void;
    get sidekiqJobLimiterCompressionThresholdBytesInput(): number | undefined;
    private _sidekiqJobLimiterLimitBytes?;
    get sidekiqJobLimiterLimitBytes(): number;
    set sidekiqJobLimiterLimitBytes(value: number);
    resetSidekiqJobLimiterLimitBytes(): void;
    get sidekiqJobLimiterLimitBytesInput(): number | undefined;
    private _sidekiqJobLimiterMode?;
    get sidekiqJobLimiterMode(): string;
    set sidekiqJobLimiterMode(value: string);
    resetSidekiqJobLimiterMode(): void;
    get sidekiqJobLimiterModeInput(): string | undefined;
    private _signInText?;
    get signInText(): string;
    set signInText(value: string);
    resetSignInText(): void;
    get signInTextInput(): string | undefined;
    private _signupEnabled?;
    get signupEnabled(): boolean | cdktf.IResolvable;
    set signupEnabled(value: boolean | cdktf.IResolvable);
    resetSignupEnabled(): void;
    get signupEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _silentAdminExportsEnabled?;
    get silentAdminExportsEnabled(): boolean | cdktf.IResolvable;
    set silentAdminExportsEnabled(value: boolean | cdktf.IResolvable);
    resetSilentAdminExportsEnabled(): void;
    get silentAdminExportsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _silentModeEnabled?;
    get silentModeEnabled(): boolean | cdktf.IResolvable;
    set silentModeEnabled(value: boolean | cdktf.IResolvable);
    resetSilentModeEnabled(): void;
    get silentModeEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _slackAppEnabled?;
    get slackAppEnabled(): boolean | cdktf.IResolvable;
    set slackAppEnabled(value: boolean | cdktf.IResolvable);
    resetSlackAppEnabled(): void;
    get slackAppEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _slackAppId?;
    get slackAppId(): string;
    set slackAppId(value: string);
    resetSlackAppId(): void;
    get slackAppIdInput(): string | undefined;
    private _slackAppSecret?;
    get slackAppSecret(): string;
    set slackAppSecret(value: string);
    resetSlackAppSecret(): void;
    get slackAppSecretInput(): string | undefined;
    private _slackAppSigningSecret?;
    get slackAppSigningSecret(): string;
    set slackAppSigningSecret(value: string);
    resetSlackAppSigningSecret(): void;
    get slackAppSigningSecretInput(): string | undefined;
    private _slackAppVerificationToken?;
    get slackAppVerificationToken(): string;
    set slackAppVerificationToken(value: string);
    resetSlackAppVerificationToken(): void;
    get slackAppVerificationTokenInput(): string | undefined;
    private _snippetSizeLimit?;
    get snippetSizeLimit(): number;
    set snippetSizeLimit(value: number);
    resetSnippetSizeLimit(): void;
    get snippetSizeLimitInput(): number | undefined;
    private _snowplowAppId?;
    get snowplowAppId(): string;
    set snowplowAppId(value: string);
    resetSnowplowAppId(): void;
    get snowplowAppIdInput(): string | undefined;
    private _snowplowCollectorHostname?;
    get snowplowCollectorHostname(): string;
    set snowplowCollectorHostname(value: string);
    resetSnowplowCollectorHostname(): void;
    get snowplowCollectorHostnameInput(): string | undefined;
    private _snowplowCookieDomain?;
    get snowplowCookieDomain(): string;
    set snowplowCookieDomain(value: string);
    resetSnowplowCookieDomain(): void;
    get snowplowCookieDomainInput(): string | undefined;
    private _snowplowDatabaseCollectorHostname?;
    get snowplowDatabaseCollectorHostname(): string;
    set snowplowDatabaseCollectorHostname(value: string);
    resetSnowplowDatabaseCollectorHostname(): void;
    get snowplowDatabaseCollectorHostnameInput(): string | undefined;
    private _snowplowEnabled?;
    get snowplowEnabled(): boolean | cdktf.IResolvable;
    set snowplowEnabled(value: boolean | cdktf.IResolvable);
    resetSnowplowEnabled(): void;
    get snowplowEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sourcegraphEnabled?;
    get sourcegraphEnabled(): boolean | cdktf.IResolvable;
    set sourcegraphEnabled(value: boolean | cdktf.IResolvable);
    resetSourcegraphEnabled(): void;
    get sourcegraphEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sourcegraphPublicOnly?;
    get sourcegraphPublicOnly(): boolean | cdktf.IResolvable;
    set sourcegraphPublicOnly(value: boolean | cdktf.IResolvable);
    resetSourcegraphPublicOnly(): void;
    get sourcegraphPublicOnlyInput(): boolean | cdktf.IResolvable | undefined;
    private _sourcegraphUrl?;
    get sourcegraphUrl(): string;
    set sourcegraphUrl(value: string);
    resetSourcegraphUrl(): void;
    get sourcegraphUrlInput(): string | undefined;
    private _spamCheckApiKey?;
    get spamCheckApiKey(): string;
    set spamCheckApiKey(value: string);
    resetSpamCheckApiKey(): void;
    get spamCheckApiKeyInput(): string | undefined;
    private _spamCheckEndpointEnabled?;
    get spamCheckEndpointEnabled(): boolean | cdktf.IResolvable;
    set spamCheckEndpointEnabled(value: boolean | cdktf.IResolvable);
    resetSpamCheckEndpointEnabled(): void;
    get spamCheckEndpointEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _spamCheckEndpointUrl?;
    get spamCheckEndpointUrl(): string;
    set spamCheckEndpointUrl(value: string);
    resetSpamCheckEndpointUrl(): void;
    get spamCheckEndpointUrlInput(): string | undefined;
    private _staticObjectsExternalStorageAuthToken?;
    get staticObjectsExternalStorageAuthToken(): string;
    set staticObjectsExternalStorageAuthToken(value: string);
    resetStaticObjectsExternalStorageAuthToken(): void;
    get staticObjectsExternalStorageAuthTokenInput(): string | undefined;
    private _staticObjectsExternalStorageUrl?;
    get staticObjectsExternalStorageUrl(): string;
    set staticObjectsExternalStorageUrl(value: string);
    resetStaticObjectsExternalStorageUrl(): void;
    get staticObjectsExternalStorageUrlInput(): string | undefined;
    private _suggestPipelineEnabled?;
    get suggestPipelineEnabled(): boolean | cdktf.IResolvable;
    set suggestPipelineEnabled(value: boolean | cdktf.IResolvable);
    resetSuggestPipelineEnabled(): void;
    get suggestPipelineEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _terminalMaxSessionTime?;
    get terminalMaxSessionTime(): number;
    set terminalMaxSessionTime(value: number);
    resetTerminalMaxSessionTime(): void;
    get terminalMaxSessionTimeInput(): number | undefined;
    private _terms?;
    get terms(): string;
    set terms(value: string);
    resetTerms(): void;
    get termsInput(): string | undefined;
    private _throttleAuthenticatedApiEnabled?;
    get throttleAuthenticatedApiEnabled(): boolean | cdktf.IResolvable;
    set throttleAuthenticatedApiEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleAuthenticatedApiEnabled(): void;
    get throttleAuthenticatedApiEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleAuthenticatedApiPeriodInSeconds?;
    get throttleAuthenticatedApiPeriodInSeconds(): number;
    set throttleAuthenticatedApiPeriodInSeconds(value: number);
    resetThrottleAuthenticatedApiPeriodInSeconds(): void;
    get throttleAuthenticatedApiPeriodInSecondsInput(): number | undefined;
    private _throttleAuthenticatedApiRequestsPerPeriod?;
    get throttleAuthenticatedApiRequestsPerPeriod(): number;
    set throttleAuthenticatedApiRequestsPerPeriod(value: number);
    resetThrottleAuthenticatedApiRequestsPerPeriod(): void;
    get throttleAuthenticatedApiRequestsPerPeriodInput(): number | undefined;
    private _throttleAuthenticatedPackagesApiEnabled?;
    get throttleAuthenticatedPackagesApiEnabled(): boolean | cdktf.IResolvable;
    set throttleAuthenticatedPackagesApiEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleAuthenticatedPackagesApiEnabled(): void;
    get throttleAuthenticatedPackagesApiEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleAuthenticatedPackagesApiPeriodInSeconds?;
    get throttleAuthenticatedPackagesApiPeriodInSeconds(): number;
    set throttleAuthenticatedPackagesApiPeriodInSeconds(value: number);
    resetThrottleAuthenticatedPackagesApiPeriodInSeconds(): void;
    get throttleAuthenticatedPackagesApiPeriodInSecondsInput(): number | undefined;
    private _throttleAuthenticatedPackagesApiRequestsPerPeriod?;
    get throttleAuthenticatedPackagesApiRequestsPerPeriod(): number;
    set throttleAuthenticatedPackagesApiRequestsPerPeriod(value: number);
    resetThrottleAuthenticatedPackagesApiRequestsPerPeriod(): void;
    get throttleAuthenticatedPackagesApiRequestsPerPeriodInput(): number | undefined;
    private _throttleAuthenticatedWebEnabled?;
    get throttleAuthenticatedWebEnabled(): boolean | cdktf.IResolvable;
    set throttleAuthenticatedWebEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleAuthenticatedWebEnabled(): void;
    get throttleAuthenticatedWebEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleAuthenticatedWebPeriodInSeconds?;
    get throttleAuthenticatedWebPeriodInSeconds(): number;
    set throttleAuthenticatedWebPeriodInSeconds(value: number);
    resetThrottleAuthenticatedWebPeriodInSeconds(): void;
    get throttleAuthenticatedWebPeriodInSecondsInput(): number | undefined;
    private _throttleAuthenticatedWebRequestsPerPeriod?;
    get throttleAuthenticatedWebRequestsPerPeriod(): number;
    set throttleAuthenticatedWebRequestsPerPeriod(value: number);
    resetThrottleAuthenticatedWebRequestsPerPeriod(): void;
    get throttleAuthenticatedWebRequestsPerPeriodInput(): number | undefined;
    private _throttleUnauthenticatedApiEnabled?;
    get throttleUnauthenticatedApiEnabled(): boolean | cdktf.IResolvable;
    set throttleUnauthenticatedApiEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleUnauthenticatedApiEnabled(): void;
    get throttleUnauthenticatedApiEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleUnauthenticatedApiPeriodInSeconds?;
    get throttleUnauthenticatedApiPeriodInSeconds(): number;
    set throttleUnauthenticatedApiPeriodInSeconds(value: number);
    resetThrottleUnauthenticatedApiPeriodInSeconds(): void;
    get throttleUnauthenticatedApiPeriodInSecondsInput(): number | undefined;
    private _throttleUnauthenticatedApiRequestsPerPeriod?;
    get throttleUnauthenticatedApiRequestsPerPeriod(): number;
    set throttleUnauthenticatedApiRequestsPerPeriod(value: number);
    resetThrottleUnauthenticatedApiRequestsPerPeriod(): void;
    get throttleUnauthenticatedApiRequestsPerPeriodInput(): number | undefined;
    private _throttleUnauthenticatedPackagesApiEnabled?;
    get throttleUnauthenticatedPackagesApiEnabled(): boolean | cdktf.IResolvable;
    set throttleUnauthenticatedPackagesApiEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleUnauthenticatedPackagesApiEnabled(): void;
    get throttleUnauthenticatedPackagesApiEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleUnauthenticatedPackagesApiPeriodInSeconds?;
    get throttleUnauthenticatedPackagesApiPeriodInSeconds(): number;
    set throttleUnauthenticatedPackagesApiPeriodInSeconds(value: number);
    resetThrottleUnauthenticatedPackagesApiPeriodInSeconds(): void;
    get throttleUnauthenticatedPackagesApiPeriodInSecondsInput(): number | undefined;
    private _throttleUnauthenticatedPackagesApiRequestsPerPeriod?;
    get throttleUnauthenticatedPackagesApiRequestsPerPeriod(): number;
    set throttleUnauthenticatedPackagesApiRequestsPerPeriod(value: number);
    resetThrottleUnauthenticatedPackagesApiRequestsPerPeriod(): void;
    get throttleUnauthenticatedPackagesApiRequestsPerPeriodInput(): number | undefined;
    private _throttleUnauthenticatedWebEnabled?;
    get throttleUnauthenticatedWebEnabled(): boolean | cdktf.IResolvable;
    set throttleUnauthenticatedWebEnabled(value: boolean | cdktf.IResolvable);
    resetThrottleUnauthenticatedWebEnabled(): void;
    get throttleUnauthenticatedWebEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _throttleUnauthenticatedWebPeriodInSeconds?;
    get throttleUnauthenticatedWebPeriodInSeconds(): number;
    set throttleUnauthenticatedWebPeriodInSeconds(value: number);
    resetThrottleUnauthenticatedWebPeriodInSeconds(): void;
    get throttleUnauthenticatedWebPeriodInSecondsInput(): number | undefined;
    private _throttleUnauthenticatedWebRequestsPerPeriod?;
    get throttleUnauthenticatedWebRequestsPerPeriod(): number;
    set throttleUnauthenticatedWebRequestsPerPeriod(value: number);
    resetThrottleUnauthenticatedWebRequestsPerPeriod(): void;
    get throttleUnauthenticatedWebRequestsPerPeriodInput(): number | undefined;
    private _timeTrackingLimitToHours?;
    get timeTrackingLimitToHours(): boolean | cdktf.IResolvable;
    set timeTrackingLimitToHours(value: boolean | cdktf.IResolvable);
    resetTimeTrackingLimitToHours(): void;
    get timeTrackingLimitToHoursInput(): boolean | cdktf.IResolvable | undefined;
    private _twoFactorGracePeriod?;
    get twoFactorGracePeriod(): number;
    set twoFactorGracePeriod(value: number);
    resetTwoFactorGracePeriod(): void;
    get twoFactorGracePeriodInput(): number | undefined;
    private _unconfirmedUsersDeleteAfterDays?;
    get unconfirmedUsersDeleteAfterDays(): number;
    set unconfirmedUsersDeleteAfterDays(value: number);
    resetUnconfirmedUsersDeleteAfterDays(): void;
    get unconfirmedUsersDeleteAfterDaysInput(): number | undefined;
    private _uniqueIpsLimitEnabled?;
    get uniqueIpsLimitEnabled(): boolean | cdktf.IResolvable;
    set uniqueIpsLimitEnabled(value: boolean | cdktf.IResolvable);
    resetUniqueIpsLimitEnabled(): void;
    get uniqueIpsLimitEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _uniqueIpsLimitPerUser?;
    get uniqueIpsLimitPerUser(): number;
    set uniqueIpsLimitPerUser(value: number);
    resetUniqueIpsLimitPerUser(): void;
    get uniqueIpsLimitPerUserInput(): number | undefined;
    private _uniqueIpsLimitTimeWindow?;
    get uniqueIpsLimitTimeWindow(): number;
    set uniqueIpsLimitTimeWindow(value: number);
    resetUniqueIpsLimitTimeWindow(): void;
    get uniqueIpsLimitTimeWindowInput(): number | undefined;
    private _updateRunnerVersionsEnabled?;
    get updateRunnerVersionsEnabled(): boolean | cdktf.IResolvable;
    set updateRunnerVersionsEnabled(value: boolean | cdktf.IResolvable);
    resetUpdateRunnerVersionsEnabled(): void;
    get updateRunnerVersionsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _usagePingEnabled?;
    get usagePingEnabled(): boolean | cdktf.IResolvable;
    set usagePingEnabled(value: boolean | cdktf.IResolvable);
    resetUsagePingEnabled(): void;
    get usagePingEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _useClickhouseForAnalytics?;
    get useClickhouseForAnalytics(): boolean | cdktf.IResolvable;
    set useClickhouseForAnalytics(value: boolean | cdktf.IResolvable);
    resetUseClickhouseForAnalytics(): void;
    get useClickhouseForAnalyticsInput(): boolean | cdktf.IResolvable | undefined;
    private _userDeactivationEmailsEnabled?;
    get userDeactivationEmailsEnabled(): boolean | cdktf.IResolvable;
    set userDeactivationEmailsEnabled(value: boolean | cdktf.IResolvable);
    resetUserDeactivationEmailsEnabled(): void;
    get userDeactivationEmailsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _userDefaultExternal?;
    get userDefaultExternal(): boolean | cdktf.IResolvable;
    set userDefaultExternal(value: boolean | cdktf.IResolvable);
    resetUserDefaultExternal(): void;
    get userDefaultExternalInput(): boolean | cdktf.IResolvable | undefined;
    private _userDefaultInternalRegex?;
    get userDefaultInternalRegex(): string;
    set userDefaultInternalRegex(value: string);
    resetUserDefaultInternalRegex(): void;
    get userDefaultInternalRegexInput(): string | undefined;
    private _userDefaultsToPrivateProfile?;
    get userDefaultsToPrivateProfile(): boolean | cdktf.IResolvable;
    set userDefaultsToPrivateProfile(value: boolean | cdktf.IResolvable);
    resetUserDefaultsToPrivateProfile(): void;
    get userDefaultsToPrivateProfileInput(): boolean | cdktf.IResolvable | undefined;
    private _userOauthApplications?;
    get userOauthApplications(): boolean | cdktf.IResolvable;
    set userOauthApplications(value: boolean | cdktf.IResolvable);
    resetUserOauthApplications(): void;
    get userOauthApplicationsInput(): boolean | cdktf.IResolvable | undefined;
    private _userShowAddSshKeyMessage?;
    get userShowAddSshKeyMessage(): boolean | cdktf.IResolvable;
    set userShowAddSshKeyMessage(value: boolean | cdktf.IResolvable);
    resetUserShowAddSshKeyMessage(): void;
    get userShowAddSshKeyMessageInput(): boolean | cdktf.IResolvable | undefined;
    private _validRunnerRegistrars?;
    get validRunnerRegistrars(): string[];
    set validRunnerRegistrars(value: string[]);
    resetValidRunnerRegistrars(): void;
    get validRunnerRegistrarsInput(): string[] | undefined;
    private _versionCheckEnabled?;
    get versionCheckEnabled(): boolean | cdktf.IResolvable;
    set versionCheckEnabled(value: boolean | cdktf.IResolvable);
    resetVersionCheckEnabled(): void;
    get versionCheckEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _webIdeClientsidePreviewEnabled?;
    get webIdeClientsidePreviewEnabled(): boolean | cdktf.IResolvable;
    set webIdeClientsidePreviewEnabled(value: boolean | cdktf.IResolvable);
    resetWebIdeClientsidePreviewEnabled(): void;
    get webIdeClientsidePreviewEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _whatsNewVariant?;
    get whatsNewVariant(): string;
    set whatsNewVariant(value: string);
    resetWhatsNewVariant(): void;
    get whatsNewVariantInput(): string | undefined;
    private _wikiPageMaxContentBytes?;
    get wikiPageMaxContentBytes(): number;
    set wikiPageMaxContentBytes(value: number);
    resetWikiPageMaxContentBytes(): void;
    get wikiPageMaxContentBytesInput(): number | undefined;
    private _defaultBranchProtectionDefaults;
    get defaultBranchProtectionDefaults(): ApplicationSettingsDefaultBranchProtectionDefaultsOutputReference;
    putDefaultBranchProtectionDefaults(value: ApplicationSettingsDefaultBranchProtectionDefaults): void;
    resetDefaultBranchProtectionDefaults(): void;
    get defaultBranchProtectionDefaultsInput(): ApplicationSettingsDefaultBranchProtectionDefaults | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
