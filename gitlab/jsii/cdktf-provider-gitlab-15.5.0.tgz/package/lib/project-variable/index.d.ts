/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#description ProjectVariable#description}
    */
    readonly description?: string;
    /**
    * The environment scope of the variable. Defaults to all environment (`*`). Note that in Community Editions of Gitlab, values other than `*` will cause inconsistent plans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#environment_scope ProjectVariable#environment_scope}
    */
    readonly environmentScope?: string;
    /**
    * If set to `true`, the value of the variable will be hidden in the CI/CD User Interface. The value must meet the [hidden requirements](https://docs.gitlab.com/ci/variables/#hide-a-cicd-variable).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#hidden ProjectVariable#hidden}
    */
    readonly hidden?: boolean | cdktf.IResolvable;
    /**
    * The name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#key ProjectVariable#key}
    */
    readonly key: string;
    /**
    * If set to `true`, the value of the variable will be masked in job logs. The value must meet the [masking requirements](https://docs.gitlab.com/ee/ci/variables/#mask-a-cicd-variable).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#masked ProjectVariable#masked}
    */
    readonly masked?: boolean | cdktf.IResolvable;
    /**
    * The name or id of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#project ProjectVariable#project}
    */
    readonly project: string;
    /**
    * If set to `true`, the variable will be passed only to pipelines running on protected branches and tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#protected ProjectVariable#protected}
    */
    readonly protected?: boolean | cdktf.IResolvable;
    /**
    * Whether the variable is treated as a raw string. When true, variables in the value are not expanded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#raw ProjectVariable#raw}
    */
    readonly raw?: boolean | cdktf.IResolvable;
    /**
    * The value of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#value ProjectVariable#value}
    */
    readonly value: string;
    /**
    * The type of a variable. Valid values are: `env_var`, `file`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#variable_type ProjectVariable#variable_type}
    */
    readonly variableType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable gitlab_project_variable}
*/
export declare class ProjectVariable extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_variable";
    /**
    * Generates CDKTF code for importing a ProjectVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectVariable to import
    * @param importFromId The id of the existing ProjectVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_variable gitlab_project_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectVariableConfig
    */
    constructor(scope: Construct, id: string, config: ProjectVariableConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentScope?;
    get environmentScope(): string;
    set environmentScope(value: string);
    resetEnvironmentScope(): void;
    get environmentScopeInput(): string | undefined;
    private _hidden?;
    get hidden(): boolean | cdktf.IResolvable;
    set hidden(value: boolean | cdktf.IResolvable);
    resetHidden(): void;
    get hiddenInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _masked?;
    get masked(): boolean | cdktf.IResolvable;
    set masked(value: boolean | cdktf.IResolvable);
    resetMasked(): void;
    get maskedInput(): boolean | cdktf.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _protected?;
    get protected(): boolean | cdktf.IResolvable;
    set protected(value: boolean | cdktf.IResolvable);
    resetProtected(): void;
    get protectedInput(): boolean | cdktf.IResolvable | undefined;
    private _raw?;
    get raw(): boolean | cdktf.IResolvable;
    set raw(value: boolean | cdktf.IResolvable);
    resetRaw(): void;
    get rawInput(): boolean | cdktf.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _variableType?;
    get variableType(): string;
    set variableType(value: string);
    resetVariableType(): void;
    get variableTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
