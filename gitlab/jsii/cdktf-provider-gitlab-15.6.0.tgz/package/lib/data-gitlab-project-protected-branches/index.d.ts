/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectProtectedBranchesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The integer or path with namespace that uniquely identifies the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#project_id DataGitlabProjectProtectedBranches#project_id}
    */
    readonly projectId: string;
    /**
    * protected_branches block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#protected_branches DataGitlabProjectProtectedBranches#protected_branches}
    */
    readonly protectedBranches?: DataGitlabProjectProtectedBranchesProtectedBranches[] | cdktf.IResolvable;
}
export interface DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels {
    /**
    * The ID of a GitLab group allowed to perform the relevant action. Mutually exclusive with `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#group_id DataGitlabProjectProtectedBranches#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action. Mutually exclusive with `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#user_id DataGitlabProjectProtectedBranches#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels | cdktf.IResolvable): any;
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels | cdktf.IResolvable): any;
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels | cdktf.IResolvable | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsOutputReference;
}
export interface DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels {
    /**
    * The ID of a GitLab deploy key allowed to perform the relevant action. Mutually exclusive with `group_id` and `user_id`. This field is read-only until Gitlab 17.5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#deploy_key_id DataGitlabProjectProtectedBranches#deploy_key_id}
    */
    readonly deployKeyId?: number;
    /**
    * The ID of a GitLab group allowed to perform the relevant action. Mutually exclusive with `deploy_key_id` and `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#group_id DataGitlabProjectProtectedBranches#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action. Mutually exclusive with `deploy_key_id` and `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#user_id DataGitlabProjectProtectedBranches#user_id}
    */
    readonly userId?: number;
}
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsToTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels | cdktf.IResolvable): any;
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsToHclTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels | cdktf.IResolvable): any;
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels | cdktf.IResolvable | undefined);
    get accessLevel(): string;
    get accessLevelDescription(): string;
    private _deployKeyId?;
    get deployKeyId(): number;
    set deployKeyId(value: number);
    resetDeployKeyId(): void;
    get deployKeyIdInput(): number | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsOutputReference;
}
export interface DataGitlabProjectProtectedBranchesProtectedBranches {
    /**
    * merge_access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#merge_access_levels DataGitlabProjectProtectedBranches#merge_access_levels}
    */
    readonly mergeAccessLevels?: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels[] | cdktf.IResolvable;
    /**
    * push_access_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#push_access_levels DataGitlabProjectProtectedBranches#push_access_levels}
    */
    readonly pushAccessLevels?: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels[] | cdktf.IResolvable;
}
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesToTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranches | cdktf.IResolvable): any;
export declare function dataGitlabProjectProtectedBranchesProtectedBranchesToHclTerraform(struct?: DataGitlabProjectProtectedBranchesProtectedBranches | cdktf.IResolvable): any;
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectProtectedBranchesProtectedBranches | cdktf.IResolvable | undefined;
    set internalValue(value: DataGitlabProjectProtectedBranchesProtectedBranches | cdktf.IResolvable | undefined);
    get allowForcePush(): cdktf.IResolvable;
    get codeOwnerApprovalRequired(): cdktf.IResolvable;
    get id(): number;
    get name(): string;
    private _mergeAccessLevels;
    get mergeAccessLevels(): DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevelsList;
    putMergeAccessLevels(value: DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels[] | cdktf.IResolvable): void;
    resetMergeAccessLevels(): void;
    get mergeAccessLevelsInput(): cdktf.IResolvable | DataGitlabProjectProtectedBranchesProtectedBranchesMergeAccessLevels[] | undefined;
    private _pushAccessLevels;
    get pushAccessLevels(): DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevelsList;
    putPushAccessLevels(value: DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels[] | cdktf.IResolvable): void;
    resetPushAccessLevels(): void;
    get pushAccessLevelsInput(): cdktf.IResolvable | DataGitlabProjectProtectedBranchesProtectedBranchesPushAccessLevels[] | undefined;
}
export declare class DataGitlabProjectProtectedBranchesProtectedBranchesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabProjectProtectedBranchesProtectedBranches[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectProtectedBranchesProtectedBranchesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches gitlab_project_protected_branches}
*/
export declare class DataGitlabProjectProtectedBranches extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_protected_branches";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectProtectedBranches resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectProtectedBranches to import
    * @param importFromId The id of the existing DataGitlabProjectProtectedBranches that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectProtectedBranches to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_protected_branches gitlab_project_protected_branches} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectProtectedBranchesConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectProtectedBranchesConfig);
    get id(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protectedBranches;
    get protectedBranches(): DataGitlabProjectProtectedBranchesProtectedBranchesList;
    putProtectedBranches(value: DataGitlabProjectProtectedBranchesProtectedBranches[] | cdktf.IResolvable): void;
    resetProtectedBranches(): void;
    get protectedBranchesInput(): cdktf.IResolvable | DataGitlabProjectProtectedBranchesProtectedBranches[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
