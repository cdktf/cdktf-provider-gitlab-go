/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectExternalStatusCheckConfig extends cdktf.TerraformMetaArguments {
    /**
    * The URL of the external status check service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#external_url ProjectExternalStatusCheck#external_url}
    */
    readonly externalUrl: string;
    /**
    * The display name of the external status check service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#name ProjectExternalStatusCheck#name}
    */
    readonly name: string;
    /**
    * The ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#project_id ProjectExternalStatusCheck#project_id}
    */
    readonly projectId: number;
    /**
    * The list of IDs of protected branches to scope the rule by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#protected_branch_ids ProjectExternalStatusCheck#protected_branch_ids}
    */
    readonly protectedBranchIds?: number[];
    /**
    * The HMAC secret for the external status check.  If this is set, then removed from the config, the value will get set to empty in the state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#shared_secret ProjectExternalStatusCheck#shared_secret}
    */
    readonly sharedSecret?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check gitlab_project_external_status_check}
*/
export declare class ProjectExternalStatusCheck extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_external_status_check";
    /**
    * Generates CDKTF code for importing a ProjectExternalStatusCheck resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectExternalStatusCheck to import
    * @param importFromId The id of the existing ProjectExternalStatusCheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectExternalStatusCheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/project_external_status_check gitlab_project_external_status_check} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectExternalStatusCheckConfig
    */
    constructor(scope: Construct, id: string, config: ProjectExternalStatusCheckConfig);
    private _externalUrl?;
    get externalUrl(): string;
    set externalUrl(value: string);
    get externalUrlInput(): string | undefined;
    get hmac(): cdktf.IResolvable;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): number;
    set projectId(value: number);
    get projectIdInput(): number | undefined;
    private _protectedBranchIds?;
    get protectedBranchIds(): number[];
    set protectedBranchIds(value: number[]);
    resetProtectedBranchIds(): void;
    get protectedBranchIdsInput(): number[] | undefined;
    private _sharedSecret?;
    get sharedSecret(): string;
    set sharedSecret(value: string);
    resetSharedSecret(): void;
    get sharedSecretInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
