/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TagProtectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Access levels allowed to create. Default value of `maintainer`. The default value is always sent if not provided in the configuration. Valid values are: `no one`, `developer`, `maintainer`, `admin`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#create_access_level TagProtection#create_access_level}
    */
    readonly createAccessLevel?: string;
    /**
    * The id of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#project TagProtection#project}
    */
    readonly project: string;
    /**
    * Name of the tag or wildcard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#tag TagProtection#tag}
    */
    readonly tag: string;
    /**
    * allowed_to_create block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#allowed_to_create TagProtection#allowed_to_create}
    */
    readonly allowedToCreate?: TagProtectionAllowedToCreate[] | cdktf.IResolvable;
}
export interface TagProtectionAllowedToCreate {
    /**
    * Access levels allowed to create protected tags. Valid values are: `no one`, `developer`, `maintainer`, `admin`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#access_level TagProtection#access_level}
    */
    readonly accessLevel?: string;
    /**
    * The ID of a GitLab group allowed to perform the relevant action. Mutually exclusive with `user_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#group_id TagProtection#group_id}
    */
    readonly groupId?: number;
    /**
    * The ID of a GitLab user allowed to perform the relevant action. Mutually exclusive with `group_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#user_id TagProtection#user_id}
    */
    readonly userId?: number;
}
export declare function tagProtectionAllowedToCreateToTerraform(struct?: TagProtectionAllowedToCreate | cdktf.IResolvable): any;
export declare function tagProtectionAllowedToCreateToHclTerraform(struct?: TagProtectionAllowedToCreate | cdktf.IResolvable): any;
export declare class TagProtectionAllowedToCreateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TagProtectionAllowedToCreate | cdktf.IResolvable | undefined;
    set internalValue(value: TagProtectionAllowedToCreate | cdktf.IResolvable | undefined);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    get accessLevelDescription(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    resetUserId(): void;
    get userIdInput(): number | undefined;
}
export declare class TagProtectionAllowedToCreateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TagProtectionAllowedToCreate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TagProtectionAllowedToCreateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection gitlab_tag_protection}
*/
export declare class TagProtection extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_tag_protection";
    /**
    * Generates CDKTF code for importing a TagProtection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TagProtection to import
    * @param importFromId The id of the existing TagProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TagProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/tag_protection gitlab_tag_protection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TagProtectionConfig
    */
    constructor(scope: Construct, id: string, config: TagProtectionConfig);
    private _createAccessLevel?;
    get createAccessLevel(): string;
    set createAccessLevel(value: string);
    resetCreateAccessLevel(): void;
    get createAccessLevelInput(): string | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _allowedToCreate;
    get allowedToCreate(): TagProtectionAllowedToCreateList;
    putAllowedToCreate(value: TagProtectionAllowedToCreate[] | cdktf.IResolvable): void;
    resetAllowedToCreate(): void;
    get allowedToCreateInput(): cdktf.IResolvable | TagProtectionAllowedToCreate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
