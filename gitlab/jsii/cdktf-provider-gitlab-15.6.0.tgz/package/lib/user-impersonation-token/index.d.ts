/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserImpersonationTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * Expiration date of the impersonation token in ISO format (YYYY-MM-DD).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#expires_at UserImpersonationToken#expires_at}
    */
    readonly expiresAt: string;
    /**
    * The name of the impersonation token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#name UserImpersonationToken#name}
    */
    readonly name: string;
    /**
    * Array of scopes of the impersonation token. valid values are: `api`, `read_user`, `read_api`, `read_repository`, `write_repository`, `read_registry`, `write_registry`, `read_virtual_registry`, `write_virtual_registry`, `sudo`, `admin_mode`, `create_runner`, `manage_runner`, `ai_features`, `k8s_proxy`, `self_rotate`, `read_service_ping`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#scopes UserImpersonationToken#scopes}
    */
    readonly scopes: string[];
    /**
    * The ID of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#user_id UserImpersonationToken#user_id}
    */
    readonly userId: number;
    /**
    * Wether to validate if the expiration date is in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#validate_past_expiration_date UserImpersonationToken#validate_past_expiration_date}
    */
    readonly validatePastExpirationDate?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token gitlab_user_impersonation_token}
*/
export declare class UserImpersonationToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_user_impersonation_token";
    /**
    * Generates CDKTF code for importing a UserImpersonationToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserImpersonationToken to import
    * @param importFromId The id of the existing UserImpersonationToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserImpersonationToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/user_impersonation_token gitlab_user_impersonation_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserImpersonationTokenConfig
    */
    constructor(scope: Construct, id: string, config: UserImpersonationTokenConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    get expiresAtInput(): string | undefined;
    get id(): string;
    get impersonation(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get revoked(): cdktf.IResolvable;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    get token(): string;
    get tokenId(): number;
    private _userId?;
    get userId(): number;
    set userId(value: number);
    get userIdInput(): number | undefined;
    private _validatePastExpirationDate?;
    get validatePastExpirationDate(): boolean | cdktf.IResolvable;
    set validatePastExpirationDate(value: boolean | cdktf.IResolvable);
    resetValidatePastExpirationDate(): void;
    get validatePastExpirationDateInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
