/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabPipelineSchedulesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name or id of the project to add the schedule to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules#project DataGitlabPipelineSchedules#project}
    */
    readonly project: string;
}
export interface DataGitlabPipelineSchedulesPipelineSchedulesOwner {
}
export declare function dataGitlabPipelineSchedulesPipelineSchedulesOwnerToTerraform(struct?: DataGitlabPipelineSchedulesPipelineSchedulesOwner): any;
export declare function dataGitlabPipelineSchedulesPipelineSchedulesOwnerToHclTerraform(struct?: DataGitlabPipelineSchedulesPipelineSchedulesOwner): any;
export declare class DataGitlabPipelineSchedulesPipelineSchedulesOwnerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabPipelineSchedulesPipelineSchedulesOwner | undefined;
    set internalValue(value: DataGitlabPipelineSchedulesPipelineSchedulesOwner | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabPipelineSchedulesPipelineSchedules {
    /**
    * The timezone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules#cron_timezone DataGitlabPipelineSchedules#cron_timezone}
    */
    readonly cronTimezone?: string;
    /**
    * The pipeline schedule id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules#id DataGitlabPipelineSchedules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: number;
}
export declare function dataGitlabPipelineSchedulesPipelineSchedulesToTerraform(struct?: DataGitlabPipelineSchedulesPipelineSchedules): any;
export declare function dataGitlabPipelineSchedulesPipelineSchedulesToHclTerraform(struct?: DataGitlabPipelineSchedulesPipelineSchedules): any;
export declare class DataGitlabPipelineSchedulesPipelineSchedulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabPipelineSchedulesPipelineSchedules | undefined;
    set internalValue(value: DataGitlabPipelineSchedulesPipelineSchedules | undefined);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get cron(): string;
    private _cronTimezone?;
    get cronTimezone(): string;
    set cronTimezone(value: string);
    resetCronTimezone(): void;
    get cronTimezoneInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    get idInput(): number | undefined;
    get nextRunAt(): string;
    private _owner;
    get owner(): DataGitlabPipelineSchedulesPipelineSchedulesOwnerOutputReference;
    get ref(): string;
    get updatedAt(): string;
}
export declare class DataGitlabPipelineSchedulesPipelineSchedulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataGitlabPipelineSchedulesPipelineSchedules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabPipelineSchedulesPipelineSchedulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules gitlab_pipeline_schedules}
*/
export declare class DataGitlabPipelineSchedules extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_pipeline_schedules";
    /**
    * Generates CDKTF code for importing a DataGitlabPipelineSchedules resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabPipelineSchedules to import
    * @param importFromId The id of the existing DataGitlabPipelineSchedules that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabPipelineSchedules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/pipeline_schedules gitlab_pipeline_schedules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabPipelineSchedulesConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabPipelineSchedulesConfig);
    get id(): string;
    private _pipelineSchedules;
    get pipelineSchedules(): DataGitlabPipelineSchedulesPipelineSchedulesList;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
