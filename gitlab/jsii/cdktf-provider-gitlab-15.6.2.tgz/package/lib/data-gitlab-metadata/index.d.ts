/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabMetadataConfig extends cdktf.TerraformMetaArguments {
}
export interface DataGitlabMetadataKas {
}
export declare function dataGitlabMetadataKasToTerraform(struct?: DataGitlabMetadataKas): any;
export declare function dataGitlabMetadataKasToHclTerraform(struct?: DataGitlabMetadataKas): any;
export declare class DataGitlabMetadataKasOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabMetadataKas | undefined;
    set internalValue(value: DataGitlabMetadataKas | undefined);
    get enabled(): cdktf.IResolvable;
    get externalK8SProxyUrl(): string;
    get externalUrl(): string;
    get version(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/metadata gitlab_metadata}
*/
export declare class DataGitlabMetadata extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_metadata";
    /**
    * Generates CDKTF code for importing a DataGitlabMetadata resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabMetadata to import
    * @param importFromId The id of the existing DataGitlabMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/metadata gitlab_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabMetadataConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGitlabMetadataConfig);
    get enterprise(): cdktf.IResolvable;
    get id(): string;
    private _kas;
    get kas(): DataGitlabMetadataKasOutputReference;
    get revision(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
