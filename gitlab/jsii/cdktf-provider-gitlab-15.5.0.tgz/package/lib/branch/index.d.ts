/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface BranchConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#id Branch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicates whether the branch is kept once the resource destroyed (must be applied before a destroy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#keep_on_destroy Branch#keep_on_destroy}
    */
    readonly keepOnDestroy?: boolean | cdktf.IResolvable;
    /**
    * The name for this branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#name Branch#name}
    */
    readonly name: string;
    /**
    * The ID or full path of the project which the branch is created against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#project Branch#project}
    */
    readonly project: string;
    /**
    * The ref which the branch is created from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#ref Branch#ref}
    */
    readonly ref: string;
}
export interface BranchCommit {
}
export declare function branchCommitToTerraform(struct?: BranchCommit): any;
export declare function branchCommitToHclTerraform(struct?: BranchCommit): any;
export declare class BranchCommitOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BranchCommit | undefined;
    set internalValue(value: BranchCommit | undefined);
    get authorEmail(): string;
    get authorName(): string;
    get authoredDate(): string;
    get committedDate(): string;
    get committerEmail(): string;
    get committerName(): string;
    get id(): string;
    get message(): string;
    get parentIds(): string[];
    get shortId(): string;
    get title(): string;
}
export declare class BranchCommitList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BranchCommitOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch gitlab_branch}
*/
export declare class Branch extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_branch";
    /**
    * Generates CDKTF code for importing a Branch resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Branch to import
    * @param importFromId The id of the existing Branch that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Branch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/branch gitlab_branch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BranchConfig
    */
    constructor(scope: Construct, id: string, config: BranchConfig);
    get canPush(): cdktf.IResolvable;
    private _commit;
    get commit(): BranchCommitList;
    get default(): cdktf.IResolvable;
    get developerCanMerge(): cdktf.IResolvable;
    get developerCanPush(): cdktf.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keepOnDestroy?;
    get keepOnDestroy(): boolean | cdktf.IResolvable;
    set keepOnDestroy(value: boolean | cdktf.IResolvable);
    resetKeepOnDestroy(): void;
    get keepOnDestroyInput(): boolean | cdktf.IResolvable | undefined;
    get merged(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get protected(): cdktf.IResolvable;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    get refInput(): string | undefined;
    get webUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
