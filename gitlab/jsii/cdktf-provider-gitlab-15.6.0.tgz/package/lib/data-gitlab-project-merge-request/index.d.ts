/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectMergeRequestConfig extends cdktf.TerraformMetaArguments {
    /**
    * The unique project level ID of the merge request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_request#iid DataGitlabProjectMergeRequest#iid}
    */
    readonly iid: number;
    /**
    * The ID or path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_request#project DataGitlabProjectMergeRequest#project}
    */
    readonly project: string;
}
export interface DataGitlabProjectMergeRequestAssignee {
}
export declare function dataGitlabProjectMergeRequestAssigneeToTerraform(struct?: DataGitlabProjectMergeRequestAssignee): any;
export declare function dataGitlabProjectMergeRequestAssigneeToHclTerraform(struct?: DataGitlabProjectMergeRequestAssignee): any;
export declare class DataGitlabProjectMergeRequestAssigneeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestAssignee | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestAssignee | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabProjectMergeRequestAssignees {
}
export declare function dataGitlabProjectMergeRequestAssigneesToTerraform(struct?: DataGitlabProjectMergeRequestAssignees): any;
export declare function dataGitlabProjectMergeRequestAssigneesToHclTerraform(struct?: DataGitlabProjectMergeRequestAssignees): any;
export declare class DataGitlabProjectMergeRequestAssigneesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGitlabProjectMergeRequestAssignees | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestAssignees | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export declare class DataGitlabProjectMergeRequestAssigneesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGitlabProjectMergeRequestAssigneesOutputReference;
}
export interface DataGitlabProjectMergeRequestAuthor {
}
export declare function dataGitlabProjectMergeRequestAuthorToTerraform(struct?: DataGitlabProjectMergeRequestAuthor): any;
export declare function dataGitlabProjectMergeRequestAuthorToHclTerraform(struct?: DataGitlabProjectMergeRequestAuthor): any;
export declare class DataGitlabProjectMergeRequestAuthorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestAuthor | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestAuthor | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface DataGitlabProjectMergeRequestClosedBy {
}
export declare function dataGitlabProjectMergeRequestClosedByToTerraform(struct?: DataGitlabProjectMergeRequestClosedBy): any;
export declare function dataGitlabProjectMergeRequestClosedByToHclTerraform(struct?: DataGitlabProjectMergeRequestClosedBy): any;
export declare class DataGitlabProjectMergeRequestClosedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGitlabProjectMergeRequestClosedBy | undefined;
    set internalValue(value: DataGitlabProjectMergeRequestClosedBy | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_request gitlab_project_merge_request}
*/
export declare class DataGitlabProjectMergeRequest extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_merge_request";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectMergeRequest resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectMergeRequest to import
    * @param importFromId The id of the existing DataGitlabProjectMergeRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectMergeRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/data-sources/project_merge_request gitlab_project_merge_request} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectMergeRequestConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectMergeRequestConfig);
    private _assignee;
    get assignee(): DataGitlabProjectMergeRequestAssigneeOutputReference;
    private _assignees;
    get assignees(): DataGitlabProjectMergeRequestAssigneesList;
    private _author;
    get author(): DataGitlabProjectMergeRequestAuthorOutputReference;
    get blockingDiscussionsResolved(): cdktf.IResolvable;
    get changesCount(): string;
    get closedAt(): string;
    private _closedBy;
    get closedBy(): DataGitlabProjectMergeRequestClosedByOutputReference;
    get createdAt(): string;
    get id(): number;
    private _iid?;
    get iid(): number;
    set iid(value: number);
    get iidInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
