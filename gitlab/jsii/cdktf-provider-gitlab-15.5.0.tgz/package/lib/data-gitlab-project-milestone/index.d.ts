/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabProjectMilestoneConfig extends cdktf.TerraformMetaArguments {
    /**
    * The instance-wide ID of the project’s milestone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_milestone#milestone_id DataGitlabProjectMilestone#milestone_id}
    */
    readonly milestoneId: number;
    /**
    * The ID or URL-encoded path of the project owned by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_milestone#project DataGitlabProjectMilestone#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_milestone gitlab_project_milestone}
*/
export declare class DataGitlabProjectMilestone extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_project_milestone";
    /**
    * Generates CDKTF code for importing a DataGitlabProjectMilestone resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabProjectMilestone to import
    * @param importFromId The id of the existing DataGitlabProjectMilestone that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_milestone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabProjectMilestone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/data-sources/project_milestone gitlab_project_milestone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabProjectMilestoneConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabProjectMilestoneConfig);
    get createdAt(): string;
    get description(): string;
    get dueDate(): string;
    get expired(): cdktf.IResolvable;
    get id(): string;
    get iid(): number;
    private _milestoneId?;
    get milestoneId(): number;
    set milestoneId(value: number);
    get milestoneIdInput(): number | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get projectId(): number;
    get startDate(): string;
    get state(): string;
    get title(): string;
    get updatedAt(): string;
    get webUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
