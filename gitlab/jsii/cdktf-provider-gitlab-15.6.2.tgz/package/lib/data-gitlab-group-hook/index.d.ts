/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataGitlabGroupHookConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID or full path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_hook#group DataGitlabGroupHook#group}
    */
    readonly group: string;
    /**
    * The id of the group hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_hook#hook_id DataGitlabGroupHook#hook_id}
    */
    readonly hookId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_hook gitlab_group_hook}
*/
export declare class DataGitlabGroupHook extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "gitlab_group_hook";
    /**
    * Generates CDKTF code for importing a DataGitlabGroupHook resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGitlabGroupHook to import
    * @param importFromId The id of the existing DataGitlabGroupHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGitlabGroupHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/data-sources/group_hook gitlab_group_hook} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGitlabGroupHookConfig
    */
    constructor(scope: Construct, id: string, config: DataGitlabGroupHookConfig);
    get confidentialIssuesEvents(): cdktf.IResolvable;
    get confidentialNoteEvents(): cdktf.IResolvable;
    get customWebhookTemplate(): string;
    get deploymentEvents(): cdktf.IResolvable;
    get emojiEvents(): cdktf.IResolvable;
    get enableSslVerification(): cdktf.IResolvable;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    get groupId(): number;
    private _hookId?;
    get hookId(): number;
    set hookId(value: number);
    get hookIdInput(): number | undefined;
    get id(): string;
    get issuesEvents(): cdktf.IResolvable;
    get jobEvents(): cdktf.IResolvable;
    get mergeRequestsEvents(): cdktf.IResolvable;
    get noteEvents(): cdktf.IResolvable;
    get pipelineEvents(): cdktf.IResolvable;
    get pushEvents(): cdktf.IResolvable;
    get pushEventsBranchFilter(): string;
    get releasesEvents(): cdktf.IResolvable;
    get subgroupEvents(): cdktf.IResolvable;
    get tagPushEvents(): cdktf.IResolvable;
    get token(): string;
    get url(): string;
    get wikiPageEvents(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
