/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectIntegrationYoutrackConfig extends cdktf.TerraformMetaArguments {
    /**
    * URL to view an issue in the external issue tracker. Must contain :id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack#issues_url ProjectIntegrationYoutrack#issues_url}
    */
    readonly issuesUrl: string;
    /**
    * ID or namespace of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack#project ProjectIntegrationYoutrack#project}
    */
    readonly project: string;
    /**
    * URL of the project in the external issue tracker.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack#project_url ProjectIntegrationYoutrack#project_url}
    */
    readonly projectUrl: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack gitlab_project_integration_youtrack}
*/
export declare class ProjectIntegrationYoutrack extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_integration_youtrack";
    /**
    * Generates CDKTF code for importing a ProjectIntegrationYoutrack resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectIntegrationYoutrack to import
    * @param importFromId The id of the existing ProjectIntegrationYoutrack that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectIntegrationYoutrack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/project_integration_youtrack gitlab_project_integration_youtrack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectIntegrationYoutrackConfig
    */
    constructor(scope: Construct, id: string, config: ProjectIntegrationYoutrackConfig);
    get id(): string;
    private _issuesUrl?;
    get issuesUrl(): string;
    set issuesUrl(value: string);
    get issuesUrlInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectUrl?;
    get projectUrl(): string;
    set projectUrl(value: string);
    get projectUrlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
