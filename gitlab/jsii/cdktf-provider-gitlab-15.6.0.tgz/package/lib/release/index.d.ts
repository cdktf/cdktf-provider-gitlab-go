/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ReleaseConfig extends cdktf.TerraformMetaArguments {
    /**
    * The release assets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#assets Release#assets}
    */
    readonly assets?: ReleaseAssets;
    /**
    * The description of the release. You can use Markdown.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#description Release#description}
    */
    readonly description?: string;
    /**
    * The title of each milestone the release is associated with. GitLab Premium customers can specify group milestones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#milestones Release#milestones}
    */
    readonly milestones?: string[];
    /**
    * The name of the release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#name Release#name}
    */
    readonly name?: string;
    /**
    * The ID or full path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#project Release#project}
    */
    readonly project: string;
    /**
    * If a tag specified in tag_name doesn't exist, the release is created from ref and tagged with tag_name. It can be a commit SHA, another tag name, or a branch name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#ref Release#ref}
    */
    readonly ref?: string;
    /**
    * Date and time for the release. Defaults to the current time. Expected in ISO 8601 format (2019-03-15T08:00:00Z). Only provide this field if creating an upcoming or historical release.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#released_at Release#released_at}
    */
    readonly releasedAt?: string;
    /**
    * Message to use if creating a new annotated tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#tag_message Release#tag_message}
    */
    readonly tagMessage?: string;
    /**
    * The tag where the release is created from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#tag_name Release#tag_name}
    */
    readonly tagName: string;
}
export interface ReleaseAssets {
}
export declare function releaseAssetsToTerraform(struct?: ReleaseAssets | cdktf.IResolvable): any;
export declare function releaseAssetsToHclTerraform(struct?: ReleaseAssets | cdktf.IResolvable): any;
export declare class ReleaseAssetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseAssets | cdktf.IResolvable | undefined;
    set internalValue(value: ReleaseAssets | cdktf.IResolvable | undefined);
    get count(): number;
}
export interface ReleaseAuthor {
}
export declare function releaseAuthorToTerraform(struct?: ReleaseAuthor): any;
export declare function releaseAuthorToHclTerraform(struct?: ReleaseAuthor): any;
export declare class ReleaseAuthorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseAuthor | undefined;
    set internalValue(value: ReleaseAuthor | undefined);
    get avatarUrl(): string;
    get id(): number;
    get name(): string;
    get state(): string;
    get username(): string;
    get webUrl(): string;
}
export interface ReleaseCommit {
}
export declare function releaseCommitToTerraform(struct?: ReleaseCommit): any;
export declare function releaseCommitToHclTerraform(struct?: ReleaseCommit): any;
export declare class ReleaseCommitOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseCommit | undefined;
    set internalValue(value: ReleaseCommit | undefined);
    get authorEmail(): string;
    get authorName(): string;
    get authoredDate(): string;
    get committedDate(): string;
    get committerEmail(): string;
    get committerName(): string;
    get createdAt(): string;
    get id(): string;
    get message(): string;
    get parentIds(): string[];
    get shortId(): string;
    get title(): string;
}
export interface ReleaseLinks {
}
export declare function releaseLinksToTerraform(struct?: ReleaseLinks): any;
export declare function releaseLinksToHclTerraform(struct?: ReleaseLinks): any;
export declare class ReleaseLinksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseLinks | undefined;
    set internalValue(value: ReleaseLinks | undefined);
    get closedIssuesUrl(): string;
    get closedMergeRequestsUrl(): string;
    get editUrl(): string;
    get mergedMergeRequestsUrl(): string;
    get openedIssuesUrl(): string;
    get openedMergeRequestsUrl(): string;
    get selfAttribute(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release gitlab_release}
*/
export declare class Release extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_release";
    /**
    * Generates CDKTF code for importing a Release resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Release to import
    * @param importFromId The id of the existing Release that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Release to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/release gitlab_release} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReleaseConfig
    */
    constructor(scope: Construct, id: string, config: ReleaseConfig);
    private _assets;
    get assets(): ReleaseAssetsOutputReference;
    putAssets(value: ReleaseAssets): void;
    resetAssets(): void;
    get assetsInput(): cdktf.IResolvable | ReleaseAssets | undefined;
    private _author;
    get author(): ReleaseAuthorOutputReference;
    private _commit;
    get commit(): ReleaseCommitOutputReference;
    get commitPath(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get descriptionHtml(): string;
    get id(): string;
    private _links;
    get links(): ReleaseLinksOutputReference;
    private _milestones?;
    get milestones(): string[];
    set milestones(value: string[]);
    resetMilestones(): void;
    get milestonesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _releasedAt?;
    get releasedAt(): string;
    set releasedAt(value: string);
    resetReleasedAt(): void;
    get releasedAtInput(): string | undefined;
    private _tagMessage?;
    get tagMessage(): string;
    set tagMessage(value: string);
    resetTagMessage(): void;
    get tagMessageInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    get tagNameInput(): string | undefined;
    get tagPath(): string;
    get upcomingRelease(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
