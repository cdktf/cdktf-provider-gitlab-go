/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ProjectWikiPageConfig extends cdktf.TerraformMetaArguments {
    /**
    * Content of the wiki page. Must be at least 1 character long.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page#content ProjectWikiPage#content}
    */
    readonly content: string;
    /**
    * Format of the wiki page (auto-generated if not provided). Valid values are: `markdown`, `rdoc`, `asciidoc`, `org`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page#format ProjectWikiPage#format}
    */
    readonly format?: string;
    /**
    * The ID or URL-encoded path of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page#project ProjectWikiPage#project}
    */
    readonly project: string;
    /**
    * Title of the wiki page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page#title ProjectWikiPage#title}
    */
    readonly title: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page gitlab_project_wiki_page}
*/
export declare class ProjectWikiPage extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_project_wiki_page";
    /**
    * Generates CDKTF code for importing a ProjectWikiPage resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectWikiPage to import
    * @param importFromId The id of the existing ProjectWikiPage that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectWikiPage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/project_wiki_page gitlab_project_wiki_page} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectWikiPageConfig
    */
    constructor(scope: Construct, id: string, config: ProjectWikiPageConfig);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    get encoding(): string;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    get id(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get slug(): string;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
