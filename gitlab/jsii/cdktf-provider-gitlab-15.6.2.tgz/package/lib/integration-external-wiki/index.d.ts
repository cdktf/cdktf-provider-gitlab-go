/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntegrationExternalWikiConfig extends cdktf.TerraformMetaArguments {
    /**
    * The URL of the external wiki.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki#external_wiki_url IntegrationExternalWiki#external_wiki_url}
    */
    readonly externalWikiUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki#id IntegrationExternalWiki#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the project you want to activate integration on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki#project IntegrationExternalWiki#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki gitlab_integration_external_wiki}
*/
export declare class IntegrationExternalWiki extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_integration_external_wiki";
    /**
    * Generates CDKTF code for importing a IntegrationExternalWiki resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationExternalWiki to import
    * @param importFromId The id of the existing IntegrationExternalWiki that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationExternalWiki to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/integration_external_wiki gitlab_integration_external_wiki} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationExternalWikiConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationExternalWikiConfig);
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    private _externalWikiUrl?;
    get externalWikiUrl(): string;
    set externalWikiUrl(value: string);
    get externalWikiUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get slug(): string;
    get title(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
