/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ClusterAgentTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token#agent_id ClusterAgentToken#agent_id}
    */
    readonly agentId: number;
    /**
    * The Description for the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token#description ClusterAgentToken#description}
    */
    readonly description?: string;
    /**
    * The Name of the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token#name ClusterAgentToken#name}
    */
    readonly name: string;
    /**
    * ID or full path of the project maintained by the authenticated user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token#project ClusterAgentToken#project}
    */
    readonly project: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token gitlab_cluster_agent_token}
*/
export declare class ClusterAgentToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_cluster_agent_token";
    /**
    * Generates CDKTF code for importing a ClusterAgentToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClusterAgentToken to import
    * @param importFromId The id of the existing ClusterAgentToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClusterAgentToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.5.0/docs/resources/cluster_agent_token gitlab_cluster_agent_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterAgentTokenConfig
    */
    constructor(scope: Construct, id: string, config: ClusterAgentTokenConfig);
    private _agentId?;
    get agentId(): number;
    set agentId(value: number);
    get agentIdInput(): number | undefined;
    get createdAt(): string;
    get createdByUserId(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUsedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    get status(): string;
    get token(): string;
    get tokenId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
