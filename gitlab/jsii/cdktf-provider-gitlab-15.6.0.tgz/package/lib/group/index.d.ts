/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * A list of email address domains to allow group access. Will be concatenated together into a comma separated string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#allowed_email_domains_list Group#allowed_email_domains_list}
    */
    readonly allowedEmailDomainsList?: string[];
    /**
    * Default to Auto DevOps pipeline for all projects within this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#auto_devops_enabled Group#auto_devops_enabled}
    */
    readonly autoDevopsEnabled?: boolean | cdktf.IResolvable;
    /**
    * A local path to the avatar image to upload. **Note**: not available for imported resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#avatar Group#avatar}
    */
    readonly avatar?: string;
    /**
    * The hash of the avatar image. Use `filesha256("path/to/avatar.png")` whenever possible. **Note**: this is used to trigger an update of the avatar. If it's not given, but an avatar is given, the avatar will be updated each time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#avatar_hash Group#avatar_hash}
    */
    readonly avatarHash?: string;
    /**
    * Initial default branch name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#default_branch Group#default_branch}
    */
    readonly defaultBranch?: string;
    /**
    * See https://docs.gitlab.com/api/groups/#options-for-default_branch_protection. Valid values are: `0`, `1`, `2`, `3`, `4`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#default_branch_protection Group#default_branch_protection}
    */
    readonly defaultBranchProtection?: number;
    /**
    * The group's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#description Group#description}
    */
    readonly description?: string;
    /**
    * Enable email notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#emails_enabled Group#emails_enabled}
    */
    readonly emailsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Can be set by administrators only. Additional CI/CD minutes for this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#extra_shared_runners_minutes_limit Group#extra_shared_runners_minutes_limit}
    */
    readonly extraSharedRunnersMinutesLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#id Group#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of IP addresses or subnet masks to restrict group access. Will be concatenated together into a comma separated string. Only allowed on top level groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#ip_restriction_ranges Group#ip_restriction_ranges}
    */
    readonly ipRestrictionRanges?: string[];
    /**
    * Enable/disable Large File Storage (LFS) for the projects in this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#lfs_enabled Group#lfs_enabled}
    */
    readonly lfsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Users cannot be added to projects in this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#membership_lock Group#membership_lock}
    */
    readonly membershipLock?: boolean | cdktf.IResolvable;
    /**
    * Disable the capability of a group from getting mentioned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#mentions_disabled Group#mentions_disabled}
    */
    readonly mentionsDisabled?: boolean | cdktf.IResolvable;
    /**
    * The name of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#name Group#name}
    */
    readonly name: string;
    /**
    * Id of the parent group (creates a nested group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#parent_id Group#parent_id}
    */
    readonly parentId?: number;
    /**
    * The path of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#path Group#path}
    */
    readonly path: string;
    /**
    * Whether the group should be permanently removed during a `delete` operation. This only works with subgroups. Must be configured via an `apply` before the `destroy` is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#permanently_remove_on_delete Group#permanently_remove_on_delete}
    */
    readonly permanentlyRemoveOnDelete?: boolean | cdktf.IResolvable;
    /**
    * Defaults to false. When enabled, users can not fork projects from this group to external namespaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#prevent_forking_outside_group Group#prevent_forking_outside_group}
    */
    readonly preventForkingOutsideGroup?: boolean | cdktf.IResolvable;
    /**
    * Determine if developers can create projects in the group. Valid values are: `noone`, `owner`, `maintainer`, `developer`, `administrator`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#project_creation_level Group#project_creation_level}
    */
    readonly projectCreationLevel?: string;
    /**
    * Allow users to request member access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#request_access_enabled Group#request_access_enabled}
    */
    readonly requestAccessEnabled?: boolean | cdktf.IResolvable;
    /**
    * Require all users in this group to setup Two-factor authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#require_two_factor_authentication Group#require_two_factor_authentication}
    */
    readonly requireTwoFactorAuthentication?: boolean | cdktf.IResolvable;
    /**
    * Prevent sharing a project with another group within this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#share_with_group_lock Group#share_with_group_lock}
    */
    readonly shareWithGroupLock?: boolean | cdktf.IResolvable;
    /**
    * Can be set by administrators only. Maximum number of monthly CI/CD minutes for this group. Can be nil (default; inherit system default), 0 (unlimited), or > 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#shared_runners_minutes_limit Group#shared_runners_minutes_limit}
    */
    readonly sharedRunnersMinutesLimit?: number;
    /**
    * Enable or disable shared runners for a group’s subgroups and projects. Valid values are: `enabled`, `disabled_and_overridable`, `disabled_and_unoverridable`, `disabled_with_override`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#shared_runners_setting Group#shared_runners_setting}
    */
    readonly sharedRunnersSetting?: string;
    /**
    * Allowed to create subgroups. Valid values are: `owner`, `maintainer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#subgroup_creation_level Group#subgroup_creation_level}
    */
    readonly subgroupCreationLevel?: string;
    /**
    * Defaults to 48. Time before Two-factor authentication is enforced (in hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#two_factor_grace_period Group#two_factor_grace_period}
    */
    readonly twoFactorGracePeriod?: number;
    /**
    * The group's visibility. Can be `private`, `internal`, or `public`. Valid values are: `private`, `internal`, `public`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#visibility_level Group#visibility_level}
    */
    readonly visibilityLevel?: string;
    /**
    * The group's wiki access level. Only available on Premium and Ultimate plans. Valid values are `disabled`, `private`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#wiki_access_level Group#wiki_access_level}
    */
    readonly wikiAccessLevel?: string;
    /**
    * default_branch_protection_defaults block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#default_branch_protection_defaults Group#default_branch_protection_defaults}
    */
    readonly defaultBranchProtectionDefaults?: GroupDefaultBranchProtectionDefaults;
    /**
    * push_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#push_rules Group#push_rules}
    */
    readonly pushRules?: GroupPushRules;
}
export interface GroupDefaultBranchProtectionDefaults {
    /**
    * Allow force push for all users with push access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#allow_force_push Group#allow_force_push}
    */
    readonly allowForcePush?: boolean | cdktf.IResolvable;
    /**
    * An array of access levels allowed to merge. Valid values are: `developer`, `maintainer`, `no one`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#allowed_to_merge Group#allowed_to_merge}
    */
    readonly allowedToMerge?: string[];
    /**
    * An array of access levels allowed to push. Valid values are: `developer`, `maintainer`, `no one`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#allowed_to_push Group#allowed_to_push}
    */
    readonly allowedToPush?: string[];
    /**
    * Allow developers to initial push.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#developer_can_initial_push Group#developer_can_initial_push}
    */
    readonly developerCanInitialPush?: boolean | cdktf.IResolvable;
}
export declare function groupDefaultBranchProtectionDefaultsToTerraform(struct?: GroupDefaultBranchProtectionDefaultsOutputReference | GroupDefaultBranchProtectionDefaults): any;
export declare function groupDefaultBranchProtectionDefaultsToHclTerraform(struct?: GroupDefaultBranchProtectionDefaultsOutputReference | GroupDefaultBranchProtectionDefaults): any;
export declare class GroupDefaultBranchProtectionDefaultsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupDefaultBranchProtectionDefaults | undefined;
    set internalValue(value: GroupDefaultBranchProtectionDefaults | undefined);
    private _allowForcePush?;
    get allowForcePush(): boolean | cdktf.IResolvable;
    set allowForcePush(value: boolean | cdktf.IResolvable);
    resetAllowForcePush(): void;
    get allowForcePushInput(): boolean | cdktf.IResolvable | undefined;
    private _allowedToMerge?;
    get allowedToMerge(): string[];
    set allowedToMerge(value: string[]);
    resetAllowedToMerge(): void;
    get allowedToMergeInput(): string[] | undefined;
    private _allowedToPush?;
    get allowedToPush(): string[];
    set allowedToPush(value: string[]);
    resetAllowedToPush(): void;
    get allowedToPushInput(): string[] | undefined;
    private _developerCanInitialPush?;
    get developerCanInitialPush(): boolean | cdktf.IResolvable;
    set developerCanInitialPush(value: boolean | cdktf.IResolvable);
    resetDeveloperCanInitialPush(): void;
    get developerCanInitialPushInput(): boolean | cdktf.IResolvable | undefined;
}
export interface GroupPushRules {
    /**
    * All commit author emails must match this regex, e.g. `@my-company.com$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#author_email_regex Group#author_email_regex}
    */
    readonly authorEmailRegex?: string;
    /**
    * All branch names must match this regex, e.g. `(feature|hotfix)\/*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#branch_name_regex Group#branch_name_regex}
    */
    readonly branchNameRegex?: string;
    /**
    * Only commits pushed using verified emails are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#commit_committer_check Group#commit_committer_check}
    */
    readonly commitCommitterCheck?: boolean | cdktf.IResolvable;
    /**
    * Users can only push commits to this repository if the commit author name is consistent with their GitLab account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#commit_committer_name_check Group#commit_committer_name_check}
    */
    readonly commitCommitterNameCheck?: boolean | cdktf.IResolvable;
    /**
    * No commit message is allowed to match this regex, for example `ssh\:\/\/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#commit_message_negative_regex Group#commit_message_negative_regex}
    */
    readonly commitMessageNegativeRegex?: string;
    /**
    * All commit messages must match this regex, e.g. `Fixed \d+\..*`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#commit_message_regex Group#commit_message_regex}
    */
    readonly commitMessageRegex?: string;
    /**
    * Deny deleting a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#deny_delete_tag Group#deny_delete_tag}
    */
    readonly denyDeleteTag?: boolean | cdktf.IResolvable;
    /**
    * Filenames matching the regular expression provided in this attribute are not allowed, for example, `(jar|exe)$`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#file_name_regex Group#file_name_regex}
    */
    readonly fileNameRegex?: string;
    /**
    * Maximum file size (MB) allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#max_file_size Group#max_file_size}
    */
    readonly maxFileSize?: number;
    /**
    * Allows only GitLab users to author commits.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#member_check Group#member_check}
    */
    readonly memberCheck?: boolean | cdktf.IResolvable;
    /**
    * GitLab will reject any files that are likely to contain secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#prevent_secrets Group#prevent_secrets}
    */
    readonly preventSecrets?: boolean | cdktf.IResolvable;
    /**
    * Reject commit when it’s not DCO certified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#reject_non_dco_commits Group#reject_non_dco_commits}
    */
    readonly rejectNonDcoCommits?: boolean | cdktf.IResolvable;
    /**
    * Only commits signed through GPG are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#reject_unsigned_commits Group#reject_unsigned_commits}
    */
    readonly rejectUnsignedCommits?: boolean | cdktf.IResolvable;
}
export declare function groupPushRulesToTerraform(struct?: GroupPushRulesOutputReference | GroupPushRules): any;
export declare function groupPushRulesToHclTerraform(struct?: GroupPushRulesOutputReference | GroupPushRules): any;
export declare class GroupPushRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupPushRules | undefined;
    set internalValue(value: GroupPushRules | undefined);
    private _authorEmailRegex?;
    get authorEmailRegex(): string;
    set authorEmailRegex(value: string);
    resetAuthorEmailRegex(): void;
    get authorEmailRegexInput(): string | undefined;
    private _branchNameRegex?;
    get branchNameRegex(): string;
    set branchNameRegex(value: string);
    resetBranchNameRegex(): void;
    get branchNameRegexInput(): string | undefined;
    private _commitCommitterCheck?;
    get commitCommitterCheck(): boolean | cdktf.IResolvable;
    set commitCommitterCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterCheck(): void;
    get commitCommitterCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitCommitterNameCheck?;
    get commitCommitterNameCheck(): boolean | cdktf.IResolvable;
    set commitCommitterNameCheck(value: boolean | cdktf.IResolvable);
    resetCommitCommitterNameCheck(): void;
    get commitCommitterNameCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _commitMessageNegativeRegex?;
    get commitMessageNegativeRegex(): string;
    set commitMessageNegativeRegex(value: string);
    resetCommitMessageNegativeRegex(): void;
    get commitMessageNegativeRegexInput(): string | undefined;
    private _commitMessageRegex?;
    get commitMessageRegex(): string;
    set commitMessageRegex(value: string);
    resetCommitMessageRegex(): void;
    get commitMessageRegexInput(): string | undefined;
    private _denyDeleteTag?;
    get denyDeleteTag(): boolean | cdktf.IResolvable;
    set denyDeleteTag(value: boolean | cdktf.IResolvable);
    resetDenyDeleteTag(): void;
    get denyDeleteTagInput(): boolean | cdktf.IResolvable | undefined;
    private _fileNameRegex?;
    get fileNameRegex(): string;
    set fileNameRegex(value: string);
    resetFileNameRegex(): void;
    get fileNameRegexInput(): string | undefined;
    private _maxFileSize?;
    get maxFileSize(): number;
    set maxFileSize(value: number);
    resetMaxFileSize(): void;
    get maxFileSizeInput(): number | undefined;
    private _memberCheck?;
    get memberCheck(): boolean | cdktf.IResolvable;
    set memberCheck(value: boolean | cdktf.IResolvable);
    resetMemberCheck(): void;
    get memberCheckInput(): boolean | cdktf.IResolvable | undefined;
    private _preventSecrets?;
    get preventSecrets(): boolean | cdktf.IResolvable;
    set preventSecrets(value: boolean | cdktf.IResolvable);
    resetPreventSecrets(): void;
    get preventSecretsInput(): boolean | cdktf.IResolvable | undefined;
    private _rejectNonDcoCommits?;
    get rejectNonDcoCommits(): boolean | cdktf.IResolvable;
    set rejectNonDcoCommits(value: boolean | cdktf.IResolvable);
    resetRejectNonDcoCommits(): void;
    get rejectNonDcoCommitsInput(): boolean | cdktf.IResolvable | undefined;
    private _rejectUnsignedCommits?;
    get rejectUnsignedCommits(): boolean | cdktf.IResolvable;
    set rejectUnsignedCommits(value: boolean | cdktf.IResolvable);
    resetRejectUnsignedCommits(): void;
    get rejectUnsignedCommitsInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group gitlab_group}
*/
export declare class Group extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_group";
    /**
    * Generates CDKTF code for importing a Group resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Group to import
    * @param importFromId The id of the existing Group that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Group to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.0/docs/resources/group gitlab_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupConfig
    */
    constructor(scope: Construct, id: string, config: GroupConfig);
    private _allowedEmailDomainsList?;
    get allowedEmailDomainsList(): string[];
    set allowedEmailDomainsList(value: string[]);
    resetAllowedEmailDomainsList(): void;
    get allowedEmailDomainsListInput(): string[] | undefined;
    private _autoDevopsEnabled?;
    get autoDevopsEnabled(): boolean | cdktf.IResolvable;
    set autoDevopsEnabled(value: boolean | cdktf.IResolvable);
    resetAutoDevopsEnabled(): void;
    get autoDevopsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _avatar?;
    get avatar(): string;
    set avatar(value: string);
    resetAvatar(): void;
    get avatarInput(): string | undefined;
    private _avatarHash?;
    get avatarHash(): string;
    set avatarHash(value: string);
    resetAvatarHash(): void;
    get avatarHashInput(): string | undefined;
    get avatarUrl(): string;
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    resetDefaultBranch(): void;
    get defaultBranchInput(): string | undefined;
    private _defaultBranchProtection?;
    get defaultBranchProtection(): number;
    set defaultBranchProtection(value: number);
    resetDefaultBranchProtection(): void;
    get defaultBranchProtectionInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _emailsEnabled?;
    get emailsEnabled(): boolean | cdktf.IResolvable;
    set emailsEnabled(value: boolean | cdktf.IResolvable);
    resetEmailsEnabled(): void;
    get emailsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _extraSharedRunnersMinutesLimit?;
    get extraSharedRunnersMinutesLimit(): number;
    set extraSharedRunnersMinutesLimit(value: number);
    resetExtraSharedRunnersMinutesLimit(): void;
    get extraSharedRunnersMinutesLimitInput(): number | undefined;
    get fullName(): string;
    get fullPath(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipRestrictionRanges?;
    get ipRestrictionRanges(): string[];
    set ipRestrictionRanges(value: string[]);
    resetIpRestrictionRanges(): void;
    get ipRestrictionRangesInput(): string[] | undefined;
    private _lfsEnabled?;
    get lfsEnabled(): boolean | cdktf.IResolvable;
    set lfsEnabled(value: boolean | cdktf.IResolvable);
    resetLfsEnabled(): void;
    get lfsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _membershipLock?;
    get membershipLock(): boolean | cdktf.IResolvable;
    set membershipLock(value: boolean | cdktf.IResolvable);
    resetMembershipLock(): void;
    get membershipLockInput(): boolean | cdktf.IResolvable | undefined;
    private _mentionsDisabled?;
    get mentionsDisabled(): boolean | cdktf.IResolvable;
    set mentionsDisabled(value: boolean | cdktf.IResolvable);
    resetMentionsDisabled(): void;
    get mentionsDisabledInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentId?;
    get parentId(): number;
    set parentId(value: number);
    resetParentId(): void;
    get parentIdInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _permanentlyRemoveOnDelete?;
    get permanentlyRemoveOnDelete(): boolean | cdktf.IResolvable;
    set permanentlyRemoveOnDelete(value: boolean | cdktf.IResolvable);
    resetPermanentlyRemoveOnDelete(): void;
    get permanentlyRemoveOnDeleteInput(): boolean | cdktf.IResolvable | undefined;
    private _preventForkingOutsideGroup?;
    get preventForkingOutsideGroup(): boolean | cdktf.IResolvable;
    set preventForkingOutsideGroup(value: boolean | cdktf.IResolvable);
    resetPreventForkingOutsideGroup(): void;
    get preventForkingOutsideGroupInput(): boolean | cdktf.IResolvable | undefined;
    private _projectCreationLevel?;
    get projectCreationLevel(): string;
    set projectCreationLevel(value: string);
    resetProjectCreationLevel(): void;
    get projectCreationLevelInput(): string | undefined;
    private _requestAccessEnabled?;
    get requestAccessEnabled(): boolean | cdktf.IResolvable;
    set requestAccessEnabled(value: boolean | cdktf.IResolvable);
    resetRequestAccessEnabled(): void;
    get requestAccessEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _requireTwoFactorAuthentication?;
    get requireTwoFactorAuthentication(): boolean | cdktf.IResolvable;
    set requireTwoFactorAuthentication(value: boolean | cdktf.IResolvable);
    resetRequireTwoFactorAuthentication(): void;
    get requireTwoFactorAuthenticationInput(): boolean | cdktf.IResolvable | undefined;
    get runnersToken(): string;
    private _shareWithGroupLock?;
    get shareWithGroupLock(): boolean | cdktf.IResolvable;
    set shareWithGroupLock(value: boolean | cdktf.IResolvable);
    resetShareWithGroupLock(): void;
    get shareWithGroupLockInput(): boolean | cdktf.IResolvable | undefined;
    private _sharedRunnersMinutesLimit?;
    get sharedRunnersMinutesLimit(): number;
    set sharedRunnersMinutesLimit(value: number);
    resetSharedRunnersMinutesLimit(): void;
    get sharedRunnersMinutesLimitInput(): number | undefined;
    private _sharedRunnersSetting?;
    get sharedRunnersSetting(): string;
    set sharedRunnersSetting(value: string);
    resetSharedRunnersSetting(): void;
    get sharedRunnersSettingInput(): string | undefined;
    private _subgroupCreationLevel?;
    get subgroupCreationLevel(): string;
    set subgroupCreationLevel(value: string);
    resetSubgroupCreationLevel(): void;
    get subgroupCreationLevelInput(): string | undefined;
    private _twoFactorGracePeriod?;
    get twoFactorGracePeriod(): number;
    set twoFactorGracePeriod(value: number);
    resetTwoFactorGracePeriod(): void;
    get twoFactorGracePeriodInput(): number | undefined;
    private _visibilityLevel?;
    get visibilityLevel(): string;
    set visibilityLevel(value: string);
    resetVisibilityLevel(): void;
    get visibilityLevelInput(): string | undefined;
    get webUrl(): string;
    private _wikiAccessLevel?;
    get wikiAccessLevel(): string;
    set wikiAccessLevel(value: string);
    resetWikiAccessLevel(): void;
    get wikiAccessLevelInput(): string | undefined;
    private _defaultBranchProtectionDefaults;
    get defaultBranchProtectionDefaults(): GroupDefaultBranchProtectionDefaultsOutputReference;
    putDefaultBranchProtectionDefaults(value: GroupDefaultBranchProtectionDefaults): void;
    resetDefaultBranchProtectionDefaults(): void;
    get defaultBranchProtectionDefaultsInput(): GroupDefaultBranchProtectionDefaults | undefined;
    private _pushRules;
    get pushRules(): GroupPushRulesOutputReference;
    putPushRules(value: GroupPushRules): void;
    resetPushRules(): void;
    get pushRulesInput(): GroupPushRules | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
