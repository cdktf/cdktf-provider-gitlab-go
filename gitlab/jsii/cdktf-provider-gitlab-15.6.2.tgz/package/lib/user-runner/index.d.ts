/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserRunnerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access level of the runner. Valid values are: `not_protected`, `ref_protected`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#access_level UserRunner#access_level}
    */
    readonly accessLevel?: string;
    /**
    * Description of the runner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#description UserRunner#description}
    */
    readonly description?: string;
    /**
    * The ID of the group that the runner is created in. Required if runner_type is group_type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#group_id UserRunner#group_id}
    */
    readonly groupId?: number;
    /**
    * Specifies if the runner should be locked for the current project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#locked UserRunner#locked}
    */
    readonly locked?: boolean | cdktf.IResolvable;
    /**
    * Free-form maintenance notes for the runner (1024 characters)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#maintenance_note UserRunner#maintenance_note}
    */
    readonly maintenanceNote?: string;
    /**
    * Maximum timeout that limits the amount of time (in seconds) that runners can run jobs. Must be at least 600 (10 minutes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#maximum_timeout UserRunner#maximum_timeout}
    */
    readonly maximumTimeout?: number;
    /**
    * Specifies if the runner should ignore new jobs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#paused UserRunner#paused}
    */
    readonly paused?: boolean | cdktf.IResolvable;
    /**
    * The ID of the project that the runner is created in. Required if runner_type is project_type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#project_id UserRunner#project_id}
    */
    readonly projectId?: number;
    /**
    * The scope of the runner. Valid values are: `instance_type`, `group_type`, `project_type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#runner_type UserRunner#runner_type}
    */
    readonly runnerType: string;
    /**
    * A list of runner tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#tag_list UserRunner#tag_list}
    */
    readonly tagList?: string[];
    /**
    * Specifies if the runner should handle untagged jobs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#untagged UserRunner#untagged}
    */
    readonly untagged?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner gitlab_user_runner}
*/
export declare class UserRunner extends cdktf.TerraformResource {
    static readonly tfResourceType = "gitlab_user_runner";
    /**
    * Generates CDKTF code for importing a UserRunner resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserRunner to import
    * @param importFromId The id of the existing UserRunner that should be imported. Refer to the {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserRunner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/gitlabhq/gitlab/18.6.1/docs/resources/user_runner gitlab_user_runner} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserRunnerConfig
    */
    constructor(scope: Construct, id: string, config: UserRunnerConfig);
    private _accessLevel?;
    get accessLevel(): string;
    set accessLevel(value: string);
    resetAccessLevel(): void;
    get accessLevelInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get id(): string;
    private _locked?;
    get locked(): boolean | cdktf.IResolvable;
    set locked(value: boolean | cdktf.IResolvable);
    resetLocked(): void;
    get lockedInput(): boolean | cdktf.IResolvable | undefined;
    private _maintenanceNote?;
    get maintenanceNote(): string;
    set maintenanceNote(value: string);
    resetMaintenanceNote(): void;
    get maintenanceNoteInput(): string | undefined;
    private _maximumTimeout?;
    get maximumTimeout(): number;
    set maximumTimeout(value: number);
    resetMaximumTimeout(): void;
    get maximumTimeoutInput(): number | undefined;
    private _paused?;
    get paused(): boolean | cdktf.IResolvable;
    set paused(value: boolean | cdktf.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktf.IResolvable | undefined;
    private _projectId?;
    get projectId(): number;
    set projectId(value: number);
    resetProjectId(): void;
    get projectIdInput(): number | undefined;
    private _runnerType?;
    get runnerType(): string;
    set runnerType(value: string);
    get runnerTypeInput(): string | undefined;
    private _tagList?;
    get tagList(): string[];
    set tagList(value: string[]);
    resetTagList(): void;
    get tagListInput(): string[] | undefined;
    get token(): string;
    private _untagged?;
    get untagged(): boolean | cdktf.IResolvable;
    set untagged(value: boolean | cdktf.IResolvable);
    resetUntagged(): void;
    get untaggedInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
